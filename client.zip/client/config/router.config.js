export default [
  {
    path: '/',
    component: '../layouts/BasicLayout',
    Routes: ['src/pages/Authorized'],
    routes: [{
        path: '/',
        redirect: '/index',
      },
      {
        path: '/index',
        name: 'home',
        icon: 'desktop',
        component: './Index/Index',
      },
      {
        path: '/public',
        name: 'public',
        icon: 'eye',
        component: './Index/Public',
      },
      {
        path: '/charts',
        name: 'charts',
        icon: 'fund',
        component: './Index/Charts',
        authority: ['G'],
      },
      {
        path: '/project',
        name: 'projectManage',
        icon: 'profile',
        authority: ['G', 'Z', 'J'],
        routes: [{
            path: '/project/apply',
            name: 'apply',
            icon:'plus-square',
            component: './Project/Apply',
            authority: ['G', 'Z', 'J'],
          },
          {
            path: '/project/excute',
            name: 'excute',
            icon:'project',
            routes: [{
                path: '/project/excute/proposal',
                name: 'proposal',
                icon:'pushpin',
                component: './Project/Proposal',
              },
              {
                path: '/project/excute/midcheck',
                name: 'midcheck',
                icon:'build',
                component: './Project/Midcheck',
              },
              {
                path: '/project/excute/conclude',
                name: 'conclude',
                icon:'bulb',
                component: './Project/Conclude',
              },
              {
                path: '/project/excute/stop',
                name:'stop',
                icon:'exception',
                component: './Project/Stop',
              },
            ]
          },
          {
            path: '/project/category',
            name: 'category',
            icon:'tags',
            component: './Project/Category',
            authority: ['G'],
          }
        ],
      },
      {
        path: '/expenditure',
        name: 'expenditureManage',
        icon: 'money-collect',
        authority: ['G', 'Z', 'J'],
        component: './Expenditure',
      },
      {
        path: '/fruit',
        name: 'fruitManage',
        icon: 'trophy',
        authority: ['G', 'Z', 'J'],
        component: './Fruit',
      },
      {
        path: '/system',
        name: 'systemManage',
        icon: 'setting',
        authority: ['G', 'Z', 'J'],
        routes: [{
            path: '/system/self',
            name: 'selfCenter',
            icon: 'user',
            component: './User/Center/Center',
          },
          {
            path: '/system/notice',
            name: 'notice',
            icon: 'bell',
            component: './User/Notice/Notice',
          },
        ],
      },
      {
        path: '/person',
        name: 'personManage',
        icon: 'team',
        component: './User/Manage',
        authority: ['G'],
      },
      {
        path: '/announce',
        name: 'announce',
        icon: 'sound',
        component: './Announce',
        authority: ['G'],
      },
      {
        path: '/files',
        name: 'files',
        icon: 'file',
        component: './Files',
        authority: ['G'],
      },
      {
        path: '/user',
        // component: '../layouts/UserLayout',
        hideInMenu:true,
        routes: [{
            path: '/user',
            redirect: '/'
          },
          {
            path: '/user/login',
            name: 'login',
            component: './User/Login/Login',
          },
          {
            path: '/user/register',
            name: 'register',
            component: './User/Register/Register'
          },
          {
            path: '/user/register-result',
            name: 'register.result',
            component: './User/Register/RegisterResult',
          },
        ],
      },
      {
        name: 'exception',
        icon: 'warning',
        path: '/exception',
        hideInMenu:true,
        routes: [
          // exception
          {
            path: '/exception/403',
            name: 'not-permission',
            component: './Exception/403',
          },
          {
            path: '/exception/404',
            name: 'not-find',
            component: './Exception/404',
          },
          {
            path: '/exception/500',
            name: 'server-error',
            component: './Exception/500',
          },
        ],
      },
      {
        component: '404',
      },
    ],
  },
];
