import {
  add
} from '@/services/user';
import {
  setAuthority
} from '@/utils/authority';
import {
  reloadAuthorized
} from '@/utils/Authorized';

export default {
  namespace: 'register',

  state: {
    status: undefined,
  },

  effects: {
    * submit({
      payload
    }, {
      call,
      put
    }) {
      const response = yield call(add, payload);
      yield put({
        type: 'registerHandle',
        payload: response,
      });
    },
  },

  reducers: {
    registerHandle(state, {
      payload
    }) {
      return {
        ...state,
        status: payload.code ? 'ok' : 'fail',
      };
    },
  },
};
