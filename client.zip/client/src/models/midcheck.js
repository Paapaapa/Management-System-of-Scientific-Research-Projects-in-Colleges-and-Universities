import {
  queryMidcheck,
  removeMidcheck,
  addMidcheck,
  getPMCharts
} from '@/services/api';
import {
  pagination,
  filterEmpty,
} from '@/utils/utils';

const searchData = pagination({});

const formData = {};

const data={
  list: [],
  pagination: {},
};

export default {
  namespace: 'midcheck',

  state: {
    data,
    searchData,
    formData,
    selectedRows: [],
    typeParams:{},
    PMArea:[],
    isIndex: true, // 标识是否是每个标签页在切换
  },

  effects: {
    * fetch(_, {
      call,
      put,
      select
    }) {
      const searchParams = yield select(state => state.midcheck.searchData);
      const typeParams = yield select(state => state.midcheck.typeParams);
      const response = yield call(queryMidcheck, filterEmpty({
        ...typeParams,
        ...searchParams,
      }));
      yield put({
        type: 'save',
        payload: response.data,
      });
    },
    * fetchPMArea(_, {
      call,
      put
    }) {
      const response = yield call(getPMCharts);
      yield put({
        type: 'savePMArea',
        payload: response.data,
      });
    },
    * add(_, {
      call,
      select
    }) {
      const params = yield select(state => state.midcheck.formData);
      const response = yield call(addMidcheck, params);

      return response;
    },
    * remove({
      payload,
      callback
    }, {
      call
    }) {
      const response = yield call(removeMidcheck, {
        Id: payload.Id
      });

      if (callback) callback();
      return response;
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: {
          list: action.payload.list,
          pagination: {
            total: action.payload.total,
            pageSize: parseInt(action.payload.pageSize, 10),
            current: parseInt(action.payload.pageNum, 10),
          }
        },
      };
    },
    savePMArea(state, {
      payload
    }) {
      return {
        ...state,
        PMArea: payload || [],
      };
    },
    resetList(state){
      return{
        ...state,
        data,
      }
    },
    saveTypeParams(state, {
      payload
    }) {
      return {
        ...state,
        typeParams: payload || {},
      }
    },
    changeSearchFormFields(state, {
      payload
    }) {
      const data = payload || searchData;
      return {
        ...state,
        searchData: {
          ...state.searchData,
          pageNum: 1,
          ...data,
        },
      };
    },
    resetSearchData(state, {
      payload
    }) {
      return {
        ...state,
        searchData: {
          ...searchData,
          ...payload,
        },
      };
    },
    changeIsIndex(state, {
      payload
    }) {
      return {
        ...state,
        isIndex: payload,
      }
    },
    changeFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload,
      }
    },
    resetFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload || formData,
      };
    },
    changeSelectedRows(state, {
      payload
    }) {
      return {
        ...state,
        selectedRows: payload,
      }
    }
  },
};
