import {
  query,
  queryCurrent,
  querySelect,
  add,
  remove,
  queryAvatar
} from '@/services/user';
import {
  pagination,
  filterEmpty,
} from '@/utils/utils';

const searchData = pagination({});

const formData = {};

const data={
  list: [],
  pagination: {},
}

export default {
  namespace: 'user',

  state: {
    data,
    currentUser: {},
    personSelect: {},
    zSelect: {},
    formData,
    searchData,
    selectedRows: [],
    typeParams:{},
    avatarList:{},
  },

  effects: {
    * fetch(_, {
      call,
      put,
      select
    }) {
      const searchParams = yield select(state => state.user.searchData);
      const typeParams = yield select(state => state.user.typeParams);
      const response = yield call(query, filterEmpty({
        ...typeParams,
        ...searchParams,
      }));
      yield put({
        type: 'save',
        payload: response ?.data,
      });
    },
    * fetchCurrent(_, {
      call,
      put
    }) {
      const response = yield call(queryCurrent, {
        Id: JSON.parse(sessionStorage.getItem('currentUser')).Id,
      });
      yield put({
        type: 'saveCurrentUser',
        payload: response.currentUser,
      });
    },
    * fetchSelect({
      payload
    }, {
      call,
      put
    }) {
      const response = yield call(querySelect, {
        ...payload,
      });
      yield put({
        type: payload ? 'saveZSelect' : 'saveSelect',
        payload: response,
      });
    },
    * fetchAvatar(_, {
      call,
      put
    }) {
      const response = yield call(queryAvatar);
      yield put({
        type:  'saveAvatar',
        payload: response,
      });
    },
    * add(_, {
      call,
      select
    }) {
      const params = yield select(state => state.user.formData);
      const response = yield call(add,params);
      return response;
    },
    * remove({
      payload
    }, {
      call
    }) {
      const response = yield call(remove, {
        Id: payload.Id
      });
      return response;
    },
  },
  reducers: {
    save(state, action) {
      return {
        ...state,
        data: {
          list: action.payload.list,
          pagination: {
            total: action.payload.total,
            pageSize: parseInt(action.payload.pageSize, 10),
            current: parseInt(action.payload.pageNum, 10),
          }
        },
      };
    },
    saveCurrentUser(state, action) {
      return {
        ...state,
        currentUser: action.payload || {},
      };
    },
    saveSelect(state, action) {
      return {
        ...state,
        personSelect: JSON.parse(action.payload.data),
      };
    },
    saveZSelect(state, action) {
      return {
        ...state,
        zSelect: JSON.parse(action.payload.data),
      };
    },
    saveAvatar(state, action) {
      return {
        ...state,
        avatarList: JSON.parse(action.payload.data),
      };
    },
    saveTypeParams(state, {
      payload
    }) {
      return {
        ...state,
        typeParams: payload || {},
      }
    },
    changeNotifyCount(state, action) {
      return {
        ...state,
        currentUser: {
          ...state.currentUser,
          notifyCount: action.payload.totalCount,
          unreadCount: action.payload.unreadCount,
        },
      };
    },
    changeSearchFormFields(state, {
      payload
    }) {
      const data = payload || searchData;
      return {
        ...state,
        searchData: {
          ...state.searchData,
          pageNum: 1,
          ...data,
        },
      };
    },
    resetSearchData(state, {
      payload
    }) {
      return {
        ...state,
        searchData: {
          ...searchData,
          ...payload,
        },
      };
    },
    changeFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload,
      }
    },
    resetFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload || formData,
      };
    },
    changeSelectedRows(state, {
      payload
    }) {
      return {
        ...state,
        selectedRows: payload,
      }
    },
  },
};
