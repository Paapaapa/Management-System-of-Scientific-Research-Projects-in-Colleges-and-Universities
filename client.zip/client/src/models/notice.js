import {
  queryNotice,
  removeNotice,
  addNotice
} from '@/services/api';
import {
  pagination,
  filterEmpty,
  formatObj,
} from '@/utils/utils';

const searchData = pagination({});

const formData = {
  Id: '',
};
const data = {
  list: [],
  pagination: {},
}

export default {
  namespace: 'notice',

  state: {
    data,
    searchData,
    formData,
    selectedRows: [],
  },

  effects: {
    * fetch(_, {
      call,
      put,
      select
    }) {
      const params = yield select(state => state.notice.searchData);
      const response = yield call(queryNotice, filterEmpty(params));
      yield put({
        type: 'save',
        payload: response.data,
      });
    },
    * add(_, {
      call,
      select
    }) {
      const params = yield select(state => state.notice.formData);
      const response = yield call(addNotice, formatObj(params));

      return response;
    },
    * remove({
      payload,
      callback
    }, {
      call,
      put
    }) {
      const response = yield call(removeNotice, {
        Id: payload.Id
      });

      if (callback) callback();
      return response;
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: {
          list: action.payload.list,
          pagination: {
            total: action.payload.total,
            pageSize: parseInt(action.payload.pageSize, 10),
            current: parseInt(action.payload.pageNum, 10),
          }
        },
      };
    },
    reset(state) {
      return {
        ...state,
        data,
      }
    },
    changeSearchFormFields(state, {
      payload
    }) {
      const data = payload || searchData;
      return {
        ...state,
        searchData: {
          ...state.searchData,
          ...data,
        },
      };
    },
    resetSearchData(state, {
      payload
    }) {
      return {
        ...state,
        searchData: payload || searchData,
      };
    },
    changeFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: {
          ...state.formData,
          ...payload,
        }
      }
    },
    resetFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload || formData,
      };
    },
    changeSelectedRows(state, {
      payload
    }) {
      return {
        ...state,
        selectedRows: payload,
      }
    },
  },
};
