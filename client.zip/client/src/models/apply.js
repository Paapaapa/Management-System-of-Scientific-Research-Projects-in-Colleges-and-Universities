import {
  queryProjectApply,
  removeProjectApply,
  addProjectApply,
  queryPApplySelect,
  getPCharts,
  queryZCheck,
  addZCheck,
  removeZCheck,
  querySign,
  addSign,
  removeSign,
} from '@/services/api';
import {
  pagination,
  filterEmpty,
} from '@/utils/utils';

const searchData = pagination({});
const signSearch = pagination({});

const formData = {};

const zcheckFormData = {};

const signFormData = {};

const data = {
  list: [],
  pagination: {},
};

export default {
  namespace: 'apply',

  state: {
    data,
    searchData,
    signSearch,
    signData: [], // 选题数据
    formData,
    zcheckFormData, // 专家评审
    signFormData, // 选题管理
    selectedRows: [],
    projectSelect: {}, // 所有项目
    SSelect: {}, // 自己申报的项目
    typeParams: {}, // 分类参数
    PArea: [], // 区域图数据
    isIndex: true, // 标识是否是每个标签页在切换
  },

  effects: {
    * fetch(_, {
      call,
      put,
      select
    }) {
      const searchParams = yield select(state => state.apply.searchData);
      const typeParams = yield select(state => state.apply.typeParams);
      const response = yield call(queryProjectApply, filterEmpty({
        ...typeParams,
        ...searchParams,
      }));
      yield put({
        type: 'save',
        payload: response.data,
      });
      return response;
    },
    * fetchSelect({
      payload
    }, {
      call,
      put
    }) {
      const response = yield call(queryPApplySelect, payload);
      yield put({
        type: payload ? 'saveSSelect' : 'saveSelect',
        payload: response,
      });
    },
    * fetchPArea({
      payload
    }, {
      call,
      put
    }) {
      const response = yield call(getPCharts, payload);
      yield put({
        type: 'savePArea',
        payload: response.data,
      });
    },
    * add(_, {
      call,
      select
    }) {
      const params = yield select(state => state.apply.formData);
      const response = yield call(addProjectApply, params);
      return response;
    },
    * remove({
      payload,
    }, {
      call,
    }) {
      const response = yield call(removeProjectApply, {
        Id: payload.Id
      });
      return response;
    },
    * addZCheck(_, {
      call,
      select
    }) {
      const params = yield select(state => state.apply.zcheckFormData);
      const response = yield call(addZCheck, params);
      return response;
    },
    * removeZCheck({
      payload,
    }, {
      call,
    }) {
      const response = yield call(removeZCheck, {
        project_id: payload.project_id
      });
      return response;
    },
    * fetchSign(_, {
      call,
      put,
      select
    }) {
      const searchParams = yield select(state => state.apply.signSearch);
      const response = yield call(querySign, searchParams);
      yield put({
        type: 'save',
        payload: response.data,
      });
    },
    * addSign(_, {
      call,
      select
    }) {
      const params = yield select(state => state.apply.signFormData);
      const response = yield call(addSign, params);
      return response;
    },
    * removeSign({
      payload,
    }, {
      call,
    }) {
      const response = yield call(removeSign, {
        Id: payload.Id
      });
      return response;
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: {
          list: action.payload.list || [],
          pagination: {
            total: action.payload.total || 0,
            pageSize: parseInt(action.payload.pageSize, 10) || 10,
            current: parseInt(action.payload.pageNum, 10) || 1,
          }
        },
      };
    },
    savePArea(state, {
      payload
    }) {
      return {
        ...state,
        PArea: payload || [],
      };
    },
    resetList(state) {
      return {
        ...state,
        data
      }
    },
    saveSelect(state, action) {
      return {
        ...state,
        projectSelect: JSON.parse(action.payload.data),
      };
    },
    // 存储自己的项目
    saveSSelect(state, action) {
      return {
        ...state,
        SSelect: JSON.parse(action.payload.data),
      };
    },
    saveTypeParams(state, {
      payload
    }) {
      return {
        ...state,
        typeParams: payload || {},
      }
    },
    changeIsIndex(state, {
      payload
    }) {
      return {
        ...state,
        isIndex: payload,
      }
    },
    changeSignSearch(state, {
      payload
    }) {
      const data = payload || signSearch;
      return {
        ...state,
        signSearch: {
          ...state.signSearch,
          ...data,
        },
      };
    },
    changeSearchFormFields(state, {
      payload
    }) {
      const data = payload || searchData;
      return {
        ...state,
        searchData: {
          ...state.searchData,
          pageNum: 1,
          ...data,
        },
      };
    },
    resetSearchData(state, {
      payload
    }) {
      return {
        ...state,
        searchData: payload || searchData,
      };
    },
    changeFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload,
      }
    },
    changeZCheckFormData(state, {
      payload
    }) {
      return {
        ...state,
        zcheckFormData: payload,
      }
    },
    changeSignFormData(state, {
      payload
    }) {
      return {
        ...state,
        signFormData: payload,
      }
    },
    resetFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload || formData,
      };
    },
    changeSelectedRows(state, {
      payload
    }) {
      return {
        ...state,
        selectedRows: payload,
      }
    }
  },
};
