import {
  queryFruit,
  removeFruit,
  addFruit,
  getFCharts
} from '@/services/api';
import {
  pagination,
  filterEmpty,
} from '@/utils/utils';

const searchData = pagination({});

const formData = {};
const data = {
  list: [],
  pagination: {},
};

export default {
  namespace: 'fapply',

  state: {
    data,
    searchData,
    formData,
    selectedRows: [],
    typeParams:{},
    FCharts:[],
    isIndex: true, // 标识是否是每个标签页在切换s
  },

  effects: {
    * fetch(_, {
      call,
      put,
      select
    }) {
      const searchParams = yield select(state => state.fapply.searchData);
      const typeParams = yield select(state => state.fapply.typeParams);
      const response = yield call(queryFruit, filterEmpty({
        ...searchParams,
        ...typeParams,
      }));
      yield put({
        type: 'save',
        payload: response.data,
      });
      return response;
    },
    * fetchFCharts({payload}, {
      call,
      put
    }) {
      const response = yield call(getFCharts,payload);
      yield put({
        type: 'saveFCharts',
        payload: response.data,
      });
    },
    * add(_, {
      call,
      select
    }) {
      const params = yield select(state => state.fapply.formData);
      const response = yield call(addFruit, params);

      return response;
    },
    * remove({
      payload,
      callback
    }, {
      call,
      put
    }) {
      const response = yield call(removeFruit, {
        Id: payload.Id
      });

      if (callback) callback();
      return response;
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: {
          list: action.payload.list,
          pagination: {
            total: action.payload.total,
            pageSize: parseInt(action.payload.pageSize, 10),
            current: parseInt(action.payload.pageNum, 10),
          }
        },
      };
    },
    saveFCharts(state, {
      payload
    }) {
      return {
        ...state,
        FCharts: payload || [],
      };
    },
    resetList(state) {
      return {
        ...state,
        data
      }
    },
    saveTypeParams(state, {
      payload
    }) {
      return {
        ...state,
        typeParams: payload || {},
      }
    },
    changeIsIndex(state, {
      payload
    }) {
      return {
        ...state,
        isIndex: payload,
      }
    },
    changeSearchFormFields(state, {
      payload
    }) {
      let result = payload || searchData;
      return {
        ...state,
        searchData: {
          ...state.searchData,
          pageNum: 1,
          ...result,
        },
      };
    },
    resetSearchData(state, {
      payload
    }) {
      return {
        ...state,
        searchData: {
          ...searchData,
          ...payload,
        },
      };
    },
    changeFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload,
      }
    },
    resetFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload || formData,
      };
    },
    changeSelectedRows(state, {
      payload
    }) {
      return {
        ...state,
        selectedRows: payload,
      }
    }
  },
};
