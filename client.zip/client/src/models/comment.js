import {
  queryComment,
  removeComment,
  addComment,
} from '@/services/api';
import {
  pagination,
  filterEmpty,
} from '@/utils/utils';

const searchData = pagination({});

const formData = {};

export default {
  namespace: 'comment',

  state: {
    data: {
      list: [],
      total:0,
    },
    searchData,
    formData,
    selectedRows: [],
  },

  effects: {
    * fetch(_, {
      call,
      put,
      select
    }) {
      const params = yield select(state => state.comment.searchData);
      const response = yield call(queryComment, filterEmpty(params));
      yield put({
        type: 'save',
        payload: response.data,
      });
      return response;
    },
    * add(_, {
      call,
      select
    }) {
      const params = yield select(state => state.comment.formData);
      const response = yield call(addComment, params);

      return response;
    },
    * remove({
      payload,
      callback
    }, {
      call,
      put
    }) {
      const response = yield call(removeComment, {
        Id: payload
      });

      if (callback) callback();
      return response;
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: {
          list: state.data.list.concat(action.payload.list || []),
          total:action.payload.total,
        },
      };
    },
    saveList(state) {
      return {
        ...state,
        data: {
          list: [],
          total:0,
        }
      }
    },
    changeSearchFormFields(state, {
      payload
    }) {
      const data = payload || searchData;
      return {
        ...state,
        searchData: {
          ...state.searchData,
          pageNum: 1,
          ...data,
        },
      };
    },
    resetSearchData(state, {
      payload
    }) {
      return {
        ...state,
        searchData: payload || searchData,
      };
    },
    changeFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload,
      }
    },
    resetFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload || formData,
      };
    },
    changeSelectedRows(state, {
      payload
    }) {
      return {
        ...state,
        selectedRows: payload,
      }
    }
  },
};
