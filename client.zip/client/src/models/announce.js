import { addAnnounce, queryAnnounce, removeAnnounce } from '@/services/api';
import { filterEmpty, formatObj, pagination } from '@/utils/utils';

const searchData = pagination({});

const formData = {};

const data = {
  list: [],
  pagination: {},
};

export default {
  namespace: 'announce',

  state: {
    data,
    searchData,
    formData,
    selectedRows: [],
  },

  effects: {
    * fetch(_, {
      call,
      put,
      select
    }) {
      const params = yield select(state => state.announce.searchData);
      const response = yield call(queryAnnounce, filterEmpty(params));
      yield put({
        type: 'save',
        payload: response.data,
      });
    },
    * add(_, {
      call,
      select
    }) {
      const params = yield select(state => state.announce.formData);
      const response = yield call(addAnnounce, formatObj(params));
      return response;
    },
    * remove({
      payload
    }, {
      call,
    }) {
      const response = yield call(removeAnnounce, {
        Id: payload.Id
      });
      return response;
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: {
          list: action.payload.list,
          pagination: {
            total: action.payload.total,
            pageSize: parseInt(action.payload.pageSize, 10),
            current: parseInt(action.payload.pageNum, 10),
          }
        },
      };
    },
    resetList(state) {
      return {
        ...state,
        data
      };
    },
    changeSearchFormFields(state, {
      payload
    }) {
      const data = payload || searchData;
      return {
        ...state,
        searchData: {
          ...state.searchData,
          pageNum: 1,
          ...data,
        },
      };
    },
    resetSearchData(state, {
      payload
    }) {
      return {
        ...state,
        searchData: payload || searchData,
      };
    },
    changeFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: {
          ...state.formData,
          ...payload,
        }
      }
    },
    resetFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload || formData,
      };
    },
    changeSelectedRows(state, {
      payload
    }) {
      return {
        ...state,
        selectedRows: payload,
      }
    },
  },
};
