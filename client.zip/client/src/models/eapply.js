import {
  queryExpenditure,
  removeExpenditure,
  addExpenditure,
  getECharts
} from '@/services/api';
import {
  pagination,
  filterEmpty,
} from '@/utils/utils';

const searchData = pagination({});

const formData = {};

const data = {
  list: [],
  pagination: {},
}

export default {
  namespace: 'eapply',

  state: {
    data,
    searchData,
    formData,
    selectedRows: [],
    typeParams: {},
    EBar: [], // 图表数据
    isIndex: true, // 标识是否是每个标签页在切换
  },

  effects: {
    * fetch(_, {
      call,
      put,
      select
    }) {
      const searchParams = yield select(state => state.eapply.searchData);
      const typeParams = yield select(state => state.eapply.typeParams);
      const response = yield call(queryExpenditure, filterEmpty({
        ...typeParams,
        ...searchParams,
      }));
      yield put({
        type: 'save',
        payload: response.data,
      });
    },
    * fetchEBar(_, {
      call,
      put
    }) {
      const response = yield call(getECharts);
      yield put({
        type: 'saveEBar',
        payload: response.data,
      });
    },
    * add(_, {
      call,
      select
    }) {
      const params = yield select(state => state.eapply.formData);
      const response = yield call(addExpenditure, params);

      return response;
    },
    * remove({
      payload,
      callback
    }, {
      call
    }) {
      const response = yield call(removeExpenditure, {
        Id: payload.Id
      });

      if (callback) callback();
      return response;
    },
  },
  reducers: {
    save(state, action) {
      return {
        ...state,
        data: {
          list: action.payload.list || [],
          pagination: {
            total: action.payload.total,
            pageSize: parseInt(action.payload.pageSize, 10),
            current: parseInt(action.payload.pageNum, 10),
          }
        },
      };
    },
    saveEBar(state, {
      payload
    }) {
      return {
        ...state,
        EBar: payload || [],
      };
    },
    resetList(state) {
      return {
        ...state,
        data,
      };
    },
    saveTypeParams(state, {
      payload
    }) {
      return {
        ...state,
        typeParams: payload || {},
      }
    },
    changeIsIndex(state, {
      payload
    }) {
      return {
        ...state,
        isIndex: payload,
      }
    },
    changeSearchFormFields(state, {
      payload
    }) {
      const data = payload || searchData;
      return {
        ...state,
        searchData: {
          ...state.searchData,
          pageNum: 1,
          ...data,
        },
      };
    },
    resetSearchData(state, {
      payload
    }) {
      return {
        ...state,
        searchData:{
          ...searchData,
          ...payload,
        },
      };
    },
    changeFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload,
      }
    },
    resetFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload || formData,
      };
    },
    changeSelectedRows(state, {
      payload
    }) {
      return {
        ...state,
        selectedRows: payload,
      }
    }
  },
};
