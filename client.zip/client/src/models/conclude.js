import {
  queryConclude,
  removeConclude,
  addConclude,
  getPCCharts
} from '@/services/api';
import {
  pagination,
  filterEmpty,
} from '@/utils/utils';

const searchData = pagination({});

const formData = {};

const data = {
  list: [],
  pagination: {},
}

export default {
  namespace: 'conclude',

  state: {
    data,
    searchData,
    formData,
    selectedRows: [],
    typeParams:{},
    PCBar:[],
    isIndex: true, // 标识是否是每个标签页在切换
  },

  effects: {
    * fetch(_, {
      call,
      put,
      select
    }) {
      const searchParams = yield select(state => state.conclude.searchData);
      const typeParams = yield select(state => state.conclude.typeParams);
      const response = yield call(queryConclude, filterEmpty({
        ...typeParams,
        ...searchParams,
      }));
      yield put({
        type: 'save',
        payload: response.data,
      });
    },
    * fetchPCBar(_, {
      call,
      put
    }) {
      const response = yield call(getPCCharts);
      yield put({
        type: 'savePCBar',
        payload: response.data,
      });
    },
    * add(_, {
      call,
      select
    }) {
      const params = yield select(state => state.conclude.formData);
      const response = yield call(addConclude, params);

      return response;
    },
    * remove({
      payload,
      callback
    }, {
      call
    }) {
      const response = yield call(removeConclude, {
        Id: payload.Id
      });

      if (callback) callback();
      return response;
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: {
          list: action.payload.list,
          pagination: {
            total: action.payload.total,
            pageSize: parseInt(action.payload.pageSize, 10),
            current: parseInt(action.payload.pageNum, 10),
          }
        },
      };
    },
    savePCBar(state, {
      payload
    }) {
      return {
        ...state,
        PCBar: payload || [],
      };
    },
    resetList(state) {
      return {
        ...state,
        data,
      }
    },
    saveTypeParams(state, {
      payload
    }) {
      return {
        ...state,
        typeParams: payload || {},
      }
    },
    changeIsIndex(state, {
      payload
    }) {
      return {
        ...state,
        isIndex: payload,
      }
    },
    changeSearchFormFields(state, {
      payload
    }) {
      const data = payload || searchData;
      return {
        ...state,
        searchData: {
          ...state.searchData,
          pageNum: 1,
          ...data,
        },
      };
    },
    resetSearchData(state, {
      payload
    }) {
      return {
        ...state,
        searchData: {
          ...searchData,
          ...payload,
        },
      };
    },
    changeFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload,
      }
    },
    resetFormData(state, {
      payload
    }) {
      return {
        ...state,
        formData: payload || formData,
      };
    },
    changeSelectedRows(state, {
      payload
    }) {
      return {
        ...state,
        selectedRows: payload,
      }
    }
  },
};
