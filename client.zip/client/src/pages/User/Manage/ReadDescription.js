import { Drawer, Row, Avatar } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';

const ROLE = {
  'G': '管理员',
  'J': '教师',
  'Z': '专家'
};

@connect(({ user }) => ({
  record: user.formData,
  personSelect: user.personSelect
}))
class ReadDescription extends PureComponent {

  render() {
    const { record, visible, onClose, personSelect } = this.props;
    const contentTitle = {
      'Id': '编号',
      'name': '姓名',
      'role': '角色',
      'age': '年龄',
      'education': '学历',
      'phone_num': '联系方式',
      'identify_num': '身份证号',
      'checkman_id': '审核人',
      'address': '通讯地址',
      'check_time': '审核时间',
      'introduce': '自我介绍',
      'is_passed': '是否通过'
    };
    const DescriptionItem = ({ title, content }) => (
      <div
        style={{
          fontSize: 14,
          lineHeight: '22px',
          marginBottom: 7,
          color: 'rgba(0,0,0,0.65)',
        }}
      >
        <p
          style={{
            marginRight: 8,
            display: 'inline-block',
            color: 'rgba(0,0,0,0.85)',
          }}
        >
          {title}:
        </p>
        {content}
      </div>
    );

    return (
      <Drawer
        destroyOnClose
        title={`${record ?.name}-详情`}
        placement="right"
        closable={false}
        onClose={onClose}
        visible={visible}
        width={500}
      >
        <Row>
          <DescriptionItem title='头像' content={<Avatar src={record.avatar ? `${window.location.origin}/server/api/file/download/avatar&${record.avatar}` : 'https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png'} alt={record ?.name} />} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.Id} content={record ?.Id} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.name} content={record ?.name} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.role} content={ROLE[record ?.role]} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.age} content={record ?.age || '尚未填写'} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.education} content={record ?.education || '尚未填写'} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.phone_num} content={record ?.phone_num || '尚未填写'} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.identify_num} content={record ?.identify_num || '尚未填写'} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.address} content={record ?.address || '尚未填写'} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.introduce} content={record.introduce || '尚未填写'} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.is_passed} content={record ?.is_passed !== null ? (record ?.is_passed ? '是' : '否') : '尚未审核'} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.checkman_id} content={record ?.checkman_id !== null ? personSelect[record ?.checkman_id] : '尚未审核'} />
        </Row>
        <Row>
          <DescriptionItem title={contentTitle.check_time} content={record ?.check_time !== null ? moment(record ?.check_time).format('YYYY-MM-DD HH:mm:ss') : '尚未审核'} />
        </Row>
      </Drawer>
    );
  }
}

export default ReadDescription;