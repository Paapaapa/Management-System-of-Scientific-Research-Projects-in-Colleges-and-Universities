import { Modal, Select, Form, message, Input } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';

const { Option } = Select;
const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ user }) => ({
  currentUser: user.currentUser,
  formData: user.formData,
}))
@Form.create()
class Check extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      formData,
      currentUser
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'user/changeFormData',
        payload: {
          ...formData,
          ...fieldsValue,
          ucheck_time: moment().format('YYYY-MM-DD HH:mm:ss'),
          role: fieldsValue.is_ucheck_pass === '0' ? formData.role : formData.upgrade_level,
          ucheckman_id: currentUser.Id,
        },
      });
      dispatch({
        type: 'user/add',
      }).then(res => {
        if (res.code === 1) {
          onCancel();
          message.success("审核成功");
          dispatch({
            type: 'user/fetch',
          });
        } else {
          message.error("审核失败");
        }
      });
    });
  };

  render() {
    const { visible, onCancel, form, formData } = this.props;

    return (
      <Modal
        destroyOnClose
        title="审核职位"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="是否通过">
          {form.getFieldDecorator('is_ucheck_pass', {
            rules: [{ required: true, message: '必选' }],
            initialValue: formData.is_ucheck_pass == 0 || formData.is_ucheck_pass ? String(formData.is_ucheck_pass) : '',
          })(<Select
            style={{ width: 200 }}
            placeholder="请选择"
          >
            <Option value="0">不同意</Option>
            <Option value="1">同意</Option>
          </Select>)}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="审核意见">
          {form.getFieldDecorator('ucheck_comment', {
            rules: [{ required: true, message: '必填' }],
            initialValue: formData ?.ucheck_comment
          })(<TextArea
              style={{ minHeight: 32 }}
              placeholder='请输入审核意见'
              rows={4}
            />)}
        </FormItem>
      </Modal>
    );
  };
};

export default Check;