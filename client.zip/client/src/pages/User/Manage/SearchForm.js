import { Form, Row, Col, AutoComplete, Button, Icon, DatePicker, Select, Input } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';

const FormItem = Form.Item;
const { Option } = Select;
const { RangePicker } = DatePicker;

@connect(({ user }) => ({
  personSelect: user.personSelect,
}))
@Form.create()
class SearchForm extends PureComponent {
  state = {
    principalData: [],
    expandForm: false,
  };

  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    dispatch({
      type: 'user/resetSearchData',
    });
    dispatch({
      type: 'user/fetch',
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleSearch = (e) => {
    e.preventDefault();
    const { dispatch, form, personSelect } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      Object.keys(personSelect).forEach((val) => {
        personSelect[val] === values.checkman_id && (values.checkman_id = val);
      });
      dispatch({
        type: 'user/resetSearchData',
        payload: {
          ...values,
          check_time: values.check_time ? [values.check_time[0].format('YYYY-MM-DD'), values.check_time[1].format('YYYY-MM-DD')].toString() : '',
        },
      });
      dispatch({
        type: 'user/fetch',
      });
    });
  };

  handleAutoSearch = (value, data) => {
    if (value !== '') {
      const dataSource = [];
      Object.keys(data).forEach((val) => {
        if (data[val].indexOf(value) > -1) dataSource.push(data[val]);
      });
      this.setState({
        principalData: dataSource,
      });
    }
  };

  renderSimpleForm() {
    const {
      form: { getFieldDecorator }
    } = this.props;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="编号">
              {getFieldDecorator('Id')(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="姓名">
              {getFieldDecorator('name')(
                <Input placeholder="请输入" />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <div style={{ overflow: 'hidden', float: 'right' }}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
              <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
                展开 <Icon type="down" />
              </a>
            </div>
          </Col>
        </Row>
      </Form>
    );
  };

  renderAdvancedForm() {
    const {
      form: { getFieldDecorator }, personSelect
    } = this.props;
    const { principalData } = this.state;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="编号">
              {getFieldDecorator('Id')(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="姓名">
              {getFieldDecorator('name')(
                <Input placeholder="请输入" />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="角色">
              {getFieldDecorator('role')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="G">管理员</Option>
                  <Option value="J">教师</Option>
                  <Option value="Z">专家</Option>
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="学历">
              {getFieldDecorator('education')(
                <Select>
                  <Option value="博士">博士</Option>
                  <Option value="硕士">硕士</Option>
                  <Option value="本科">本科</Option>
                  <Option value="专科">专科</Option>
                  <Option value="高中">高中</Option>
                  <Option value="初中">初中</Option>
                  <Option value="中专">中专</Option>
                  <Option value="小学">小学</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="是否通过">
              {getFieldDecorator('is_passed')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option key="0">否</Option>
                  <Option key="1">是</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="审核时间">
              {getFieldDecorator('check_time')(
                <RangePicker />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="审核人">
              {getFieldDecorator('checkman_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={16} sm={24}>
            <div style={{ overflow: 'hidden', float: 'right' }}>
              <div style={{ marginBottom: 24 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                  重置
                </Button>
                <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
                  收起 <Icon type="up" />
                </a>
              </div>
            </div>
          </Col>
        </Row>
      </Form>
    );
  }

  render() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }
};

export default SearchForm;