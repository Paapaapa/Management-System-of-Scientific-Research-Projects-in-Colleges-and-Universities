import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import StandardTable from '@/components/StandardTable';
import { Button, Card, Divider, Dropdown, Icon, Menu, message, Popconfirm, Radio, Modal, Row, Col } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { Fragment, PureComponent } from 'react';
import styles from './Manage.less';
import ReadDescription from './ReadDescription';
import SearchForm from './SearchForm';
import CheckForm from './CheckForm';
import { formatObj } from '@/utils/utils';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const { confirm } = Modal;
const ROLE = {
  'G': '管理员',
  'J': '教师',
  'Z': '专家'
};
const PROGRESS = ['等待审核', '审核通过', '审核不通过'];


@connect(({ user, loading }) => ({
  user,
  loading: loading.models.rule,
  currentUser: user.currentUser,
}))
class Manage extends PureComponent {
  state = {
    menuVal: '',
    readVisible: false,
    checkVisible: false,
    key: 'all',
  };

  columns = [
    {
      title: '编号',
      dataIndex: 'Id',
      sorter: true,
    },
    {
      title: '姓名',
      dataIndex: 'name',
      sorter: true,
    },
    {
      title: '角色',
      dataIndex: 'role',
      sorter: true,
      render: text => ROLE[text],
    },
    {
      title: '操作',
      render: (text, record) => {
        const { currentUser } = this.props;
        const { key } = this.state;
        const showConfirm = (e) => {
          confirm({
            title: `您确定设置${record.name}为${ROLE[e.key]}吗？`,
            onOk: () => {
              this.handleSRole(record, e);
            },
            okText: '确定',
            cancelText: '取消',
          });
        }
        const menu = (
          <Menu onClick={(e) => showConfirm(e)}>
            <Menu.Item key="Z">专家</Menu.Item>
            <Menu.Item key="J">教师</Menu.Item>
          </Menu>);
        const renderBtn = {
          'divider': <Divider type="vertical" />,
          'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
          'set': <Dropdown overlay={menu}>
            <Button>
              设置为<Icon type="down" />
            </Button>
          </Dropdown>,
          'logout': <Popconfirm onConfirm={() => this.handleLogout(record)} okText='确定' cancelText='取消' title='您确定注销此用户吗？' ><a href="#">注销</a></Popconfirm>,
          'remain': <Popconfirm onConfirm={() => this.handleRemain(record)} okText='确定' cancelText='取消' title='您确定恢复此用户吗？' ><a href='#'>恢复</a></Popconfirm>,
          'remove': <Popconfirm onConfirm={() => this.handleRemove(record)} okText='确定' cancelText='取消' title='您确定彻底删除此用户吗？' ><a href='#'>彻底删除</a></Popconfirm>,
          'Rpass': <Popconfirm onConfirm={() => this.handleCheck(true, record)} okText='确定' cancelText='取消' title='您确定同意此用户的注册申请吗？' ><a href='#'>同意</a></Popconfirm>,
          'Rreject': <Popconfirm onConfirm={() => this.handleCheck(false, record)} okText='确定' cancelText='取消' title='您确定驳回此用户的注册申请吗？' ><a href='#'>驳回</a></Popconfirm>,
          'readUpgrade': <a onClick={() => this.handleDetail(record)}>查看申请详情</a>,
          'ucheck': <a onClick={() => this.handleCheckVisible(true, record)}>{record.ucheck_time ? '重新审核' : '审核'}</a>,
        }
        return (
          <>
            {renderBtn.read}
            {key === 'all' && record.del_flag === 0 && record.role !== 'G' ? <>
              {renderBtn.divider}{renderBtn.set}{renderBtn.divider}{renderBtn.logout}
            </> : null}
            {key === 'all' && record.del_flag === 1 && record.role !== 'G' ? <>
              {renderBtn.divider}{renderBtn.remain}{renderBtn.divider}{renderBtn.remove}
            </> : null}
            {key === 'noRCheck' ? <>
              {renderBtn.divider}{renderBtn.Rpass}{renderBtn.divider}{renderBtn.Rreject}
            </> : null}
            {key === 'noUCheck' ? <>
              {renderBtn.divider}{renderBtn.readUpgrade}{renderBtn.divider}{renderBtn.ucheck}
            </> : null}
          </>
        );
      },
    },
  ];

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'user/fetchSelect',
    });
    this.handleClick({
      key: this.state.key,
    });
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'user/resetSearchData',
    });
    dispatch({
      type: 'user/resetList',
    });
    dispatch({
      type: 'user/saveTypeParams',
    });
  }

  handleSRole = (record, e) => {
    const {
      dispatch
    } = this.props;
    if (record)
      dispatch({
        type: 'user/changeFormData',
        payload: {
          ...formatObj(record),
          role: e.key,
        },
      });
    dispatch({
      type: 'user/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success("设置成功");
        this.doPageSearch();
      } else {
        message.error("设置失败");
      }
    });
  }

  handleDetail = (record) => {
    const { user: { personSelect } } = this.props;
    Modal.info({
      title: '申请详情',
      content: (
        <div style={{ marginTop: '16px' }}>
          <div>
            <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>申请职位：</span>
            {ROLE[record ?.upgrade_level]}
          </div>
          <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
          <div>
            <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>申请理由：</span><br />
            {record ?.upgrade_reason}
          </div>
          {
            record.is_ucheck_pass !== null ? <>
              <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
              <div>
                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>状态：</span>
                {record ?.is_ucheck_pass == 0 ? '驳回' : '已同意'}
              </div>
              <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
              <div>
                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>审核人员：</span>
                {personSelect[record ?.ucheckman_id]}
              </div>
              <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
              <div>
                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>审核意见：</span><br />
                {record ?.ucheck_comment}
              </div>
              <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
              <div>
                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>审核时间：</span>
                {moment(record ?.ucheck_time).format('YYYY-MM-DD HH:mm:ss')}
              </div>
            </> : null
          }
        </div>
      ),
      okText: '关闭'
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const params = {
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'user/changeSearchFormFields',
      payload: params,
    })
    this.doPageSearch();
  };

  handleReadVisible = (flag, record) => {
    const { dispatch } = this.props;
    this.setState({
      readVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'user/changeFormData',
        payload: {
          ...record,
        },
      });
  }

  handleCheckVisible = (flag, record) => {
    const { dispatch } = this.props;
    this.setState({
      checkVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'user/changeFormData',
        payload: record,
      });
  }

  handleRefresh = () => {
    this.doPageSearch();
  }

  handleClick = (e) => {
    const { dispatch } = this.props;
    const params = {};
    this.setState({
      key: e.key,
    });
    switch (e.key) {
      case 'noRCheck':
        params.is_passed = 'null';
        params.del_flag = 0;
        this.setState({
          menuVal: 'noRCheck',
        })
        break;
      case 'noUCheck':
        params.upgrade_level = 'notNull';
        params.ucheck_time = 'null';
        params.del_flag = 0;
        this.setState({
          menuVal: 'noUCheck',
        })
        break;
      default:
        params.is_passed = 1;
        params.del_flag = 0;
        this.setState({
          menuVal: 'normal',
        })
        break;
    }
    dispatch({
      type: 'user/saveTypeParams',
      payload: params,
    });
    this.doPageSearch();
  }

  handleRadioGroup = (e) => {
    const {
      dispatch, currentUser
    } = this.props;
    const params = {};
    this.setState({
      menuVal: e.target.value,
    });
    switch (e.target.value) {
      case 'noRCheck':
        params.is_passed = 'null';
        params.del_flag = 0;
        break;
      case 'noUCheck':
        params.upgrade_level = 'notNull';
        params.ucheck_time = 'null';
        params.del_flag = 0;
        break;
      case 'RChecked':
        params.checkman_id = currentUser.Id;
        params.check_time = 'notNull';
        params.del_flag = 0;
        break;
      case 'UChecked':
        params.ucheckman_id = currentUser.Id;
        params.ucheck_time = 'notNull';
        params.del_flag = 0;
        break;
      case 'logouted':
        params.del_flag = 1;
        break;
      default:
        params.is_passed = 1;
        params.del_flag = 0;
        break;
    }
    dispatch({
      type: 'user/saveTypeParams',
      payload: params,
    });
    this.doPageSearch();
  }

  handleCheck = (flag, record) => {
    const {
      dispatch, currentUser
    } = this.props;
    if (record)
      dispatch({
        type: 'user/changeFormData',
        payload: {
          ...formatObj(record),
          check_time: moment().format('YYYY-MM-DD HH:mm:ss'),
          is_passed: flag,
          checkman_id: currentUser.Id,
        },
      });
    dispatch({
      type: 'user/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success("审核成功");
        this.doPageSearch();
      } else {
        message.error("审核失败");
      }
    });
  };

  handleLogout = (record) => {
    const {
      dispatch
    } = this.props;
    if (record)
      dispatch({
        type: 'user/changeFormData',
        payload: {
          ...formatObj(record),
          del_flag: 1,
        },
      });
    dispatch({
      type: 'user/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success("注销成功");
        this.doPageSearch();
      } else {
        message.error("注销失败");
      }
    });
  }

  handleRemove(record) {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'user/remove',
      payload: record,
    }).then((res) => {
      if (res.code === 1) {
        message.success("删除成功");
        this.doPageSearch();
      } else {
        message.error("删除失败");
      }
    });
  }

  handleRemain(record) {
    const {
      dispatch
    } = this.props;
    if (record)
      dispatch({
        type: 'user/changeFormData',
        payload: {
          ...formatObj(record),
          del_flag: 0,
        },
      });
    dispatch({
      type: 'user/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success("恢复成功");
        this.doPageSearch();
      } else {
        message.error("恢复失败");
      }
    });
  }

  doPageSearch() {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'user/fetch',
    });
  }

  render() {
    const {
      user: { data },
      loading
    } = this.props;
    const { selectedRows, menuVal, readVisible, checkVisible, key } = this.state;
    data.pagination = {
      ...data.pagination,
      showTotal: total => `总计 ${total} 条数据`,
      pageSizeOptions: ['10', '20', '30'],
    };
    return (
      <PageHeaderWrapper title="人员管理">
        <Card bordered={false}>
          <Row gutter={20}>
            <Col span={4} >
              <Menu onClick={this.handleClick} mode="vertical" defaultSelectedKeys={["all"]}>
                <Menu.Item key="all">全部人员</Menu.Item>
                <Menu.Item key="noRCheck">注册审核</Menu.Item>
                <Menu.Item key="noUCheck">职位审核</Menu.Item>
              </Menu>
            </Col>
            <Col span={20} >
              <div className={styles.tableList}>
                <div className={styles.tableListForm}>
                  <SearchForm />
                </div>
                <div className={styles.tableListOperator}>
                  <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                    刷新
                  </Button>
                  <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                    {key === 'all' ? (<>
                      <RadioButton value="normal">正常状态</RadioButton>
                      <RadioButton value="logouted">注销状态</RadioButton>
                    </>) : null}
                    {key === 'noRCheck' ? (<>
                      <RadioButton value="noRCheck">待处理</RadioButton>
                      <RadioButton value="RChecked">已处理</RadioButton>
                    </>) : null}
                    {key === 'noUCheck' ? (<>
                      <RadioButton value="noUCheck">待处理</RadioButton>
                      <RadioButton value="UChecked">已处理</RadioButton>
                    </>) : null}
                  </RadioGroup>
                </div>
                <StandardTable
                  selectedRows={[]}
                  loading={loading}
                  data={data}
                  columns={this.columns}
                  onChange={this.handleStandardTableChange}
                  rowKey={record => record.Id}
                />
              </div>
            </Col>
          </Row>
        </Card>
        <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
        <CheckForm visible={checkVisible} onCancel={() => this.handleCheckVisible(false)} />
      </PageHeaderWrapper>
    );
  }
}

export default Manage;
