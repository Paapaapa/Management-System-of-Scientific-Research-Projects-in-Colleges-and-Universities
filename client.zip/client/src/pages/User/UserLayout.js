import React, { Component } from 'react';
import styles from './Login/Login.less';
import Link from 'umi/link';
import logo from '../../assets/logo.svg';

class App extends Component {

  render() {
    const { children } = this.props;
    return (
      <div className={styles.container}>
        <div className={styles.content}>
          <div className={styles.top}>
            <div className={styles.header}>
              <Link to="/">
                <img alt="logo" className={styles.logo} src={logo} />
                <span className={styles.title}>高校科研项目管理系统</span>
              </Link>
            </div>
            <div className={styles.desc}>高校科研项目管理系统愿为广大教师和科研人员提供优质服务</div>
          </div>
          {children}
        </div>
      </div>
    );
  }
}

export default App;
