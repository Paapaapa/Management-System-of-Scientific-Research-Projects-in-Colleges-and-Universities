import React, { Component } from 'react';
import { connect } from 'dva';
import { formatMessage, FormattedMessage } from 'umi/locale';
import { Checkbox, Alert, message } from 'antd';
import Login from '@/components/Login';
import styles from './Login.less';
import Link from 'umi/link';
import logo from '../../../assets/logo.svg';
import Layout from '../UserLayout';

const { Tab, UserName, Password, Submit } = Login;

@connect(({ login, loading }) => ({
  login,
  submitting: loading.effects['login/login'],
}))
class LoginPage extends Component {
  state = {
    type: 'account',
    autoLogin: true,
  };

  componentDidMount() {
    // const cookie = document.cookie.indexOf(';')>-1?document.cookie.split(';') : [document.cookie];
    // if (cookie.length) {
    //   let temp=[];
    //   cookie.forEach((val,index)=>{
    //     if(val.indexOf('login')>-1) temp=cookie[index].split('=')[1];
    //   });
    //   temp=temp.indexOf('&')>-1?temp.split('&'):[temp];
    //   this.setState({
    //     autoLogin: temp[0] === 'false' ? false : true,
    //   });
    //   if (temp[1] && temp[2] && localStorage.getItem('antd-pro-authority') !== '["guest"]') {
    //     this.handleSubmit(undefined, {
    //       pid: temp[1],
    //       pwd: temp[2],
    //     });
    //   }
    // }
  }

  handleSubmit = (err, values) => {
    if (!err) {
      const { dispatch } = this.props;
      const { autoLogin } = this.state;
      dispatch({
        type: 'login/login',
        payload: {
          ...values,
        },
      }).then((res) => {
        res.status ? message.success(res.msg) : message.error(res.msg);
      });
      // if(autoLogin){
      //   const d = new Date();
      //   d.setTime(d.getTime()+(1*24*60*60*1000));
      //   const expires = `expires=${d.toGMTString()}`;
      //   document.cookie =`login=${autoLogin}&${values?.pid}&${values?.pwd};${expires}`;
      // }else{
      //   document.cookie =`login=${autoLogin};`;
      // }
    }
  };

  changeAutoLogin = e => {
    this.setState({
      autoLogin: e.target.checked,
    });
  };

  renderMessage = content => (
    <Alert style={{ marginBottom: 24 }} message={content} type="error" showIcon />
  );

  render() {
    const { login, submitting } = this.props;
    const { type, autoLogin } = this.state;
    return (
      <Layout>
          <div className={styles.main}>
            <Login
              defaultActiveKey={type}
              onSubmit={this.handleSubmit}
              ref={form => {
                this.loginForm = form;
              }}
            >
              <Tab key="account" tab="登录">
                <UserName
                  name="pid"
                  placeholder="请填写用户编号"
                  rules={[
                    {
                      required: true,
                      message: "必填",
                    },
                  ]}
                />
                <Password
                  name="pwd"
                  placeholder="请填写密码"
                  rules={[
                    {
                      required: true,
                      message: "必填",
                    },
                  ]}
                  onPressEnter={e => {
                    e.preventDefault();
                    this.loginForm.validateFields(this.handleSubmit);
                  }}
                />
              </Tab>
              <div style={{ lineHeight: '20px', height: '20px' }}>
                {/* <Checkbox checked={autoLogin} onChange={this.changeAutoLogin}>
              记住我
            </Checkbox> */}
                <Link style={{ float: 'right' }} to="/user/register">
                  注册
            </Link>
              </div>
              <Submit loading={submitting}>
                登录
          </Submit>
            </Login>
          </div>
          </Layout>
    );
  }
}

export default LoginPage;
