import React, { Component } from 'react';
import { Form, Input, Button, Radio, message, Modal } from 'antd';
import { connect } from 'dva';
import moment from 'moment';

const FormItem = Form.Item;
const SIMROLE = ['Z', 'J'];
const ROLE = {
  'Z': '专家',
  'J': '教师',
}

@connect(({ user }) => ({
  currentUser: user.currentUser,
  personSelect: user.personSelect,
}))
@Form.create()
class Personal extends Component {
  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'user/fetchSelect',
    })
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const {
      dispatch,
      form,
      currentUser
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'user/changeFormData',
        payload: {
          ...fieldsValue,
          Id: currentUser.Id,
          is_ucheck_pass: null,
          ucheckman_id: null,
          ucheck_time: null,
          ucheck_comment: null,
        },
      });
      dispatch({
        type: 'user/add',
      }).then((res) => {
        if (res.code === 1) {
          message.success("申请成功");
          dispatch({
            type: 'user/fetchCurrent',
          });
        } else {
          message.error("申请失败");
        }
      });
    });
  };

  handleDetail = () => {
    const { personSelect, currentUser: record } = this.props;
    Modal.info({
      title: '申请详情',
      content: (
        <div style={{ marginTop: '16px' }}>
          <div>
            <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>申请职位：</span>
            {ROLE[record ?.upgrade_level]}
          </div>
          <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
          <div>
            <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>申请理由：</span><br />
            {record ?.upgrade_reason}
          </div>
          {
            record.is_ucheck_pass !== null ? <>
              <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
              <div>
                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>状态：</span>
                {record ?.is_ucheck_pass == 0 ? '驳回' : '已同意'}
              </div>
              <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
              <div>
                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>审核人员：</span>
                {personSelect[record ?.ucheckman_id]}
              </div>
              <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
              <div>
                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>审核意见：</span><br />
                {record ?.ucheck_comment}
              </div>
              <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
              <div>
                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>审核时间：</span>
                {moment(record ?.ucheck_time).format('YYYY-MM-DD HH:mm:ss')}
              </div>
            </> : null
          }
        </div>
      ),
      okText: '关闭'
    });
  }

  render() {
    const {
      form: { getFieldDecorator }, currentUser: { role, upgrade_level }
    } = this.props;
    const formItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 10 },
    };

    return (
      <Form onSubmit={this.handleSubmit} hideRequiredMark>
        <p style={{ textAlign: 'center', margin: "20px 0" }}>您当前的职位是 <b>{ROLE[role]}</b>，您可以申请更换其他职位，申请请填写以下内容： </p>
        <FormItem label="职位" {...formItemLayout}>
          {getFieldDecorator('upgrade_level', {
            rules: [
              {
                required: true,
                message: '必选',
              },
            ],
          })(
            <Radio.Group>
              {SIMROLE.map(val => (val !== role ? <Radio key={val} value={val}>{ROLE[val]}</Radio> : null))}
            </Radio.Group>
          )}
        </FormItem>
        <FormItem label='申请理由' {...formItemLayout}>
          {getFieldDecorator('upgrade_reason', {
            rules: [
              {
                required: true,
                message: '必填',
              },
            ],
          })(
            <Input.TextArea
              placeholder='请填写申请理由'
              rows={4}
            />
          )}
        </FormItem>
        <div style={{ textAlign: 'center' }}>
          <Button type="primary" htmlType="submit">
            提交申请
          </Button>
          {upgrade_level ?
            <Button ghost onClick={this.handleDetail} style={{ marginLeft: '15px' }}>
              查看上一次申请
            </Button> : null}
        </div>
      </Form>
    );
  }
}

export default Personal;
