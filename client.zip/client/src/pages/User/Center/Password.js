import React, { Component } from 'react';
import { Form, Input, Button, message, Icon, Steps } from 'antd';
import { connect } from 'dva';
import styles from './Password.less';

const FormItem = Form.Item;
const { Step } = Steps;
const formItemLayout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 10 },
};

@connect(({ user }) => ({
  currentUser: user.currentUser,
}))
class Password extends Component {
  state = {
    current: 0,
  }

  firstStep = Form.create()(props => {
    const { form: { getFieldDecorator }, form } = props;
    const { currentUser } = this.props;
    const handleFirstSubmit = (e) => {
      e.preventDefault();
      form.validateFields((err, fieldsValue) => {
        if (err) return;
        if (fieldsValue.password === undefined || fieldsValue.password === '') {
          message.warning('不能为空');
          return;
        }
        if (fieldsValue.password === currentUser.password) this.next();
        else message.warning('原始密码错误');
      });
    }

    return (
      <Form layout='horizontal' onSubmit={handleFirstSubmit} hideRequiredMark>
        <FormItem label='原密码' {...formItemLayout}>
          {getFieldDecorator('password', {
            rules: [
              {
                required: true,
                message: '必填',
              },
            ]
          })(<Input.Password prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />} type="password" placeholder="请输入原始密码" />)}
        </FormItem>
        <div style={{ textAlign: 'center' }}>
          <Button type="primary" htmlType="submit">
            下一步
          </Button>
        </div>
      </Form>)
  });

  secondStep = Form.create()(props => {
    const { form: { getFieldDecorator }, form } = props;
    const { currentUser, dispatch } = this.props;
    const handleSecondSubmit = (e) => {
      e.preventDefault();
      form.validateFields((err, fieldsValue) => {
        if (err) return;
        if (fieldsValue.password !== fieldsValue.repassword) {
          message.warning('密码不一致，请检查');
          return;
        }
        dispatch({
          type: 'user/changeFormData',
          payload: {
            password: fieldsValue.password,
            Id: currentUser.Id,
          },
        });
        dispatch({
          type: 'user/add',
        }).then((res) => {
          if (res.code === 1) {
            this.next();
            dispatch({
              type: 'user/fetchCurrent',
            });
          } else {
            message.error("修改失败");
          }
        });
      });
    };

    return (
      <Form layout='horizontal' onSubmit={handleSecondSubmit} hideRequiredMark>
        <FormItem label='新密码' {...formItemLayout}>
          {getFieldDecorator('password',{
            rules:[
              {
                required:true,
                message:'必填'
              }
            ]
          })(
            <Input.Password prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />} type="password" placeholder="请输入新密码" />)}
        </FormItem>
        <FormItem label='确认密码' {...formItemLayout}>
          {getFieldDecorator('repassword',{
            rules:[
              {
                required:true,
                message:'必填'
              }
            ]
          })(
            <Input.Password prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />} type="password" placeholder="请再次输入新密码" />)}
        </FormItem>
        <div style={{ textAlign: 'center' }}>
          <Button style={{ marginRight: 8 }} onClick={() => this.prev()}>
            上一步
          </Button>
          <Button type="primary" htmlType="submit">
            下一步
          </Button>
        </div>
      </Form>)
  });

  steps = [{
    title: 'First',
    content: <this.firstStep />,
  }, {
    title: 'Second',
    content: <this.secondStep />,
  }, {
    title: 'Last',
    content:
      <div style={{ textAlign: 'center' }}>
        <Icon className={styles.icon} type="check-circle" theme="filled" /><br />
        <span className={styles.iconFont}>修改成功</span>
        <div>
          <Button style={{ marginRight: 8 }} onClick={() => this.prev()}>上一步</Button>
          <Button type="primary" onClick={() => this.setState({ current: 0 })}>重新修改</Button>
        </div>
      </div>,
  }];

  next() {
    const { current } = this.state;
    this.setState({ current: current + 1 });
  }

  prev() {
    const { current } = this.state;
    this.setState({ current: current - 1 });
  }

  render() {
    const { current } = this.state;

    return (
      <div style={{ width: '60%', margin: '20px auto' }}>
        <Steps current={current}>
          {this.steps.map(item => <Step key={item.title} title={item.title} />)}
        </Steps>
        <div className={styles['steps-content']}>{this.steps[current].content}</div>
      </div>
    );
  }
}

export default Password;
