import React, { Component, Fragment } from 'react';
import { Form, Input, Upload, Select, Button, Radio, InputNumber, message } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const { Option } = Select;
const uploadType = ['image/png', 'image/jpeg', 'image/gif', 'application/x-bmp'];

@connect(({ user }) => ({
  currentUser: user.currentUser,
}))
@Form.create()
class Personal extends Component {
  state = {
    fileList: [],
    imageUrl: 'https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png',
  }

  componentDidMount() {
    const { currentUser } = this.props;
    if (currentUser.avatar) {
      this.setState({
        imageUrl: `${window.location.origin}/server/api/file/download/avatar&${currentUser.avatar}`
      })
    }
  }

  renderAvatarView = () => {
    const { imageUrl } = this.state;
    const getBase64 = (img, callback) => {
      const reader = new FileReader();
      reader.addEventListener('load', () => callback(reader.result));
      reader.readAsDataURL(img);
    }
    const checkImage = (file) => {
      const isValid = uploadType.includes(file.type);
      if (!isValid) {
        message.error('只能上传png,gif,jpg,jpeg,jpe,bmp等常见格式的图片，请重新上传');
        return false;
      }
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isLt2M) {
        message.error('图片必须小于2M，请重新上传');
        return false;
      }
      return true;
    }
    const props = {
      beforeUpload: (file) => {
        if (checkImage(file))
          this.setState(state => ({
            fileList: [...state.fileList, file],
          }));

        return false;
      },
      onChange: (info) => {
        if (checkImage(info.file))
          getBase64(info.file, resultUrl => this.setState({
            imageUrl: resultUrl,
          }));
      },
      showUploadList: false,
    };

    return (
      <Fragment>
        <Upload {...props}>
          <img src={imageUrl} alt="avatar" width="100px" height="100px" style={{borderRadius: '50%'}} />
        </Upload>
      </Fragment>
    );
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const {
      dispatch,
      form
    } = this.props;
    const postData = new FormData();
    const {
      fileList
    } = this.state;
    fileList.forEach((file) => {
      postData.append('files', file);
    });
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      Object.keys(fieldsValue).forEach(val => {
        postData.append(val, fieldsValue[val]);
      });
      dispatch({
        type: 'user/changeFormData',
        payload: postData,
      });
      dispatch({
        type: 'user/add',
      }).then((res) => {
        if (res.code === 1) {
          message.success("修改成功");
          dispatch({
            type: 'user/fetchCurrent',
          });
        } else {
          message.error("修改失败");
        }
      });
    });
  };

  render() {
    const {
      form: { getFieldDecorator }, currentUser
    } = this.props;
    const formItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 8 },
    };

    return (
      <Form layout='horizontal' onSubmit={this.handleSubmit} hideRequiredMark>
        <FormItem label='头像' {...formItemLayout}>
          {this.renderAvatarView()}
        </FormItem>
        <FormItem label='编号' {...formItemLayout}>
          {getFieldDecorator('Id', {
            initialValue: currentUser ?.Id,
          })(<Input disabled />)}
        </FormItem>
        <FormItem label='姓名' {...formItemLayout}>
          {getFieldDecorator('name', {
            rules: [
              {
                required: true,
                message: '必填',
              },
            ],
            initialValue: currentUser ?.name,
          })(<Input allowClear />)}
        </FormItem>
        <FormItem label="角色" {...formItemLayout}>
          {getFieldDecorator('role', {
            initialValue: currentUser ?.role,
          })(
            <Radio.Group disabled >
              <Radio value="G">管理员</Radio>
              <Radio value="Z">专家</Radio>
              <Radio value="J">教师</Radio>
            </Radio.Group>
          )}
        </FormItem>
        <FormItem label='学历' {...formItemLayout}>
          {getFieldDecorator('education', {
            initialValue: currentUser ?.education,
          })(
            <Select>
              <Option key="博士">博士</Option>
              <Option key="硕士">硕士</Option>
              <Option key="本科">本科</Option>
              <Option key="专科">专科</Option>
              <Option key="高中">高中</Option>
              <Option key="初中">初中</Option>
              <Option key="中专">中专</Option>
              <Option key="小学">小学</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label='年龄' {...formItemLayout}>
          {getFieldDecorator('age', {
            initialValue: currentUser ?.age,
          })(<InputNumber min={0} />)}
        </FormItem>
        <FormItem label='联系方式' {...formItemLayout}>
          {getFieldDecorator('phone_num', {
            rules: [
              {
                required: true,
                message: '必填',
              },
            ],
            initialValue: currentUser ?.phone_num,
          })(<Input allowClear />)}
        </FormItem>
        <FormItem label='身份证号' {...formItemLayout}>
          {getFieldDecorator('identity_num', {
            initialValue: currentUser ?.identity_num,
          })(<Input allowClear />)}
        </FormItem>
        <FormItem label='通讯地址' {...formItemLayout}>
          {getFieldDecorator('address', {
            initialValue: currentUser ?.address,
          })(<Input allowClear />)}
        </FormItem>
        <FormItem label='自我介绍' {...formItemLayout}>
          {getFieldDecorator('introduce', {
            initialValue: currentUser ?.introduce,
          })(
            <Input.TextArea
              placeholder='请填写自我介绍'
              rows={4}
            />
          )}
        </FormItem>
        <div style={{ textAlign: 'center' }}>
          <Button type="primary" htmlType="submit">
            更新
          </Button>
        </div>
      </Form>
    );
  }
}

export default Personal;
