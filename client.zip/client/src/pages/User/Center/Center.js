import { Tabs, Card } from 'antd';
import { connect } from 'dva';
import React, { Component } from 'react';
import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import Personal from './Personal';
import Password from './Password';
import Upgrade from './Upgrade';

const { TabPane } = Tabs;

@connect(({ user }) => ({
  user,
}))
class Center extends Component {
  render() {
    const { user: { currentUser } } = this.props;
    return (
      <PageHeaderWrapper title="个人中心">
        <Card bordered={false}>
          <Tabs defaultActiveKey="1" size="large">
            <TabPane tab="个人资料" key="1">
              <Personal />
            </TabPane>
            <TabPane tab="密码修改" key="2">
              <Password />
            </TabPane>
            {currentUser.role !== 'G' ? <TabPane tab="职位通道" key="3">
              <Upgrade />
            </TabPane> : null}
          </Tabs>
        </Card>
      </PageHeaderWrapper>
    );
  }
}

export default Center;