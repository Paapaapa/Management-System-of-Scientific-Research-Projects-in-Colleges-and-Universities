import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import StandardTable from '@/components/StandardTable';
import { Button, Card, Divider, Dropdown, Form, Icon, Menu, message, Popconfirm } from 'antd';
import { connect } from 'dva';
import Link from 'umi/link';
import React, { Fragment, PureComponent } from 'react';
import styles from './Notice.less';
import SearchForm from './SearchForm';

const TYPE = ['项目申报', '项目开题', '中期检查', '项目结题','项目中止', '经费', '成果'];
const URL = ['/project/apply', '/project/excute/proposal', '/project/excute/midcheck', '/project/excute/conclude', '/expenditure', '/fruit'];

@connect(({ notice, loading, user }) => ({
  notice,
  loading: loading.models.rule,
  personSelect: user.personSelect,
  currentUser: user.currentUser,
}))
@Form.create()
class Notice extends PureComponent {
  state = {
    selectedRows: [],
  };

  columns = [
    {
      title: '内容',
      dataIndex: 'content',
    },
    {
      title: '类型',
      dataIndex: 'type',
      sorter: true,
      render: text => TYPE[text[0]],
    },
    {
      title: '状态',
      dataIndex: 'is_read',
      sorter: true,
      render: text => text ? '已读' : '未读',
    },
    {
      title: '发送人',
      dataIndex: 'sendman_id',
      sorter: true,
      render: text => {
        const { personSelect } = this.props;
        return text ? personSelect[text] : '系统';
      },
    },
    {
      title: '操作',
      render: (text, record) => {
        const { currentUser } = this.props;
        return (<>
          {record.is_read === 0 ? (<a onClick={() => this.handleRead(record)}>标为已读</a>)
            : (<Popconfirm title="您确定删除吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消"><a href="#">删除</a></Popconfirm>)}
          <Divider type="vertical" />
          <Link to={`${URL[record.type[0]]}?menuVal=${record.type[2]}`}>前往</Link>
        </>)
      },
    },
  ];

  componentDidMount() {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'user/fetchSelect'
    });
    this.doPageSearch();
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'notice/resetSearchData',
    });
    dispatch({
      type: 'notice/resetList',
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const params = {
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'notice/changeSearchFormFields',
      payload: params,
    })
    this.doPageSearch();
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (selectedRows.length === 0) return;
    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'notice/remove',
          payload: {
            key: selectedRows.map(row => row.key),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
    const { dispatch } = this.props;
    dispatch({
      type: 'notice/changeSelectedRows',
      payload: rows,
    });
  };

  handleRefresh = () => {
    this.doPageSearch();
  }

  handleRemove = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'notice/remove',
      payload: record,
    }).then((res) => {
      if (res.code === 1) {
        message.success('删除成功');
        this.doPageSearch();
      } else {
        message.error('删除失败');
      }
    });
  }

  handleRead = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'notice/changeFormData',
      payload: {
        ...record,
        is_read: 1,
      },
    });
    dispatch({
      type: 'notice/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success("操作成功");
        this.doPageSearch();
      } else {
        message.error("操作失败");
      }
    });
  }

  doPageSearch() {
    const {
      dispatch,
      currentUser
    } = this.props;
    dispatch({
      type: 'notice/changeSearchFormFields',
      payload: {
        acceptman_id: currentUser.Id,
      }
    });
    dispatch({
      type: 'notice/fetch',
    });
  }

  render() {
    const {
      notice: { data },
      loading,
    } = this.props;
    const { selectedRows } = this.state;
    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );
    data.pagination = {
      ...data.pagination,
      showTotal: total => `总计 ${total} 条数据`,
      pageSizeOptions: ['10', '20', '30'],
    };
    return (
      <PageHeaderWrapper title="消息通知">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <SearchForm />
            <div className={styles.tableListOperator}>
              <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                刷新
              </Button>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={this.columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
              rowKey={record=>record.Id}
            />
          </div>
        </Card>
      </PageHeaderWrapper>
    );
  }
}

export default Notice;
