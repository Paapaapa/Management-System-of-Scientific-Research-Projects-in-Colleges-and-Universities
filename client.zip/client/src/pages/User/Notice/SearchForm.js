import { Button, Col, Form, Row, Select } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';

const FormItem = Form.Item;
const {Option} = Select;
const TYPE=['项目申报','项目开题','项目中期检查','项目结题','经费','成果','系统'];

@connect()
@Form.create()
class SearchForm extends PureComponent {
  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    dispatch({
      type:'notice/resetSearchData',
    });
    dispatch({
      type:'notice/fetch',
    });
  };

  handleSearch = (e) => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      dispatch({
        type: 'notice/changeSearchFormFields',
        payload:{
          ...values,
          pageNum: 1,
        },
      });
      dispatch({
        type: 'notice/fetch',
      });
    });
  };
  
    render() {
        const {
            form: { getFieldDecorator }
          } = this.props;
  
          return (
            <Form onSubmit={this.handleSearch} layout="inline">
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={8} sm={24}>
                  <FormItem label="状态">
                    {getFieldDecorator('is_read')(
                      <Select
                        style={{ width: 200 }}
                        placeholder="请选择"
                      >
                        <Option key="0">未读</Option>
                        <Option key="1">已读</Option>
                      </Select>
                    )}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <FormItem label="类型">
                    {getFieldDecorator('type')(
                      <Select placeholder="请选择" style={{ width: 200 }}>
                        { TYPE.map((val,index)=>(<Option key={index}>{val}</Option>))}
                      </Select>
                    )}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <div style={{ overflow: 'hidden',float:'right'}}>
                    <div style={{ marginBottom: 24,marginTop:4 }}>
                      <Button type="primary" htmlType="submit">
                       查询
                      </Button>
                      <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                       重置
                      </Button>
                    </div>
                  </div>
                </Col>
              </Row>
            </Form>
      );
    };
};

export default SearchForm;