import Result from '@/components/Result';
import { Button } from 'antd';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import { FormattedMessage } from 'umi/locale';
import Layout from '../UserLayout';
import styles from './RegisterResult.less';
import { connect } from 'dva';

@connect()
class App extends PureComponent {

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'register/registerHandle',
      payload: {
        code: 0,
      }
    });
  }

  renderActions = (
    <div className={styles.actions}>
      <Link to="/">
        <Button size="large">
          返回首页
        </Button>
      </Link>
    </div>
  );

  render() {
    const { location } = this.props;
    return (
      <Layout>
        <Result
          className={styles.registerResult}
          type="success"
          title={
            <div className={styles.title}>
              <FormattedMessage
                id="app.register-result.msg"
                values={{ email: location.state ? location.state.account : 'account' }}
              />
            </div>
          }
          description="您的账户正在等待管理员审核，审核通过后方能登录，请耐心等待······"
          actions={this.renderActions}
          style={{ marginTop: 56 }}
        />
      </Layout>
    );
  }
}

export default App;