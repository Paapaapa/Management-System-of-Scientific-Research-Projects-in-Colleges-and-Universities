import { Drawer, Upload, Divider, Timeline,Tooltip } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import DescriptionList from '@/components/DescriptionList';
import Ellipsis from '@/components/Ellipsis';

const { Description } = DescriptionList;

@connect(({ fapply, user, category,apply }) => ({
  record: fapply.formData,
  personSelect: user.personSelect,
  categorySelect: category.categorySelect,
  projectSelect:apply.projectSelect
}))
class ReadDescription extends PureComponent {

  render() {
    const { record, visible, onClose, personSelect, categorySelect,projectSelect } = this.props;
    // 时间轴显示进度
    const RenderTimeline = (records) => (
      <Timeline pending={records.confirm_time ? false : "进行中···"} mode="alternate" style={{paddingTop:'10px'}}>
        {records.apply_time ? (
          <Timeline.Item>
            <div>{`${personSelect[records.principal_id]}进行了成果登记`}</div>
            <div>{moment(records.apply_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
        {records.check_time ? (
          <Timeline.Item>
            <div>{`管理员${personSelect[records.checkman_id]}进行了初审`}</div>
            <div>{moment(records.check_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
          {records.zcheck_time ? (
          <Timeline.Item>
            <div>{`专家${personSelect[records.zcheckman_id]}进行了评审`}</div>
            <div>{moment(records.zcheck_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
        {records.confirm_time ? (
          <Timeline.Item>
            <div>{`管理员${personSelect[records.confirmman_id]}确认了成果`}</div>
            <div>{moment(records.confirm_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
      </Timeline>
    );
    // 附件下载
    const downloadFile = () => {
      const props = {
        fileList: record ?.file_path ?.split(',') ?.map((val, index) => ({
          'uid': index,
          'name': val.split('_')[1],
          'status': 'done',
          'url': `${window.location.origin}/server/api/file/download/fruit&${val}`,
        })),
        showUploadList: {
          showPreviewIcon: true,
          showRemoveIcon: false,
        },
      };
      return record.file_path ? (<Upload {...props} />) : <>暂无附件</>;
    };


    return (
      <Drawer
        destroyOnClose
        title={`${projectSelect[record ?.project_id]}-成果详情`}
        placement="right"
        closable={false}
        onClose={onClose}
        visible={visible}
        width={800}
      >
        <DescriptionList size="large" title="流程进度" style={{ marginBottom: 32 }}>
          {RenderTimeline(record)}
        </DescriptionList>
        <Divider style={{ marginBottom: 32 }} />
        <DescriptionList size="large" title="First-成果登记" style={{ marginBottom: 32 }}>
          <Description term="项目名称">
          <Ellipsis tooltip lines={1}>{projectSelect[record ?.project_id]}</Ellipsis>
          </Description>
          <Description term="项目类别">{categorySelect[record ?.category_id]}</Description>
          <Description term="登记人">{personSelect[record ?.principal_id]}</Description>
          <Description term="成果简介">
           <Ellipsis tooltip lines={1}>{record ?.description}</Ellipsis>
          </Description>
          <Description term="登记时间">{moment(record ?.apply_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.check_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Second-管理员初审" style={{ marginBottom: 32, display: record ?.check_time ? 'block' : 'none' }}>
          <Description term="审核人员">{personSelect[record ?.checkman_id]}</Description>
          <Description term="是否通过">{record ?.is_check_pass==1?'是':'否'}</Description>
          <Description term="审核意见">
          <Ellipsis tooltip lines={1}>{record ?.check_comment}</Ellipsis>
          </Description>
          <Description term="审核时间">{moment(record ?.check_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.zcheck_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Third-专家评审" style={{ marginBottom: 32, display: record ?.zcheck_time ? 'block' : 'none' }}>
          <Description term="评审专家">{personSelect[record ?.zcheckman_id]}</Description>
          <Description term="是否通过">{record ?.is_zcheck_pass==1?'是':'否'}</Description>
          <Description term="评审意见">
          <Ellipsis tooltip lines={1}>{record ?.zcheck_comment}</Ellipsis>
          </Description>
          <Description term="评审时间">{moment(record ?.zcheck_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.confirm_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Last-成果确认" style={{ marginBottom: 32, display: record ?.confirm_time ? 'block' : 'none' }}>
          <Description term="确认人员">{personSelect[record ?.confirmman_id]}</Description>
          <Description term="确认时间">{moment(record ?.confirm_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32 }} />
        <DescriptionList size="large" title="附件下载" style={{ marginBottom: 32 }}>
          <div style={{marginLeft:'18px'}}>{downloadFile()}</div>
        </DescriptionList>
      </Drawer>
    );
  }
}

export default ReadDescription;