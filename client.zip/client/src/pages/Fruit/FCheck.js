import StandardTable from '@/components/StandardTable';
import { Button, Divider, Radio } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import styles from './Apply.less';
import CheckForm from './CheckForm';
import ReadDescription from './ReadDescription';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待初审', '等待专家评审', '初审未通过', '申请重新初审', '等待确认', '专家评审未通过', '已确认'];

@connect(({ fapply, loading, user, category, apply }) => ({
    fapply,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
    projectSelect: apply.projectSelect,
}))
class Apply extends PureComponent {
    state = {
        menuVal: 'noCheck',
        checkVisible: false,
        readVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'project_id',
            sorter: true,
            render: (text) => {
                const { projectSelect, currentUser } = this.props;
                return (<Link to={`/project/apply?Id=${text}&menuVal=1`}>{projectSelect[text]}</Link>)
            },
        },
        {
            title: '登记人',
            dataIndex: 'principal_id',
            sorter: true,
            render: text => {
                const { personSelect } = this.props;
                return personSelect[text];
            },
        },
        {
            title: '类别',
            dataIndex: 'category_id',
            sorter: true,
            render: text => {
                const { categorySelect } = this.props;
                return categorySelect[text];
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const { currentUser } = this.props;
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                    'fcheck': <a onClick={() => this.handleCheckModalVisible(true, record)}>{record.check_time ? '重新审核' : '审核'}</a>,
                }
                return (<>
                    {renderBtn.read}
                    {[0, 1, 2, 3].includes(record.status) && currentUser.Id !== record.principal_id ? (<>
                        {renderBtn.divider}{renderBtn.fcheck}
                    </>) : null}
                </>);
            },
        },
    ];

    componentDidMount() {
        const { dispatch, location } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'category/fetchSelect',
        });
        dispatch({
            type: 'apply/fetchSelect',
        });
    }

    componentWillReceiveProps(nextProps){
        const { fapply: { isIndex } } = nextProps;
        if (isIndex) {
            this.setState({
                menuVal: 'noCheck',
            })
        }
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'fapply/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleCheckModalVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            checkVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'fapply/changeFormData',
                payload: record,
            });
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'fapply/changeFormData',
                payload: record
            });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleRadioGroup = (e) => {
        const {
            dispatch,
            currentUser
        } = this.props;
        const params = {};
        this.setState({
            menuVal: e.target.value,
        });
        switch (e.target.value) {
            case 'checked':
                params.is_check_pass = 'notNull';
                params.checkman_id = currentUser.Id;
                params.del_flag = 0;
                break;
            default:
                params.check_time = 'null';
                params.del_flag = 0;
                break;
        }
        dispatch({
            type: 'fapply/changeIsIndex',
            payload: false,
        });
        dispatch({
            type: 'fapply/saveTypeParams',
            payload: params,
        });
        this.doPageSearch();
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'fapply/fetch',
        });
    }

    render() {
        const {
            fapply: { data },
            loading,
            currentUser
        } = this.props;
        const { menuVal, checkVisible, readVisible } = this.state;
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };
        return (
            <div className={styles.tableList}>
                <div className={styles.tableListOperator}>
                    <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                        刷新
                    </Button>
                    <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                        <RadioButton value="noCheck">待处理</RadioButton>
                        <RadioButton value="checked">已处理</RadioButton>
                    </RadioGroup>
                </div>
                <StandardTable
                    selectedRows={[]}
                    loading={loading}
                    data={data}
                    columns={this.columns}
                    onChange={this.handleStandardTableChange}
                    rowKey={record => record.Id}
                />
                <CheckForm visible={checkVisible} onCancel={() => this.handleCheckModalVisible(false)} />
                <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
            </div>
        );
    }
}

export default Apply;
