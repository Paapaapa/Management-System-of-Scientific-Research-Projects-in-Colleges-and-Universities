import { Card, Tabs } from 'antd';
import { connect } from 'dva';
import React, { Component } from 'react';
import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import FCheck from './FCheck';
import ZCheck from './ZCheck';
import Finish from './Finish';
import Public from './Public';
import Self from './Self';
import Add from './Add';

const { TabPane } = Tabs;

@connect(({ user }) => ({
    user,
}))
class Index extends Component {
    state = {
        activeKey: '1',
    }

    componentDidMount() {
        const { dispatch, location } = this.props;
        const {Id,menuVal}=location.query;
        if(Id){
            dispatch({
                type: 'fapply/changeSearchFormFields',
                payload: {
                  Id,
                },
            });
        }
        this.onChange(menuVal || this.state.activeKey);
    }

    componentWillUnmount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'fapply/resetSearchData',
        });
        dispatch({
            type: 'fapply/resetList',
        });
        dispatch({
            type: 'fapply/saveTypeParams',
        });
    }

    onChange = (key) => {
        const {
            dispatch,
            user: { currentUser }
        } = this.props;
        const params = {};
        this.setState({
            activeKey: key,
        });
        switch (key) {
            case '1':
                params.confirm_time = 'notNull';
                params.del_flag = 0;
                break;
            case '2': break;
            case '3':
                params.principal_id = currentUser.Id;
                break;
            case '4':
                params.check_time = 'null';
                params.del_flag = 0;
                break;
            case '5':
                params.check_time = 'notNull';
                params.is_check_pass = 1;
                params.zcheck_time = 'null';
                params.del_flag = 0;
                break;
            case '6':
                params.zcheck_time = 'notNull';
                params.is_zcheck_pass = 1;
                params.confirm_time = 'null';
                params.del_flag = 0;
                break;
            default: break;
        }
        dispatch({
            type: 'fapply/changeIsIndex',
            payload: true,
        });
        dispatch({
            type: 'fapply/saveTypeParams',
            payload: params,
        });
        dispatch({
            type: 'fapply/fetch',
        });
    }

    render() {
        const { user: { currentUser } } = this.props;
        const { activeKey } = this.state;
        return (
            <PageHeaderWrapper title="成果管理">
                <Card bordered={false}>
                    <Tabs defaultActiveKey="1" type="card" onChange={this.onChange} activeKey={activeKey}>
                        <TabPane tab="公开公示" key="1">
                            <Public />
                        </TabPane>
                        <TabPane tab="成果登记" key="2">
                            <Add />
                        </TabPane>
                        <TabPane tab="个人登记" key="3">
                            <Self />
                        </TabPane>
                        {currentUser.role === 'G' ? <TabPane tab="审核材料" key="4">
                            <FCheck />
                        </TabPane> : null}
                        {currentUser.role === 'Z' ? <TabPane tab="评审成果" key="5">
                            <ZCheck />
                        </TabPane> : null}
                        {currentUser.role === 'G' ? <TabPane tab="成果确认" key="6">
                            <Finish />
                        </TabPane> : null}
                    </Tabs>
                </Card>
            </PageHeaderWrapper>
        );
    }
}

export default Index;