import { Modal, Select, Form, message, Input } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { formatObj } from '@/utils/utils';

const { Option } = Select;
const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ fapply, user }) => ({
  fapply,
  personSelect: user.personSelect,
  currentUser: user.currentUser,
}))
@Form.create()
class Check extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      currentUser,
      fapply: { formData }
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'fapply/changeFormData',
        payload: {
          ...formatObj(formData),
          ...fieldsValue,
          check_time: moment().format('YYYY-MM-DD HH:mm:ss'),
          checkman_id: currentUser.Id,
          status: fieldsValue.is_check_pass === '0' ? 2 : 1,
          opt:'fcheck',
        },
      });
      dispatch({
        type: 'fapply/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("审核成功");
          dispatch({
            type: 'fapply/fetch',
          });
        } else {
          message.error("审核失败");
        }
      })
    });
  };

  render() {
    const { visible, onCancel, form,fapply:{formData} } = this.props;

    return (
      <Modal
        destroyOnClose
        title="初审"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="是否通过">
          {form.getFieldDecorator('is_check_pass', {
            rules: [{ required: true, message: '必选' }],
            initialValue: formData.is_check_pass==0||formData.is_check_pass?String(formData ?.is_check_pass):'',
          })(<Select
            style={{ width: 200 }}
            placeholder="请选择"
          >
            <Option value="0">不同意</Option>
            <Option value="1">同意</Option>
          </Select>)}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="审核意见">
          {form.getFieldDecorator('check_comment', {
            rules: [{ required: true, message: '必填' }],
            initialValue: formData ?.check_comment,
          })(<TextArea
            style={{ minHeight: 32 }}
            placeholder='请输入评审意见'
            rows={4}
          />)}
        </FormItem>
      </Modal>
    );
  };
};

export default Check;