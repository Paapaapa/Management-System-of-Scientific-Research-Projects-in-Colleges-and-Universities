import StandardTable from '@/components/StandardTable';
import { Button, Radio } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import styles from './Apply.less';
import ReadComment from './ReadComment';
import ReadDescription from './ReadDescription';
import SearchForm from './SearchForm';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待初审', '等待专家评审', '初审未通过', '申请重新初审', '等待确认', '专家评审未通过', '已确认'];

@connect(({ fapply, loading, user, category, apply }) => ({
    fapply,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
    projectSelect: apply.projectSelect,
}))
class Apply extends PureComponent {
    state = {
        menuVal: 'public',
        readVisible: false,
        commentVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'project_id',
            sorter: true,
            render: (text) => {
                const { projectSelect, currentUser } = this.props;
                return (<Link to={`/project/apply?Id=${text}&menuVal=1`}>{projectSelect[text]}</Link>)
            },
        },
        {
            title: '登记人',
            dataIndex: 'principal_id',
            sorter: true,
            render: text => {
                const { personSelect } = this.props;
                return personSelect[text];
            },
        },
        {
            title: '类别',
            dataIndex: 'category_id',
            sorter: true,
            render: text => {
                const { categorySelect } = this.props;
                return categorySelect[text];
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const renderBtn = {
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                    'comment':<a onClick={() => this.handleCommentVisible(true, record)}>查看评价</a>,
                }
                return (<>
                    {renderBtn.read}
                </>);
            },
        },
    ];

    componentDidMount() {
        const { dispatch, location } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'category/fetchSelect',
        });
        dispatch({
            type: 'apply/fetchSelect',
        });
    }

    componentWillReceiveProps(nextProps){
        const { fapply: { isIndex } } = nextProps;
        if (isIndex) {
            this.setState({
                menuVal: 'public',
            })
        }
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'fapply/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'fapply/changeFormData',
                payload: record
            });
    }

    handleCommentVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            commentVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'fapply/changeFormData',
                payload: record
            });
        if (flag) {
            dispatch({
                type: 'comment/changeSearchFormFields',
                payload: {
                    fruit_id: record.Id,
                    replyto_id: 'null',
                }
            });
            dispatch({
                type: 'comment/fetch',
            });
        } else {
            // 重置和清空
            dispatch({
                type: 'comment/resetSearchData',
            });
            dispatch({
                type: 'comment/saveList',
            });
        }
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleRadioGroup = (e) => {
        const {
            dispatch,
            currentUser
        } = this.props;
        const params = {};
        this.setState({
            menuVal: e.target.value,
        });
        switch (e.target.value) {
            case 'all':
                params.del_flag = 0;
                break;
            default:
                params.del_flag = 0;
                params.confirm_time = 'notNull';
                break;
        }
        dispatch({
            type: 'fapply/changeIsIndex',
            payload: false,
        });
        dispatch({
            type: 'fapply/saveTypeParams',
            payload: params,
        });
        this.doPageSearch();
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'fapply/fetch',
        });
    }

    render() {
        const {
            fapply: { data },
            loading,
            currentUser
        } = this.props;
        const { menuVal, readVisible, commentVisible } = this.state;
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };
        return (
            <div className={styles.tableList}>
                <div className={styles.tableListForm}>
                    <SearchForm />
                </div>
                <div className={styles.tableListOperator}>
                    <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                        刷新
                    </Button>
                    {currentUser.role === 'G' ? <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                        <RadioButton value="all">所有</RadioButton>
                        <RadioButton value="public">公开</RadioButton>
                    </RadioGroup> : null}
                </div>
                <StandardTable
                    selectedRows={[]}
                    loading={loading}
                    data={data}
                    columns={this.columns}
                    onChange={this.handleStandardTableChange}
                    rowKey={record => record.Id}
                />
                <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
                <ReadComment visible={commentVisible} onClose={() => this.handleCommentVisible(false)} />
            </div>
        );
    }
}

export default Apply;
