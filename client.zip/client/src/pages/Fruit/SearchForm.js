import { Form, Row, Col, AutoComplete, Button, Icon, DatePicker, Select } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import styles from './Apply.less';

const FormItem = Form.Item;
const { Option } = Select;
const { RangePicker } = DatePicker;
const PROGRESS = ['等待初审', '等待专家评审', '初审未通过', '申请重新初审', '等待确认', '专家评审未通过', '已确认'];

@connect(({ category, user, apply }) => ({
  categorySelect: category.categorySelect,
  personSelect: user.personSelect,
  projectSelect: apply.projectSelect,
}))
@Form.create()
class SearchForm extends PureComponent {
  state = {
    dataSource: [],
    expandForm: false,
  };

  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    dispatch({
      type: 'fapply/resetSearchData',
    });
    dispatch({
      type: 'fapply/fetch',
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleSearch = (e) => {
    e.preventDefault();
    const { dispatch, form, personSelect, categorySelect, projectSelect } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      Object.keys(personSelect).forEach((val) => {
        personSelect[val] === values.principal_id && (values.principal_id = val);
        personSelect[val] === values.checkman_id && (values.checkman_id = val);
        personSelect[val] === values.zcheckman_id && (values.zcheckman_id = val);
        personSelect[val] === values.confirmman_id && (values.confirmman_id = val);
      });
      Object.keys(categorySelect).forEach((val) => {
        categorySelect[val] === values.category_id && (values.category_id = val);
      });
      Object.keys(projectSelect).forEach((val) => {
        projectSelect[val] === values.project_id && (values.project_id = val);
      });

      dispatch({
        type: 'fapply/resetSearchData',
        payload: {
          ...values,
          apply_time: values.apply_time ? [values.apply_time[0].format('YYYY-MM-DD'), values.apply_time[1].format('YYYY-MM-DD')].toString() : '',
          check_time: values.check_time ? [values.check_time[0].format('YYYY-MM-DD'), values.check_time[1].format('YYYY-MM-DD')].toString() : '',
          zcheck_time: values.zcheck_time ? [values.zcheck_time[0].format('YYYY-MM-DD'), values.zcheck_time[1].format('YYYY-MM-DD')].toString() : '',
        },
      });
      dispatch({
        type: 'fapply/fetch',
      });
    });
  };

  handleAutoSearch = (value, data) => {
    if (value !== '') {
      const dataSource = [];
      Object.keys(data).forEach((val) => {
        if (data[val].indexOf(value) > -1) dataSource.push(data[val]);
      });
      this.setState({
        dataSource
      });
    }
  };

  renderSimpleForm() {
    const {
      form: { getFieldDecorator }, personSelect, projectSelect
    } = this.props;
    const { dataSource } = this.state;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="项目名称">
              {getFieldDecorator('project_id')(
                <AutoComplete
                  dataSource={dataSource}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, projectSelect)}
                  placeholder="请输入"
                />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="登记人员">
              {getFieldDecorator('principal_id')(
                <AutoComplete
                  dataSource={dataSource}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons} style={{ float: 'right' }}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
              <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
                展开 <Icon type="down" />
              </a>
            </span>
          </Col>
        </Row>
      </Form>
    );
  };

  renderAdvancedForm() {
    const {
      form: { getFieldDecorator }, categorySelect, personSelect, projectSelect
    } = this.props;
    const { dataSource } = this.state;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="项目名称">
              {getFieldDecorator('project_id')(
                <AutoComplete
                  dataSource={dataSource}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, projectSelect)}
                  placeholder="请输入"
                />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="登记人员">
              {getFieldDecorator('principal_id')(
                <AutoComplete
                  dataSource={dataSource}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="初审人员">
              {getFieldDecorator('checkman_id')(
                <AutoComplete
                  dataSource={dataSource}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="评审人员">
              {getFieldDecorator('zcheckman_id')(
                <AutoComplete
                  dataSource={dataSource}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="确认人员">
              {getFieldDecorator('confirmman_id')(
                <AutoComplete
                  dataSource={dataSource}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="初审是否通过">
              {getFieldDecorator('is_check_pass')(
                <Select placeholder="请选择" style={{ width: 200 }}>
                  <Option key="0">否</Option>
                  <Option key="1">是</Option>
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="评审是否通过">
              {getFieldDecorator('is_zcheck_pass')(
                <Select placeholder="请选择" style={{ width: 200 }}>
                  <Option key="0">否</Option>
                  <Option key="1">是</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="登记时间">
              {getFieldDecorator('apply_time')(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="初审时间">
              {getFieldDecorator('check_time')(
                <RangePicker />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="评审时间">
              {getFieldDecorator('zcheck_time')(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="类别名称">
              {getFieldDecorator('category_id')(
                <AutoComplete
                  dataSource={dataSource}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, categorySelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="进度" labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              {getFieldDecorator('status')(
                <Select placeholder="请选择" style={{ width: 200 }}>
                  {PROGRESS.map((val, index) => (<Option key={index}>{val}</Option>))}
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <div style={{ marginBottom: 24, float: 'right' }}>
          <Button type="primary" htmlType="submit">
            查询
                </Button>
          <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
            重置
                </Button>
          <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
            收起 <Icon type="up" />
          </a>
        </div>
      </Form>
    );
  }

  render() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }
};

export default SearchForm;