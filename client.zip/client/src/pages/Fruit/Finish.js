import StandardTable from '@/components/StandardTable';
import { formatObj } from '@/utils/utils';
import { Button, Divider, message, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import styles from './Apply.less';
import ReadDescription from './ReadDescription';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待初审', '等待专家评审', '初审未通过', '申请重新初审', '等待确认', '专家评审未通过', '已确认'];

@connect(({ fapply, loading, user, category, apply }) => ({
    fapply,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
    projectSelect: apply.projectSelect,
}))
class Apply extends PureComponent {
    state = {
        menuVal: 'noConfirm',
        readVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'project_id',
            sorter: true,
            render: (text) => {
                const { projectSelect, currentUser } = this.props;
                return (<Link to={`/project/apply?Id=${text}&menuVal=1`}>{projectSelect[text]}</Link>)
            },
        },
        {
            title: '登记人',
            dataIndex: 'principal_id',
            sorter: true,
            render: text => {
                const { personSelect } = this.props;
                return personSelect[text];
            },
        },
        {
            title: '类别',
            dataIndex: 'category_id',
            sorter: true,
            render: text => {
                const { categorySelect } = this.props;
                return categorySelect[text];
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const { currentUser } = this.props;
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                    'finish': <Popconfirm title="您确定公示该成果吗？" onConfirm={() => this.handleConfirm(record)} okText="确定" cancelText="取消"><a href="#">公示成果</a></Popconfirm>,
                }
                return (<>
                    {renderBtn.read}
                    {[4].includes(record.status) && currentUser.Id !== record.principal_id ? (<>
                        {renderBtn.divider}{renderBtn.finish}
                    </>) : null}
                </>);
            },
        },
    ];

    componentDidMount() {
        const { dispatch, location } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'category/fetchSelect',
        });
        dispatch({
            type: 'apply/fetchSelect',
        });
    }

    componentWillReceiveProps(nextProps){
        const { fapply: { isIndex } } = nextProps;
        if (isIndex) {
            this.setState({
                menuVal: 'noConfirm',
            })
        }
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'fapply/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'fapply/changeFormData',
                payload: record
            });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleRadioGroup = (e) => {
        const {
            dispatch,
            currentUser
        } = this.props;
        const params = {};
        this.setState({
            menuVal: e.target.value,
        });
        switch (e.target.value) {
            case 'confirmed':
                params.confirmman_id = currentUser.Id;
                params.confirm_time = 'notNull';
                params.del_flag = 0;
                break;
            default:
                params.zcheck_time = 'notNull';
                params.is_zcheck_pass = 1;
                params.confirm_time = 'null';
                params.del_flag = 0;
                break;
        }
        dispatch({
            type: 'fapply/changeIsIndex',
            payload: false,
        });
        dispatch({
            type: 'fapply/saveTypeParams',
            payload: params,
        });
        this.doPageSearch();
    }

    handleConfirm = (record) => {
        const {
            dispatch,
            currentUser
        } = this.props;
        if (record)
            dispatch({
                type: 'fapply/changeFormData',
                payload: {
                    ...formatObj(record),
                    confirm_time: moment().format('YYYY-MM-DD HH:mm:ss'),
                    status: 6,
                    confirmman_id: currentUser.Id,
                },
            });
        dispatch({
            type: 'fapply/add',
        }).then((res) => {
            if (res.code === 1) {
                message.success("公示成功");
                this.doPageSearch();
            } else {
                message.error("公示失败");
            }
        });
    };

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'fapply/fetch',
        });
    }

    render() {
        const {
            fapply: { data },
            loading,
            currentUser
        } = this.props;
        const { readVisible,menuVal } = this.state;
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };
        return (
            <div className={styles.tableList}>
                <div className={styles.tableListOperator}>
                    <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                        刷新
              </Button>
                    <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                        <RadioButton value="noConfirm">待处理</RadioButton>
                        <RadioButton value="confirmed">已处理</RadioButton>
                    </RadioGroup>
                </div>
                <StandardTable
                    selectedRows={[]}
                    loading={loading}
                    data={data}
                    columns={this.columns}
                    onChange={this.handleStandardTableChange}
                    rowKey={record => record.Id}
                />
                <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
            </div>
        );
    }
}

export default Apply;
