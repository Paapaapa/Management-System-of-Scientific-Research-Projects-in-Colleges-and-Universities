import { Form, Input, message, Modal, Select, Upload, Button, Icon } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import {
    formatObj,
} from '@/utils/utils';
import {
    removeFile
} from '@/services/api';

const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;

@connect(({ user, category, apply }) => ({
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
    projectSelect: apply.SSelect,
}))
@Form.create()
class Check extends PureComponent {
    state = {
        fileList: [],
        submitting:false,
    }

    componentDidMount() {
        const { dispatch, currentUser } = this.props;
        dispatch({
            type: 'apply/fetchSelect',
            payload: {
                principal_id: currentUser.Id,
            }
        });
    }

    handleOk = (e) => {
        e.preventDefault();
        const {
            dispatch,
            form,
            currentUser
        } = this.props;
        const {
            fileList
        } = this.state;
        const postData = new FormData();
        fileList.forEach((file) => {
            postData.append('files', file);
        });
        form.validateFields((err, fieldsValue) => {
            if (err) return;
            form.resetFields();
            Object.keys(fieldsValue).forEach(val => {
                postData.append(val, fieldsValue[val]);
            });
            postData.append('principal_id', currentUser.Id);
            postData.append('status', 0);
            postData.append('opt', 'add');
            postData.set('project_id', fieldsValue.project_id.split('^')[0]);
            this.setState({
                submitting:true,
            });
            dispatch({
                type: 'fapply/changeFormData',
                payload: postData,
            });
            dispatch({
                type: 'fapply/add',
            }).then((res) => {
                if (res.code === 1) {
                    message.success("操作成功");
                    this.setState({
                        fileList: [],
                        submitting:false,
                    });
                } else {
                    message.error("操作失败");
                }
            });
        });
    };

    render() {
        const { visible, form, categorySelect, projectSelect } = this.props;
        const { fileList,submitting } = this.state;
        const props = {
            onRemove: (file) => {
                this.setState((state) => {
                    const index = state.fileList.indexOf(file);
                    const newFileList = state.fileList.slice();
                    newFileList.splice(index, 1);
                    return {
                        fileList: newFileList,
                    };
                });
            },
            beforeUpload: (file) => {
                this.setState(state => ({
                    fileList: [...state.fileList, file],
                }));
                return false;
            },
            fileList
        };
        // 附件下载
        const downloadFile = () => {
            const props = {
                fileList: [{
                    'uid': -1,
                    'name': '模板',
                    'status': 'done',
                    'url': `${window.location.origin}/server/api/file/download/template&fruit.doc`,
                }],
                showUploadList: {
                    showPreviewIcon: true,
                    showRemoveIcon: false,
                },
            };
            return (<>
                <div style={{ marginTop: 10 }}>请先下载以下模板填写再上传</div>
                <Upload {...props} />
            </>);
        };

        return (
            <Form layout='horizontal' onSubmit={this.handleOk} hideRequiredMark style={{ marginTop: 20 }}>
                <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 8 }} label="项目名称">
                    {form.getFieldDecorator('project_id', {
                        rules: [{ required: true, message: '必选' }],
                    })(<Select showSearch optionFilterProp="children" placeholder="请选择" style={{ width: '100%' }}>{Object.keys(projectSelect).map(val => (<Option key={`${val}^${projectSelect[val]}`}>{projectSelect[val]}</Option>))}</Select>)}
                </FormItem>
                <FormItem label="类别" labelCol={{ span: 8 }} wrapperCol={{ span: 8 }}>
                    {form.getFieldDecorator('category_id', {
                        rules: [{ required: true, message: '必选' }],
                    })(
                        <Select placeholder="请选择" style={{ width: '100%' }}>
                            {Object.keys(categorySelect).map(val => (<Option key={val}>{categorySelect[val]}</Option>))}
                        </Select>
                    )}
                </FormItem>
                <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 8 }} label="成果简介">
                    {form.getFieldDecorator('description', {
                        rules: [{ required: true, message: '请输入至少10个字符！', min: 10 }],
                    })(<TextArea
                        style={{ minHeight: 32 }}
                        placeholder='请输入成果简介'
                        rows={4}
                    />)}
                </FormItem>
                <FormItem label="附件上传" labelCol={{ span: 8 }} wrapperCol={{ span: 8 }} help={downloadFile()}>
                    <Upload name="fruit" listType="picture" {...props}>
                        <Button>
                            <Icon type="upload" /> 上传
                        </Button>
                    </Upload>
                </FormItem>
                <div style={{ textAlign: 'center' }}>
                    <Button type="primary" htmlType="submit" loading={submitting}>
                        提交
                    </Button>
                </div>
            </Form>
        );
    };
};

export default Check;