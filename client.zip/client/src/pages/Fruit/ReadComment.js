import { Drawer, Comment, Avatar, Form, Button, Input, message, Icon, Popconfirm, Empty } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';

const { TextArea } = Input;

@connect(({ fapply, user, category, apply, comment }) => ({
  record: fapply.formData,
  personSelect: user.personSelect,
  categorySelect: category.categorySelect,
  projectSelect: apply.projectSelect,
  comment,
  currentUser: user.currentUser,
  avatarList: user.avatarList,
}))
class ReadComment extends PureComponent {
  state = {
    submitting: false,
    value: '',
    isShow: 'none',
    btnTxt: '评价',// 按钮文本
    replyCommentId: '',// 回复评论Id
    replyPersonId: '',// 回复评论人Id
    canSubmit: false
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'user/fetchAvatar',
    });
  }

  renderExampleComment = (comment, children) => {
    const { personSelect, currentUser, avatarList } = this.props;

    return (
      <Comment
        actions={[<span onClick={() => this.reply(comment)}>回复</span>, <span>{currentUser.Id === comment.writer_id ? (<Popconfirm okText='确定' cancelText='取消' title='您确定删除这条评论吗？' onConfirm={() => this.handleRemove(comment.Id)}><span>删除</span></Popconfirm>) : null}</span>]}
        author={<a>{personSelect[comment.writer_id]}{comment.replyto_id ? (<><span style={{ color: 'gray', margin: 'auto 10px' }}>回复</span>{personSelect[comment.replyto_person_id]}</>) : null}</a>}
        avatar={!comment.replyto_id ? <Avatar src={avatarList[comment.writer_id] ? `${window.location.origin}/server/api/file/download/avatar&${avatarList[comment.writer_id]}` : 'https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png'} alt='头像' /> : null}
        content={<p>{comment.content}</p>}
        datetime={moment(comment.upd_time).fromNow()}
        key={comment.Id}
      >
        {children}
      </Comment>
    )
  };

  renderEditor = () => {
    const { submitting, btnTxt, value, isShow, canSubmit } = this.state;
    return (
      <div>
        <Form.Item>
          <TextArea rows={4} onChange={this.handleChange} value={value} />
        </Form.Item>
        <Form.Item style={{ float: 'right', marginBottom: '-15px' }}>
          <Button
            htmlType="submit"
            loading={submitting}
            onClick={this.handleSubmit}
            type="primary"
            disabled={canSubmit}
          >
            {btnTxt}
          </Button>
          <Button
            onClick={this.handleReset}
            style={{ marginLeft: '20px', display: isShow }}
          >
            取消回复
          </Button>
        </Form.Item>
      </div>
    );
  }

  reply = (comment) => {
    const { personSelect } = this.props;
    this.setState({
      replyCommentId: comment.replyto_id ? comment.replyto_id : comment.Id,
      replyPersonId: comment.writer_id,
      btnTxt: `回复${personSelect[comment.writer_id]}`,
      isShow: 'inline-block',
    });
  }

  handleSubmit = () => {
    const { dispatch, record, currentUser } = this.props;
    const { value, replyCommentId, replyPersonId } = this.state;
    if (!value) {
      return;
    }
    this.setState({
      submitting: true,
    });
    dispatch({
      type: 'comment/changeFormData',
      payload: {
        content: value,
        writer_id: currentUser.Id,
        fruit_id: record.Id,
        replyto_person_id: replyPersonId,
        replyto_id: replyCommentId,
      }
    });
    dispatch({
      type: 'comment/add',
    }).then(res => {
      if (res.code === 1) {
        message.success('发表成功');
        this.setState({
          value: '',
          submitting: false,
          replyCommentId: '',
          replyPersonId: '',
          btnTxt: '评论',
          canSubmit: true,
        });
        dispatch({
          type: 'comment/saveList',
        });
        dispatch({
          type: 'comment/changeSearchFormFields',
          payload: {
            pageNum: 1,
          }
        });
        dispatch({
          type: 'comment/fetch',
        }).then(res => {
          if (res.code === 1) {
            this.setState({
              canSubmit: false
            })
          }
        })
      } else {
        message.error('发表失败');
        this.setState({
          submitting: false,
        });
      }
    })
  }

  handleRemove = (id) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'comment/remove',
      payload: id,
    }).then(res => {
      if (res.code === 1) {
        message.success('删除成功');
        dispatch({
          type: 'comment/saveList',
        });
        dispatch({
          type: 'comment/changeSearchFormFields',
          payload: {
            pageNum: 1,
          }
        });
        dispatch({
          type: 'comment/fetch',
        });
      } else {
        message.error('删除失败');
      }
    })
  }

  handleChange = (e) => {
    this.setState({
      value: e.target.value,
    });
  }

  handleReset = () => {
    this.setState({
      replyCommentId: '',
      replyPersonId: '',
      btnTxt: '评价',
      isShow: 'none',
    })
  }

  more = () => {
    const { dispatch, comment } = this.props;
    dispatch({
      type: 'comment/changeSearchFormFields',
      payload: {
        pageNum: comment.searchData.pageNum + 1,
      }
    });
    dispatch({
      type: 'comment/fetch',
    });
  }

  render() {
    const { record, visible, onClose, projectSelect, comment: { data }, currentUser } = this.props;

    return (<Drawer
      estroyOnClose
      title={`${projectSelect[record ?.project_id]}-成果评价`}
      placement="right"
      closable={false}
      onClose={onClose}
      visible={visible}
      width={700}
    >
      <p style={{ padding: '4px 0', fontSize: '16px', fontWeight: 'bold', borderBottom: '1px solid #d6d6d6' }}>
        <Icon type="sound" style={{ margin: '0 8px' }} />
        所有评价
          </p>
      {data && data.list && data.list.length > 0 && data.list.map(val =>
        this.renderExampleComment(val, val.children.map(cval =>
          this.renderExampleComment(cval)))
      )}
      {data ?.list ?.length === 0 ? (<Empty description='暂无评论' />) : null}
      {data ?.list ?.length > 0 && (data ?.list ?.length == data ?.total ? (<div style={{ textAlign: 'center', padding: '14px', color: '#bdbbbb' }}>没有更多了</div>) :
        (<div onClick={this.more} style={{ textAlign: 'center', padding: '14px', color: 'rgb(24, 144, 255)', cursor: 'pointer' }}>点击加载更多</div>))}
      <p style={{ padding: '4px 0', fontSize: '16px', margin: '14px 0', fontWeight: 'bold', borderBottom: '1px solid #d6d6d6' }}>
        <Icon type="edit" style={{ margin: '0 8px' }} />
        发表评价
          </p>
      <Comment
        avatar={(
          <Avatar
            src={currentUser.avatar ? `${window.location.origin}/server/api/file/download/avatar&${currentUser.avatar}` : 'https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png'}
            alt="头像"
          />
        )}
        content={this.renderEditor()}
      />
    </Drawer>
    );
  }
}

export default ReadComment;