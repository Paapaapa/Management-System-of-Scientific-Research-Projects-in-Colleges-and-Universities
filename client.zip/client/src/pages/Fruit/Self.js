import StandardTable from '@/components/StandardTable';
import { formatObj } from '@/utils/utils';
import { Button, Divider, message, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import AddForm from './AddForm';
import styles from './Apply.less';
import ReadComment from './ReadComment';
import ReadDescription from './ReadDescription';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待初审', '等待专家评审', '初审未通过', '申请重新初审', '等待确认', '专家评审未通过', '已确认'];

@connect(({ fapply, loading, user, category, apply }) => ({
    fapply,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
    projectSelect: apply.projectSelect,
}))
class Apply extends PureComponent {
    state = {
        modalVisible: false,
        readVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'project_id',
            sorter: true,
            render: (text) => {
                const { projectSelect, currentUser } = this.props;
                return (<Link to={`/project/apply?Id=${text}&menuVal=1`}>{projectSelect[text]}</Link>)
            },
        },
        {
            title: '类别',
            dataIndex: 'category_id',
            sorter: true,
            render: text => {
                const { categorySelect } = this.props;
                return categorySelect[text];
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                    'edit': <a onClick={() => this.handleModalVisible(true, record)}>编辑</a>,
                    'rollback': <Popconfirm title="您确定撤销申请吗？" onConfirm={() => this.handleRollBack(record)} okText="确定" cancelText="取消"><a href="#">撤销</a></Popconfirm>,
                    'restart': <Popconfirm title="您确定恢复申请吗？" onConfirm={() => this.handleRestart(record)} okText="确定" cancelText="取消"><a href="#">恢复</a></Popconfirm>,
                    'remove': <Popconfirm title="您确定彻底删除吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消"><a href="#">彻底删除</a></Popconfirm>,
                    'applyCheck': <Popconfirm title="您确定申请初审吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请初审</a></Popconfirm>,
                }
                return (<>
                    {renderBtn.read}
                    {[0, 2, 3, 5].includes(record.status) ? (<>
                        {renderBtn.divider}{renderBtn.edit}
                    </>) : null}
                    {[0, 2, 3, 5].includes(record.status) && record.del_flag === 0 ? (<>
                        {renderBtn.divider}{renderBtn.rollback}
                    </>) : null}
                    {[0, 2, 3, 5].includes(record.status) && record.del_flag === 1 ? (<>
                        {renderBtn.divider}{renderBtn.restart}{renderBtn.divider}{renderBtn.remove}
                    </>) : null}
                    {[2, 5].includes(record.status) && record.del_flag === 0? (<>
                        {renderBtn.divider}{renderBtn.applyCheck}
                    </>) : null}
                </>);
            },
        },
    ];

    componentDidMount() {
        const { dispatch, location } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'category/fetchSelect',
        });
        dispatch({
            type: 'apply/fetchSelect',
        });
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'fapply/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleModalVisible = (flag, record) => {
        const { dispatch } = this.props;
        dispatch({
            type: 'fapply/resetFormData',
        });
        this.setState({
            modalVisible: !!flag,
        });
        if (record) {
            dispatch({
                type: 'fapply/changeFormData',
                payload: record,
            });
        }
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'fapply/changeFormData',
                payload: record
            });
    }

    handleRecheck = (record) => {
        const { dispatch } = this.props;
        dispatch({
            type: 'fapply/changeFormData',
            payload: {
                ...formatObj(record),
                status: 3,
                is_check_pass: null,
                check_time: null,
                check_comment: null,
                checkman_id: null,
                is_zcheck_pass:null,
                zcheck_time:null,
                zcheck_comment:null,
                zcheckman_id:null,
                opt: 'apply',
            },
        });
        dispatch({
            type: 'fapply/add',
        }).then((res) => {
            if (res.code === 1) {
                message.success('申请成功');
                this.doPageSearch();
            } else {
                message.error('申请失败');
            }
        });
    }

    handleRestart = (record) => {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'fapply/changeFormData',
            payload: {
                ...formatObj(record),
                del_flag: 0,
                opt: 'remain',
            },
        });
        dispatch({
            type: 'fapply/add',
        }).then((res) => {
            if (res.code === 1) {
                message.success('恢复成功');
                this.doPageSearch();
            } else {
                message.error('恢复失败');
            }
        });
    }

    handleRemove = (record) => {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'fapply/remove',
            payload: {
                Id: record.Id
            },
        }).then((res) => {
            if (res.code === 1) {
                message.success("删除成功");
                this.doPageSearch();
            } else {
                message.error("删除失败");
            }
        });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleRollBack = (record) => {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'fapply/changeFormData',
            payload: {
                ...formatObj(record),
                del_flag: 1,
                opt:'rollback',
            },
        });
        dispatch({
            type: 'fapply/add',
        }).then((res) => {
            if (res.code === 1) {
                message.success('撤销成功');
                this.doPageSearch();
            } else {
                message.error('撤销失败');
            }
        });
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'fapply/fetch',
        });
    }

    render() {
        const {
            fapply: { data },
            loading,
            currentUser
        } = this.props;
        const { modalVisible, readVisible, commentVisible } = this.state;
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };
        return (
            <div className={styles.tableList}>
                <div className={styles.tableListOperator}>
                    <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                        刷新
                    </Button>
                </div>
                <StandardTable
                    selectedRows={[]}
                    loading={loading}
                    data={data}
                    columns={this.columns}
                    onChange={this.handleStandardTableChange}
                    rowKey={record => record.Id}
                />
                <AddForm visible={modalVisible} onCancel={() => this.handleModalVisible(false)} />
                <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
            </div>
        );
    }
}

export default Apply;
