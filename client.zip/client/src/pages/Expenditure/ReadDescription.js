import { Drawer, Upload, Divider, Timeline,Tooltip } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import DescriptionList from '@/components/DescriptionList';
import Ellipsis from '@/components/Ellipsis';

const { Description } = DescriptionList;

@connect(({ eapply, user, apply }) => ({
  record: eapply.formData,
  personSelect: user.personSelect,
  projectSelect:apply.projectSelect
}))
class ReadDescription extends PureComponent {

  render() {
    const { record, visible, onClose, personSelect, projectSelect } = this.props;
    // 时间轴显示进度
    const RenderTimeline = (records) => (
      <Timeline pending={records.check_time ? false : "进行中···"} mode="alternate" style={{paddingTop:'10px'}}>
        {records.apply_time ? (
          <Timeline.Item>
            <div>{`${personSelect[records.applyperson_id]}申请了经费￥${records.money}`}</div>
            <div>{moment(records.apply_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
        {records.check_time ? (
          <Timeline.Item>
            <div>{`管理员${personSelect[records.checkman_id]}进行了审批`}</div>
            <div>{moment(records.check_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
      </Timeline>
    );
    // 附件下载
    const downloadFile = () => {
      const props = {
        fileList: record ?.file_path ?.split(',') ?.map((val, index) => ({
          'uid': index,
          'name': val.split('_')[1],
          'status': 'done',
          'url': `${window.location.origin}/server/api/file/download/expenditure&${val}`,
        })),
        showUploadList: {
          showPreviewIcon: true,
          showRemoveIcon: false,
        },
      };
      return record.file_path ? (<Upload {...props} />) : <>暂无附件</>;
    };
    return (
      <Drawer
        destroyOnClose
        title={`${projectSelect[record ?.prject_id]}-经费详情`}
        placement="right"
        closable={false}
        onClose={onClose}
        visible={visible}
        width={800}
      >
        <DescriptionList size="large" title="流程进度" style={{ marginBottom: 32 }}>
          {RenderTimeline(record)}
        </DescriptionList>
        <Divider style={{ marginBottom: 32 }} />
        <DescriptionList size="large" title="First-经费申请" style={{ marginBottom: 32 }}>
          <Description term="项目名称">
          <Ellipsis tooltip lines={1}>{projectSelect[record ?.project_id]}</Ellipsis>
          </Description>
          <Description term="申请人">{personSelect[record ?.applyperson_id]}</Description>
          <Description term="申请金额">{record ?.money+'元'}</Description>
          <Description term="支付宝账号">{record ?.alipay_num}</Description>
          <Description term="申请描述">
          <Ellipsis tooltip lines={1}>{record ?.description}</Ellipsis>
          </Description>
          <Description term="申请时间">{moment(record ?.apply_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.check_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Second-管理员审批" style={{ marginBottom: 32, display: record ?.check_time ? 'block' : 'none' }}>
          <Description term="是否通过">{record ?.is_check_pass==1?'是':'否'}</Description>
          <Description term="审批意见">
            <Ellipsis tooltip lines={1}>{record ?.check_comment}</Ellipsis>
          </Description>
          <Description term="审批时间">{moment(record ?.check_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32 }} />
        <DescriptionList size="large" title="附件下载" style={{ marginBottom: 32 }}>
          <div style={{marginLeft:'18px'}}>{downloadFile()}</div>
        </DescriptionList>
      </Drawer>
    );
  }
}

export default ReadDescription;