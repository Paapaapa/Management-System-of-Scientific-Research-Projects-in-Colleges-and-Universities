import { Form, Row, Col, AutoComplete, Button, Icon, DatePicker, Select, Input } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import styles from './Apply.less';

const FormItem = Form.Item;
const { Option } = Select;
const { RangePicker } = DatePicker;
const PROGRESS = ['申请成功，等待审批', '已审批', '已驳回', '重新申请，等待审批'];

@connect(({ apply, user }) => ({
  projectSelect: apply.projectSelect,
  personSelect: user.personSelect,
}))
@Form.create()
class SearchForm extends PureComponent {
  state = {
    principalData: [],
    projectSource: [],
    expandForm: false,
  };

  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    dispatch({
      type: 'eapply/resetSearchData',
    });
    dispatch({
      type: 'eapply/fetch',
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleSearch = (e) => {
    e.preventDefault();
    const { dispatch, form, personSelect, projectSelect } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      Object.keys(personSelect).forEach((val) => {
        personSelect[val] === values.applyperson_id && (values.applyperson_id = val);
        personSelect[val] === values.checkman_id && (values.checkman_id = val);
        personSelect[val] === values.sendman_id && (values.sendman_id = val);
      });
      Object.keys(projectSelect).forEach((val) => {
        projectSelect[val] === values.project_id && (values.project_id = val);
      });

      dispatch({
        type: 'eapply/resetSearchData',
        payload: {
          ...values,
          apply_time: values.apply_time ? [values.apply_time[0].format('YYYY-MM-DD'), values.apply_time[1].format('YYYY-MM-DD')].toString() : '',
          check_time: values.check_time ? [values.check_time[0].format('YYYY-MM-DD'), values.check_time[1].format('YYYY-MM-DD')].toString() : '',
          send_time: values.send_time ? [values.send_time[0].format('YYYY-MM-DD'), values.send_time[1].format('YYYY-MM-DD')].toString() : '',
        },
      });
      dispatch({
        type: 'eapply/fetch',
      });
    });
  };

  handleAutoSearch = (value, data) => {
    if (value !== '') {
      const dataSource = [];
      Object.keys(data).forEach((val) => {
        if (data[val].indexOf(value) > -1) dataSource.push(data[val]);
      });
      this.setState({
        principalData: dataSource,
        projectSource: dataSource,
      });
    }
  };

  renderSimpleForm() {
    const {
      form: { getFieldDecorator }, personSelect, projectSelect
    } = this.props;
    const { principalData, projectSource } = this.state;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="项目名称">
              {getFieldDecorator('project_id')(
                <AutoComplete
                  dataSource={projectSource}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, projectSelect)}
                  placeholder="请输入"
                />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="申请人">
              {getFieldDecorator('applyperson_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24} >
            <span className={styles.submitButtons} style={{ float: 'right' }}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
              <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
                展开 <Icon type="down" />
              </a>
            </span>
          </Col>
        </Row>
      </Form>
    );
  };

  renderAdvancedForm() {
    const {
      form: { getFieldDecorator }, personSelect, projectSelect
    } = this.props;
    const { principalData, projectSource } = this.state;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="项目名称" labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              {getFieldDecorator('project_id')(
                <AutoComplete
                  dataSource={projectSource}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, projectSelect)}
                  placeholder="请输入"
                />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="申请人" labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              {getFieldDecorator('applyperson_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="审核人" labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              {getFieldDecorator('checkman_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="申报时间" labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              {getFieldDecorator('apply_time')(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="审核时间" labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              {getFieldDecorator('check_time')(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="是否通过" labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              {getFieldDecorator('is_check_pass')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option key="0">否</Option>
                  <Option key="1">是</Option>
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="金额" labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              {getFieldDecorator('money')(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="进度" labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              {getFieldDecorator('status')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  {PROGRESS.map((val, index) => (<Option key={index}>{val}</Option>))}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <div style={{ overflow: 'hidden', float: 'right' }}>
              <div style={{ marginBottom: 24 }}>
                <Button type="primary" htmlType="submit">
                  查询
             </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                  重置
             </Button>
                <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
                  收起 <Icon type="up" />
                </a>
              </div>
            </div>
          </Col>
        </Row>
      </Form>
    );
  }

  render() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }
};

export default SearchForm;