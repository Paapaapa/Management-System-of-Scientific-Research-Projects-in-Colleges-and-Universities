import { Card, Tabs } from 'antd';
import { connect } from 'dva';
import React, { Component } from 'react';
import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import Check from './Check';
import Public from './Public';
import Self from './Self';
import Add from './Add';

const { TabPane } = Tabs;

@connect(({ user }) => ({
    user,
}))
class Index extends Component {
    state = {
        activeKey: '1',
    }

    componentDidMount() {
        const { dispatch, location } = this.props;
        const {Id,menuVal}=location.query;
        if(Id){
            dispatch({
                type: 'eapply/changeSearchFormFields',
                payload: {
                  Id,
                },
            });
        }
        this.onChange(menuVal || this.state.activeKey);
    }

    componentWillUnmount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'eapply/resetSearchData',
        });
        dispatch({
            type: 'eapply/resetList',
        });
        dispatch({
            type: 'eapply/saveTypeParams',
        });
    }

    onChange = (key) => {
        const {
            dispatch,
            user: { currentUser }
        } = this.props;
        const params = {};
        this.setState({
            activeKey: key,
        });
        switch (key) {
            case '1':
                params.is_check_pass = 1;
                params.del_flag = 0;
                break;
            case '2': break;
            case '3':
                params.applyperson_id = currentUser.Id;
                break;
            case '4':
                params.check_time = 'null';
                params.del_flag = 0;
                break;
            default: break;
        }
        dispatch({
            type: 'eapply/changeIsIndex',
            payload: true,
        });
        dispatch({
            type: 'eapply/resetSearchData',
        });
        dispatch({
            type: 'eapply/saveTypeParams',
            payload: params,
        });
        dispatch({
            type: 'eapply/fetch',
        });
    }

    render() {
        const { user: { currentUser } } = this.props;
        const { activeKey } = this.state;

        return (
            <PageHeaderWrapper title="经费管理">
                <Card bordered={false}>
                    <Tabs defaultActiveKey="1" type="card" onChange={this.onChange} activeKey={activeKey}>
                        <TabPane tab="公开公示" key="1">
                            <Public />
                        </TabPane>
                        <TabPane tab="申请经费" key="2">
                            <Add />
                        </TabPane>
                        <TabPane tab="个人申请" key="3">
                            <Self />
                        </TabPane>
                        {currentUser.role === 'G' ? <TabPane tab="审批经费" key="4">
                            <Check />
                        </TabPane> : null}
                    </Tabs>
                </Card>
            </PageHeaderWrapper>
        );
    }
}

export default Index;