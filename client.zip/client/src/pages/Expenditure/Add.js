import { removeFile } from '@/services/api';
import { Button, Form, Icon, Input, InputNumber, message, Select, Upload } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';

const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;

@connect(({ user, apply }) => ({
    currentUser: user.currentUser,
    projectSelect: apply.SSelect,
}))
@Form.create()
class AddForm extends PureComponent {
    state = {
        fileList: [],
        submitting:false,
    }

    componentDidMount() {
        const { dispatch, currentUser } = this.props;
        dispatch({
            type: 'apply/fetchSelect',
            payload: {
                principal_id: currentUser.Id,
            }
        });
    }

    handleOk = (e) => {
        e.preventDefault();
        const {
            dispatch,
            form,
            currentUser
        } = this.props;
        const {
            fileList
        } = this.state;
        const postData = new FormData();
        fileList.forEach((file) => {
            postData.append('files', file);
        });
        form.validateFields((err, fieldsValue) => {
            if (err) return;
            form.resetFields();
            Object.keys(fieldsValue).forEach(val => {
                postData.append(val, fieldsValue[val]);
            });
            postData.append('applyperson_id', currentUser.Id);
            postData.append('status', 0);
            postData.append('opt', 'add');
            postData.set('project_id', fieldsValue.project_id.split('^')[0]);
            this.setState({
                submitting:true,
            })
            dispatch({
                type: 'eapply/changeFormData',
                payload: postData,
            });
            dispatch({
                type: 'eapply/add',
            }).then((res) => {
                if (res.code === 1) {
                    message.success("操作成功");
                    this.setState({
                        fileList: [],
                        submitting:false,
                    });
                } else {
                    message.error("操作失败");
                }
            });
        });
    };

    render() {
        const { visible, form, projectSelect } = this.props;
        const { fileList,submitting } = this.state;
        const props = {
            onRemove: (file) => {
                this.setState((state) => {
                    const index = state.fileList.indexOf(file);
                    const newFileList = state.fileList.slice();
                    newFileList.splice(index, 1);
                    return {
                        fileList: newFileList,
                    };
                });
            },
            beforeUpload: (file) => {
                this.setState(state => ({
                    fileList: [...state.fileList, file],
                }));
                return false;
            },
            fileList
        };
        // 附件下载
        const downloadFile = () => {
            const props = {
                fileList: [{
                    'uid': -1,
                    'name': '申报模板',
                    'status': 'done',
                    'url': `${window.location.origin}/server/api/file/download/template&expenditure.doc`,
                }],
                showUploadList: {
                    showPreviewIcon: true,
                    showRemoveIcon: false,
                },
            };
            return (<>
                <div style={{ marginTop: 10 }}>请先下载以下模板填写再上传</div>
                <Upload {...props} />
            </>);
        };

        return (
            <Form layout='horizontal' onSubmit={this.handleOk} hideRequiredMark style={{ marginTop: 20 }}>
                <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 8 }} label="项目名称">
                    {form.getFieldDecorator('project_id', {
                        rules: [{ required: true, message: '必选' }],
                    })(<Select showSearch optionFilterProp="children" placeholder="请选择" style={{ width: '100%' }}>{Object.keys(projectSelect).map(val => (<Option key={`${val}^${projectSelect[val]}`}>{projectSelect[val]}</Option>))}</Select>)}
                </FormItem>
                <FormItem label="金额" labelCol={{ span: 8 }} wrapperCol={{ span: 8 }}>
                    {form.getFieldDecorator('money', {
                        rules: [{ required: true, message: '必填', transform: value => String(value) }],
                    })(
                        <InputNumber min={0} />
                    )}
                </FormItem>
                <FormItem label="支付宝账号" labelCol={{ span: 8 }} wrapperCol={{ span: 8 }}>
                    {form.getFieldDecorator('alipay_num', {
                        rules: [{ required: true, message: '必填' }],
                    })(
                        <Input placeholder="请输入支付宝账号" />
                    )}
                </FormItem>
                <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 8 }} label="申请描述">
                    {form.getFieldDecorator('description', {
                        rules: [{ required: true, message: '请输入至少10个字符！', min: 10 }],
                    })(<TextArea style={{ minHeight: 32 }} placeholder='请输入申请描述' rows={4} />)}
                </FormItem>
                <FormItem label="附件上传" labelCol={{ span: 8 }} wrapperCol={{ span: 8 }} help={downloadFile()}>
                    <Upload name="expenditure" listType="picture" {...props}>
                        <Button>
                            <Icon type="upload" /> 上传
                        </Button>
                    </Upload>
                </FormItem>
                <div style={{ textAlign: 'center' }}>
                    <Button type="primary" htmlType="submit" loading={submitting}>
                        提交
                    </Button>
                </div>
            </Form>
        );
    };
};

export default AddForm;