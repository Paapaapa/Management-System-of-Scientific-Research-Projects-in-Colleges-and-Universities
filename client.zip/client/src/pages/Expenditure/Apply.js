import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import StandardTable from '@/components/StandardTable';
import { Button, Card, Divider, Dropdown, Icon, Menu, message, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import Link from 'umi/link';
import moment from 'moment';
import React, { Fragment, PureComponent } from 'react';
import styles from './Apply.less';
import CheckForm from './CheckForm';
import ReadDescription from './ReadDescription';
import AddForm from './AddForm';
import SearchForm from './SearchForm';
import {
  formatObj,
} from '@/utils/utils';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['申请成功，等待审核', '审核通过，等待发放', '审核不通过', '重新申请，等待审核', '已发放'];

@connect(({ eapply, loading, user, apply }) => ({
  eapply,
  loading: loading.models.rule,
  personSelect: user.personSelect,
  currentUser: user.currentUser,
  apply,
}))
class Apply extends PureComponent {
  state = {
    modalVisible: false,
    menuVal: 'all',
    selectedRows: [],
    checkVisible: false,
    readVisible: false,
  };

  columns = [
    {
      title: '项目名称',
      dataIndex: 'project_id',
      sorter: true,
      render: (text) => {
        const { apply: { projectSelect },currentUser } = this.props;
        return (<Link to={`/project/apply?Id=${text}&menuVal=${currentUser.role==='G'?'all':'self'}`}>{projectSelect[text]}</Link>)
      },
    },
    {
      title: '申报人',
      dataIndex: 'applyperson_id',
      sorter: true,
      render: text => {
        const { personSelect } = this.props;
        return personSelect[text];
      },
    },
    {
      title: '申报时间',
      dataIndex: 'apply_time',
      sorter: true,
      render: text => moment(text).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: '进度',
      dataIndex: 'status',
      sorter: true,
      render: val => PROGRESS[val],
    },
    {
      title: '操作',
      render: (text, record) => {
        const { currentUser } = this.props;
        const { menuVal } = this.state;
        const renderButton = {
          'G': {
            'self': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              {(record.status === 1 || record.status === 4) ? null : (<Divider type="vertical" />)}
              {(record.status === 1 || record.status === 4) ? null : (<a onClick={() => this.handleModalVisible(true, record)}>编辑</a>)}
              {(record.status === 0 || record.status === 2) ? (<Divider type="vertical" />) : null}
              {(record.status === 0 || record.status === 2) ? (<Popconfirm title="您确定撤销申报吗？" onConfirm={() => this.handleRollBack(record)} okText="确定" cancelText="取消"><a href="#">撤销</a>
              </Popconfirm>) : null}
              {record.status === 2 ? (<Divider type="vertical" />) : null}
              {record.status === 2 ? (<Popconfirm title="您确定重新申请审核吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请重新审核</a></Popconfirm>) : null}
            </Fragment>,
            'all': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
            </Fragment>,
            'noCheck': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              <Divider type="vertical" />
              <a onClick={() => this.handleCheckModalVisible(true, record)}>审核</a>
            </Fragment>,
            'noSend': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              <Divider type="vertical" />
              <Popconfirm title="您确定发放吗？" onConfirm={() => this.handleSend(record)} okText="确定" cancelText="取消"><a href="#">发放</a>
              </Popconfirm>
            </Fragment>,
            'sent': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
            </Fragment>,
            'checked': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              {record.status < 3 ? <Divider type="vertical" /> : null}
              {record.status < 3 ? <a onClick={() => this.handleCheckModalVisible(true, record)}>重新审核</a> : null}
            </Fragment>,
            'rollbacked': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              <Divider type="vertical" />
              <Popconfirm title="您确定恢复吗？" onConfirm={() => this.handleRestart(record)} okText="确定" cancelText="取消"><a href="#">恢复</a>
              </Popconfirm>
              <Divider type="vertical" />
              <Popconfirm title="您确定彻底删除吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消"><a href="#">彻底删除</a>
              </Popconfirm>
            </Fragment>,
          },
          'J': {
            'self': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              {(record.status === 1 || record.status === 4) ? null : (<Divider type="vertical" />)}
              {(record.status === 1 || record.status === 4) ? null : (<a onClick={() => this.handleModalVisible(true, record)}>编辑</a>)}
              {(record.status === 0 || record.status === 2) ? (<Divider type="vertical" />) : null}
              {(record.status === 0 || record.status === 2) ? (<Popconfirm title="您确定撤销申报吗？" onConfirm={() => this.handleRollBack(record)} okText="确定" cancelText="取消"><a href="#">撤销</a>
              </Popconfirm>) : null}
              {record.status === 2 ? (<Divider type="vertical" />) : null}
              {record.status === 2 ? (<Popconfirm title="您确定重新申请审核吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请重新审核</a></Popconfirm>) : null}
            </Fragment>,
            'rollbacked': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              <Divider type="vertical" />
              <Popconfirm title="您确定恢复吗？" onConfirm={() => this.handleRestart(record)} okText="确定" cancelText="取消"><a href="#">恢复</a>
              </Popconfirm>
              <Divider type="vertical" />
              <Popconfirm title="您确定彻底删除吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消"><a href="#">彻底删除</a>
              </Popconfirm>
            </Fragment>,
          },
          'Z': {
            'self': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              {(record.status === 1 || record.status === 4) ? null : (<Divider type="vertical" />)}
              {(record.status === 1 || record.status === 4) ? null : (<a onClick={() => this.handleModalVisible(true, record)}>编辑</a>)}
              {(record.status === 0 || record.status === 2) ? (<Divider type="vertical" />) : null}
              {(record.status === 0 || record.status === 2) ? (<Popconfirm title="您确定撤销申报吗？" onConfirm={() => this.handleRollBack(record)} okText="确定" cancelText="取消"><a href="#">撤销</a>
              </Popconfirm>) : null}
              {record.status === 2 ? (<Divider type="vertical" />) : null}
              {record.status === 2 ? (<Popconfirm title="您确定重新申请审核吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请重新审核</a></Popconfirm>) : null}
            </Fragment>,
            'rollbacked': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              <Divider type="vertical" />
              <Popconfirm title="您确定恢复吗？" onConfirm={() => this.handleRestart(record)} okText="确定" cancelText="取消"><a href="#">恢复</a>
              </Popconfirm>
              <Divider type="vertical" />
              <Popconfirm title="您确定彻底删除吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消"><a href="#">彻底删除</a>
              </Popconfirm>
            </Fragment>,
          },
        };
        return renderButton[currentUser.role][menuVal];
      },
    },
  ];

  componentDidMount() {
    const { dispatch, currentUser,location } = this.props;
    dispatch({
      type: 'apply/fetchSelect',
    });
    dispatch({
      type: 'user/fetchSelect',
    });
    if (location.query.Id) {
      this.handleRadioGroup({
        target: {
          value: location.query.menuVal,
          opt:'redirect'
        }
      });
      dispatch({
        type: 'eapply/changeSearchFormFields',
        payload: {
          Id: location.query.Id,
        },
      });
      this.doPageSearch();
    } else {
      this.handleRadioGroup({
        target: {
          value: currentUser.role === 'G' ? 'all' : 'self'
        }
      });
    }
  }

  componentWillUnmount(){
    const {dispatch}=this.props;
    dispatch({
      type: 'eapply/resetSearchData',
    });
    dispatch({
      type: 'eapply/resetList',
    });
    dispatch({
      type: 'eapply/saveTypeParams',
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const params = {
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'eapply/changeSearchFormFields',
      payload: params,
    })
    this.doPageSearch();
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (selectedRows.length === 0) return;
    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'eapply/remove',
          payload: {
            key: selectedRows.map(row => row.key),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
    const { dispatch } = this.props;
    dispatch({
      type: 'eapply/changeSelectedRows',
      payload: rows,
    });
  };

  handleModalVisible = (flag, record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'eapply/resetFormData',
    });
    this.setState({
      modalVisible: !!flag,
    });
    if (record) {
      dispatch({
        type: 'eapply/changeFormData',
        payload: record,
      });
    }
  };

  handleCheckModalVisible = (flag, record) => {
    const { dispatch } = this.props;
    this.setState({
      checkVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'eapply/changeFormData',
        payload: record,
      });
  };

  handleReadVisible = (flag, record) => {
    const { dispatch } = this.props;
    this.setState({
      readVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'eapply/changeFormData',
        payload: record,
      });
  }

  handleRecheck = (record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'eapply/changeFormData',
      payload: {
        ...formatObj(record),
        status: 3,
        is_check_pass: null,
        check_time: null,
        check_comment: null,
        opt:'recheck',
      },
    });
    dispatch({
      type: 'eapply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('申请成功');
        this.doPageSearch();
      } else {
        message.error('申请失败');
      }
    });
  }

  handleRestart = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'eapply/changeFormData',
      payload: {
        ...formatObj(record),
        del_flag: 0,
        opt: 'remain',
      },
    });
    dispatch({
      type: 'eapply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('恢复成功');
        this.doPageSearch();
      } else {
        message.error('恢复失败');
      }
    });
  }

  handleRemove = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'eapply/remove',
      payload: {
        Id: record.Id
      },
    }).then((res) => {
      if (res.code === 1) {
        message.success("删除成功");
        this.doPageSearch();
      } else {
        message.error("删除失败");
      }
    });
  }

  handleRefresh = () => {
    this.doPageSearch();
  }

  handleRadioGroup = (e) => {
    const {
      dispatch,
      currentUser
    } = this.props;
    const params = {};
    this.setState({
      menuVal: e.target.value,
    });
    if(!e.target.opt){
      dispatch({
        type: 'eapply/changeSearchFormFields',
        payload:{
          Id:'',
        }
      });
    }
    switch (e.target.value) {
      case 'self':
        params.applyperson_id = currentUser.Id;
        params.del_flag = 0;
        break;
      case 'noCheck':
        params.is_check_pass = 'null';
        params.del_flag = 0;
        break;
      case 'checked':
        params.is_check_pass = 'notNull';
        params.checkman_id = currentUser.Id;
        params.del_flag = 0;
        break;
      case 'noSend':
        params.check_time = 'notNull';
        params.is_check_pass = 1;
        params.send_time = 'null';
        params.del_flag = 0;
        break;
      case 'sent':
        params.send_time = 'notNull';
        params.sendman_id = currentUser.Id;
        params.del_flag = 0;
        break;
      case 'rollbacked':
        params.applyperson_id = currentUser.Id;
        params.del_flag = 1;
        break;
      default:
        params.del_flag = 0;
        break;
    }
    dispatch({
      type: 'eapply/saveTypeParams',
      payload: params,
    });
    this.doPageSearch();
  }

  handleRollBack = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'eapply/changeFormData',
      payload: {
        ...formatObj(record),
        del_flag: 1,
      },
    });
    dispatch({
      type: 'eapply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('撤销成功');
        this.doPageSearch();
      } else {
        message.error('撤销失败');
      }
    });
  }

  handleSend = (record) => {
    const {
      dispatch, currentUser
    } = this.props;
    if (record)
      dispatch({
        type: 'eapply/changeFormData',
        payload: {
          ...formatObj(record),
          send_time: moment().format('YYYY-MM-DD HH:mm:ss'),
          status: 4,
          sendman_id: currentUser.Id,
        },
      });
    dispatch({
      type: 'eapply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success("发放成功");
        this.doPageSearch();
      } else {
        message.error("发放失败");
      }
    });
  };

  doPageSearch() {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'eapply/fetch',
    });
  }

  render() {
    const {
      eapply: { data },
      loading,
      currentUser
    } = this.props;
    const { selectedRows, modalVisible, menuVal, checkVisible, readVisible } = this.state;
    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );

    data.pagination = {
      ...data.pagination,
      showTotal: total => `总计 ${total} 条数据`,
      pageSizeOptions: ['10', '20', '30'],
    };

    return (
      <PageHeaderWrapper title="经费结算">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              <SearchForm />
            </div>
            <div className={styles.tableListOperator}>
              <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                刷新
              </Button>
              <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
                申请
              </Button>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
              <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                {currentUser.role === 'G' ? (<RadioButton value="all">全部</RadioButton>) : null}
                <RadioButton value="self">个人申请</RadioButton>
                <RadioButton value="rollbacked">已撤销</RadioButton>
                {currentUser.role === 'G' ? (<RadioButton value="noCheck">待审核</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="checked">已审核</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="noSend">待发放</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="sent">已发放</RadioButton>) : null}
              </RadioGroup>
            </div>

            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={this.columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
              rowKey='Id'
            />
          </div>
        </Card>
        <AddForm visible={modalVisible} onCancel={() => this.handleModalVisible(false)} />
        <CheckForm visible={checkVisible} onCancel={() => this.handleCheckModalVisible(false)} />
        <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
      </PageHeaderWrapper>
    );
  }
}

export default Apply;
