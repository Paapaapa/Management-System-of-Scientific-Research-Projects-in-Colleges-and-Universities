import StandardTable from '@/components/StandardTable';
import { Button, Radio } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import styles from './Apply.less';
import ReadDescription from './ReadDescription';
import SearchForm from './SearchForm';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['申请成功，等待审批', '已审批', '已驳回', '重新申请，等待审批'];

@connect(({ eapply, loading, user, apply }) => ({
    eapply,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    apply,
}))
class Apply extends PureComponent {
    state = {
        menuVal: 'public',
        readVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'project_id',
            sorter: true,
            render: (text) => {
                const { apply: { projectSelect }, currentUser } = this.props;
                return (<Link to={`/project/apply?Id=${text}&menuVal=1`}>{projectSelect[text]}</Link>)
            },
        },
        {
            title: '申请人',
            dataIndex: 'applyperson_id',
            sorter: true,
            render: text => {
                const { personSelect } = this.props;
                return personSelect[text];
            },
        },
        {
            title: '申请时间',
            dataIndex: 'apply_time',
            sorter: true,
            render: text => moment(text).format('YYYY-MM-DD HH:mm:ss'),
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const renderBtn = {
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                }
                return (<>
                    {renderBtn.read}
                </>);
            },
        },
    ];

    componentDidMount() {
        const { dispatch, currentUser, location } = this.props;
        dispatch({
            type: 'apply/fetchSelect',
        });
        dispatch({
            type: 'user/fetchSelect',
        });
    }

    componentWillReceiveProps(nextProps){
        const { eapply: { isIndex } } = nextProps;
        if (isIndex) {
            this.setState({
                menuVal: 'public',
            })
        }
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'eapply/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'eapply/changeFormData',
                payload: record,
            });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleRadioGroup = (e) => {
        const {
            dispatch
        } = this.props;
        const params = {};
        this.setState({
            menuVal: e.target.value,
        });
        switch (e.target.value) {
            case 'all':
                params.del_flag = 0;
                break;
            default:
                params.is_check_pass = 1;
                params.del_flag = 0;
                break;
        }
        dispatch({
            type: 'eapply/changeIsIndex',
            payload: false,
        });
        dispatch({
            type: 'eapply/saveTypeParams',
            payload: params,
        });
        this.doPageSearch();
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'eapply/fetch',
        });
    }

    render() {
        const {
            eapply: { data },
            loading,
            currentUser
        } = this.props;
        const { menuVal, readVisible } = this.state;
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };
        return (
            <div className={styles.tableList}>
                <div className={styles.tableListForm}>
                    <SearchForm />
                </div>
                <div className={styles.tableListOperator}>
                    <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                        刷新
                    </Button>
                    {currentUser.role === 'G' ? <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                        <RadioButton value="all">全部</RadioButton>
                        <RadioButton value="public">公开</RadioButton>
                    </RadioGroup> : null}
                </div>
                <StandardTable
                    selectedRows={[]}
                    loading={loading}
                    data={data}
                    columns={this.columns}
                    onChange={this.handleStandardTableChange}
                    rowKey={record => record.Id}
                />
                <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
            </div>
        );
    }
}

export default Apply;
