import StandardTable from '@/components/StandardTable';
import { formatObj } from '@/utils/utils';
import { Button, Divider, message, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import AddForm from './AddForm';
import styles from './Apply.less';
import ReadDescription from './ReadDescription';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['申请成功，等待审批', '已审批', '已驳回', '重新申请，等待审批'];

@connect(({ eapply, loading, user, apply }) => ({
  eapply,
  loading: loading.models.rule,
  personSelect: user.personSelect,
  currentUser: user.currentUser,
  apply,
}))
class Apply extends PureComponent {
  state = {
    modalVisible: false,
    readVisible: false,
  };

  columns = [
    {
      title: '项目名称',
      dataIndex: 'project_id',
      sorter: true,
      render: (text) => {
        const { apply: { projectSelect }, currentUser } = this.props;
        return (<Link to={`/project/apply?Id=${text}&menuVal=1`}>{projectSelect[text]}</Link>)
      },
    },
    {
      title: '申请时间',
      dataIndex: 'apply_time',
      sorter: true,
      render: text => moment(text).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: '进度',
      dataIndex: 'status',
      sorter: true,
      render: val => PROGRESS[val],
    },
    {
      title: '操作',
      render: (text, record) => {
        const renderBtn = {
          'divider': <Divider type="vertical" />,
          'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
          'edit': <a onClick={() => this.handleModalVisible(true, record)}>编辑</a>,
          'rollback': <Popconfirm title="您确定撤销申报吗？" onConfirm={() => this.handleRollBack(record)} okText="确定" cancelText="取消"><a href="#">撤销</a></Popconfirm>,
          'restart': <Popconfirm title="您确定恢复吗？" onConfirm={() => this.handleRestart(record)} okText="确定" cancelText="取消"><a href="#">恢复</a></Popconfirm>,
          'remove': <Popconfirm title="您确定彻底删除吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消"><a href="#">彻底删除</a></Popconfirm>,
          'applyCheck': <Popconfirm title="您确定申请重新审批吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请审批</a></Popconfirm>,
        }
        return (<>
          {renderBtn.read}
          {record.status !== 1 ? (<>
            {renderBtn.divider}{renderBtn.edit}
          </>) : null}
          {record.status !== 1 && record.del_flag === 0 ? (<>
            {renderBtn.divider}{renderBtn.rollback}
          </>) : null}
          {record.status !== 1 && record.del_flag === 1 ? (<>
            {renderBtn.divider}{renderBtn.restart}{renderBtn.divider}{renderBtn.remove}
          </>) : null}
          {record.status === 2 ? (<>
            {renderBtn.divider}{renderBtn.applyCheck}
          </>) : null}
        </>);
      },
    },
  ];

  componentDidMount() {
    const { dispatch, currentUser, location } = this.props;
    dispatch({
      type: 'apply/fetchSelect',
    });
    dispatch({
      type: 'user/fetchSelect',
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const params = {
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'eapply/changeSearchFormFields',
      payload: params,
    })
    this.doPageSearch();
  };

  handleModalVisible = (flag, record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'eapply/resetFormData',
    });
    this.setState({
      modalVisible: !!flag,
    });
    if (record) {
      dispatch({
        type: 'eapply/changeFormData',
        payload: record,
      });
    }
  };

  handleReadVisible = (flag, record) => {
    const { dispatch } = this.props;
    this.setState({
      readVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'eapply/changeFormData',
        payload: record,
      });
  }

  handleRecheck = (record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'eapply/changeFormData',
      payload: {
        ...formatObj(record),
        status: 3,
        is_check_pass: null,
        check_time: null,
        check_comment: null,
        checkman_id:null,
        opt: 'apply',
      },
    });
    dispatch({
      type: 'eapply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('申请成功');
        this.doPageSearch();
      } else {
        message.error('申请失败');
      }
    });
  }

  handleRestart = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'eapply/changeFormData',
      payload: {
        ...formatObj(record),
        del_flag: 0,
        opt: 'remain',
      },
    });
    dispatch({
      type: 'eapply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('恢复成功');
        this.doPageSearch();
      } else {
        message.error('恢复失败');
      }
    });
  }

  handleRemove = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'eapply/remove',
      payload: {
        Id: record.Id
      },
    }).then((res) => {
      if (res.code === 1) {
        message.success("删除成功");
        this.doPageSearch();
      } else {
        message.error("删除失败");
      }
    });
  }

  handleRollBack = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'eapply/changeFormData',
      payload: {
        ...formatObj(record),
        del_flag: 1,
        opt:'rollback',
      },
    });
    dispatch({
      type: 'eapply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('撤销成功');
        this.doPageSearch();
      } else {
        message.error('撤销失败');
      }
    });
  }


  handleRefresh = () => {
    this.doPageSearch();
  }

  doPageSearch() {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'eapply/fetch',
    });
  }

  render() {
    const {
      eapply: { data },
      loading,
      currentUser
    } = this.props;
    const { modalVisible, readVisible } = this.state;
    data.pagination = {
      ...data.pagination,
      showTotal: total => `总计 ${total} 条数据`,
      pageSizeOptions: ['10', '20', '30'],
    };
    return (
      <div className={styles.tableList}>
        <div className={styles.tableListOperator}>
          <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
            刷新
              </Button>
        </div>
        <StandardTable
          selectedRows={[]}
          loading={loading}
          data={data}
          columns={this.columns}
          onChange={this.handleStandardTableChange}
          rowKey={record => record.Id}
        />
        <AddForm visible={modalVisible} onCancel={() => this.handleModalVisible(false)} />
        <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
      </div>
    );
  }
}

export default Apply;
