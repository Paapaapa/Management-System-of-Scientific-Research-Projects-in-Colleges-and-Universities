import dva from 'dva';
import createLoading from 'dva-loading';

const runtimeDva = window.g_plugins.mergeConfig('dva');
let app = dva({
  history: window.g_history,
  
  ...(runtimeDva.config || {}),
});

window.g_app = app;
app.use(createLoading());
(runtimeDva.plugins || []).forEach(plugin => {
  app.use(plugin);
});

app.model({ namespace: 'announce', ...(require('e:/Study/graduation/client/src/models/announce.js').default) });
app.model({ namespace: 'apply', ...(require('e:/Study/graduation/client/src/models/apply.js').default) });
app.model({ namespace: 'category', ...(require('e:/Study/graduation/client/src/models/category.js').default) });
app.model({ namespace: 'comment', ...(require('e:/Study/graduation/client/src/models/comment.js').default) });
app.model({ namespace: 'conclude', ...(require('e:/Study/graduation/client/src/models/conclude.js').default) });
app.model({ namespace: 'eapply', ...(require('e:/Study/graduation/client/src/models/eapply.js').default) });
app.model({ namespace: 'fapply', ...(require('e:/Study/graduation/client/src/models/fapply.js').default) });
app.model({ namespace: 'files', ...(require('e:/Study/graduation/client/src/models/files.js').default) });
app.model({ namespace: 'global', ...(require('e:/Study/graduation/client/src/models/global.js').default) });
app.model({ namespace: 'list', ...(require('e:/Study/graduation/client/src/models/list.js').default) });
app.model({ namespace: 'login', ...(require('e:/Study/graduation/client/src/models/login.js').default) });
app.model({ namespace: 'menu', ...(require('e:/Study/graduation/client/src/models/menu.js').default) });
app.model({ namespace: 'midcheck', ...(require('e:/Study/graduation/client/src/models/midcheck.js').default) });
app.model({ namespace: 'notice', ...(require('e:/Study/graduation/client/src/models/notice.js').default) });
app.model({ namespace: 'project', ...(require('e:/Study/graduation/client/src/models/project.js').default) });
app.model({ namespace: 'proposal', ...(require('e:/Study/graduation/client/src/models/proposal.js').default) });
app.model({ namespace: 'register', ...(require('e:/Study/graduation/client/src/models/register.js').default) });
app.model({ namespace: 'setting', ...(require('e:/Study/graduation/client/src/models/setting.js').default) });
app.model({ namespace: 'stop', ...(require('e:/Study/graduation/client/src/models/stop.js').default) });
app.model({ namespace: 'user', ...(require('e:/Study/graduation/client/src/models/user.js').default) });
