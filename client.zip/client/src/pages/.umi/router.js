import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import RendererWrapper0 from 'e:/Study/graduation/client/src/pages/.umi/LocaleWrapper.jsx'
import _dvaDynamic from 'dva/dynamic'

let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/",
    "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../../layouts/BasicLayout'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
    "Routes": [require('../Authorized').default],
    "routes": [
      {
        "path": "/",
        "redirect": "/index",
        "exact": true
      },
      {
        "path": "/index",
        "name": "home",
        "icon": "desktop",
        "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__Index__Index" */'../Index/Index'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/public",
        "name": "public",
        "icon": "eye",
        "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__Index__Public" */'../Index/Public'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/charts",
        "name": "charts",
        "icon": "fund",
        "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__Index__Charts" */'../Index/Charts'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
        "authority": [
          "G"
        ],
        "exact": true
      },
      {
        "path": "/project",
        "name": "projectManage",
        "icon": "profile",
        "authority": [
          "G",
          "Z",
          "J"
        ],
        "routes": [
          {
            "path": "/project/apply",
            "name": "apply",
            "icon": "plus-square",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__Project__Apply" */'../Project/Apply'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
            "authority": [
              "G",
              "Z",
              "J"
            ],
            "exact": true
          },
          {
            "path": "/project/excute",
            "name": "excute",
            "icon": "project",
            "routes": [
              {
                "path": "/project/excute/proposal",
                "name": "proposal",
                "icon": "pushpin",
                "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../Project/Proposal'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
                "exact": true
              },
              {
                "path": "/project/excute/midcheck",
                "name": "midcheck",
                "icon": "build",
                "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../Project/Midcheck'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
                "exact": true
              },
              {
                "path": "/project/excute/conclude",
                "name": "conclude",
                "icon": "bulb",
                "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../Project/Conclude'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
                "exact": true
              },
              {
                "path": "/project/excute/stop",
                "name": "stop",
                "icon": "exception",
                "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../Project/Stop'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
                "exact": true
              },
              {
                "component": () => React.createElement(require('E:/Study/graduation/client/node_modules/_umi-build-dev@1.8.0@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
              }
            ]
          },
          {
            "path": "/project/category",
            "name": "category",
            "icon": "tags",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__Project__Category" */'../Project/Category'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
            "authority": [
              "G"
            ],
            "exact": true
          },
          {
            "component": () => React.createElement(require('E:/Study/graduation/client/node_modules/_umi-build-dev@1.8.0@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/expenditure",
        "name": "expenditureManage",
        "icon": "money-collect",
        "authority": [
          "G",
          "Z",
          "J"
        ],
        "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__Expenditure" */'../Expenditure'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/fruit",
        "name": "fruitManage",
        "icon": "trophy",
        "authority": [
          "G",
          "Z",
          "J"
        ],
        "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__Fruit" */'../Fruit'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/system",
        "name": "systemManage",
        "icon": "setting",
        "authority": [
          "G",
          "Z",
          "J"
        ],
        "routes": [
          {
            "path": "/system/self",
            "name": "selfCenter",
            "icon": "user",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__User__Center__Center" */'../User/Center/Center'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/system/notice",
            "name": "notice",
            "icon": "bell",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__User__Notice__Notice" */'../User/Notice/Notice'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('E:/Study/graduation/client/node_modules/_umi-build-dev@1.8.0@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/person",
        "name": "personManage",
        "icon": "team",
        "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__User__Manage" */'../User/Manage'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
        "authority": [
          "G"
        ],
        "exact": true
      },
      {
        "path": "/announce",
        "name": "announce",
        "icon": "sound",
        "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__Announce" */'../Announce'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
        "authority": [
          "G"
        ],
        "exact": true
      },
      {
        "path": "/files",
        "name": "files",
        "icon": "file",
        "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__Files" */'../Files'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
        "authority": [
          "G"
        ],
        "exact": true
      },
      {
        "path": "/user",
        "hideInMenu": true,
        "routes": [
          {
            "path": "/user",
            "redirect": "/",
            "exact": true
          },
          {
            "path": "/user/login",
            "name": "login",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__User__Login__Login" */'../User/Login/Login'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/user/register",
            "name": "register",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__User__Register__Register" */'../User/Register/Register'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/user/register-result",
            "name": "register.result",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__User__Register__RegisterResult" */'../User/Register/RegisterResult'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('E:/Study/graduation/client/node_modules/_umi-build-dev@1.8.0@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "name": "exception",
        "icon": "warning",
        "path": "/exception",
        "hideInMenu": true,
        "routes": [
          {
            "path": "/exception/403",
            "name": "not-permission",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__Exception__models__error.js' */'e:/Study/graduation/client/src/pages/Exception/models/error.js').then(m => { return { namespace: 'error',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__Exception__403" */'../Exception/403'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/exception/404",
            "name": "not-find",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__Exception__models__error.js' */'e:/Study/graduation/client/src/pages/Exception/models/error.js').then(m => { return { namespace: 'error',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__Exception__404" */'../Exception/404'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/exception/500",
            "name": "server-error",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__Exception__models__error.js' */'e:/Study/graduation/client/src/pages/Exception/models/error.js').then(m => { return { namespace: 'error',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__Exception__500" */'../Exception/500'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('E:/Study/graduation/client/node_modules/_umi-build-dev@1.8.0@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "p__404" */'../404'),
  LoadingComponent: require('e:/Study/graduation/client/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('E:/Study/graduation/client/node_modules/_umi-build-dev@1.8.0@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "component": () => React.createElement(require('E:/Study/graduation/client/node_modules/_umi-build-dev@1.8.0@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
  }
];
window.g_routes = routes;
window.g_plugins.applyForEach('patchRoutes', { initialValue: routes });

// route change handler
function routeChangeHandler(location, action) {
  window.g_plugins.applyForEach('onRouteChange', {
    initialValue: {
      routes,
      location,
      action,
    },
  });
}
window.g_history.listen(routeChangeHandler);
routeChangeHandler(window.g_history.location);

export default function RouterWrapper() {
  return (
<RendererWrapper0>
          <Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
        </RendererWrapper0>
  );
}
