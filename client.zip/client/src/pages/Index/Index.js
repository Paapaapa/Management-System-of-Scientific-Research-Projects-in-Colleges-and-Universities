import { Badge, Card, Col, Icon, List, Row } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import Read from './Read';

@connect(({ apply, fapply, files, announce }) => ({
  apply,
  fapply,
  files,
  announce,
}))
class Index extends PureComponent {
  state = {
    type: 'p',
    item: {},
    visible: false,
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'apply/changeSearchFormFields',
      payload: {
        establish_time: 'notNull',
        del_flag: 0,
        pageSize:5,
      }
    });
    dispatch({
      type: 'fapply/changeSearchFormFields',
      payload: {
        confirm_time: 'notNull',
        del_flag: 0,
        pageSize:5,
      }
    });
    dispatch({
      type: 'announce/changeSearchFormFields',
      payload: {
        pageSize:5,
      }
    });
    dispatch({
      type: 'files/changeSearchFormFields',
      payload: {
        pageSize:5,
        is_public:1,
      }
    });
    dispatch({
      type: 'apply/fetch',
    });
    dispatch({
      type: 'apply/fetchSelect',
    });
    dispatch({
      type: 'user/fetchSelect',
    });
    dispatch({
      type: 'category/fetchSelect',
    });
    dispatch({
      type: 'fapply/fetch',
    });
    dispatch({
      type: 'announce/fetch',
    });
    dispatch({
      type: 'files/fetch',
    });
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'apply/resetSearchData',
    });
    dispatch({
      type: 'apply/resetList',
    });
    dispatch({
      type: 'fapply/resetSearchData',
    });
    dispatch({
      type: 'fapply/resetList',
    });
    dispatch({
      type: 'announce/resetSearchData',
    });
    dispatch({
      type: 'announce/resetList',
    });
    dispatch({
      type: 'files/resetSearchData',
    });
    dispatch({
      type: 'files/resetList',
    });
  }


  handleRead = (flag, item, type) => {
    this.setState({
      visible: !!flag,
    });
    if (item && type) {
      this.setState({
        item,
        type
      });
    }
  }

  render() {
    const {
      apply: { data: { list: plist, pagination: ppagination }, projectSelect },
      fapply: { data: { list: flist, pagination: fpagination } },
      announce: { data: { list: alist, pagination: apagination } },
      files: { data: { list: filist, pagination: fipagination } },
    } = this.props;
    const { type, item, visible } = this.state;
    return (
      <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
        <Read visible={visible} onCancel={() => this.handleRead(false)} type={type} record={item} />
        <Row gutter={20}>
          <Col span={16}>
            <Card
              title="项目展示"
              extra={<Link to="/public"><Icon type="double-right" style={{ marginLeft: '10px', color: '#100f0f85' }} /></Link>}
              style={{ marginBottom: '20px' }}
              hoverable='true'
            >
              <List
                itemLayout="horizontal"
                dataSource={plist}
                size="small"
                loading={ppagination.total === undefined}
                renderItem={item => (
                  <List.Item>
                    <List.Item.Meta
                      title={<a onClick={() => this.handleRead(true, item, 'p')}><Badge color="blue" text={item.name} /></a>}
                    // description={<Ellipsis length={50}>{item.description}</Ellipsis>}
                    // avatar={<Avatar icon='smile' style={{ color: '#1890ff', backgroundColor: '#e6f7ff' }} />}
                    />
                  </List.Item>
                )}
              />
            </Card>
            <Card
              title="成果展示"
              extra={<Link to="/public"><Icon type="double-right" style={{ marginLeft: '10px', color: '#100f0f85' }} /></Link>}
              hoverable='true'
            >
              <List
                itemLayout="horizontal"
                dataSource={flist}
                size="small"
                loading={fpagination.total === undefined}
                renderItem={item => (
                  <List.Item>
                    <List.Item.Meta
                      title={<a onClick={() => this.handleRead(true, item, 'f')}><Badge color="blue" text={projectSelect ?.[item.project_id]} /></a>}
                    // description={<Ellipsis length={50}>{item.description}</Ellipsis>}
                    // avatar={<Avatar icon='trophy' style={{ color: '#1890ff', backgroundColor: '#e6f7ff' }} />}
                    />
                  </List.Item>
                )}
              />
            </Card>
          </Col>
          <Col span={8}>
            <Card
              title="通知公告"
              extra={<Link to="/public"><Icon type="double-right" style={{ marginLeft: '10px', color: '#100f0f85' }} /></Link>}
              style={{ marginBottom: '20px' }}
              hoverable='true'
            >
              <List
                itemLayout="horizontal"
                dataSource={alist}
                size="small"
                loading={apagination.total === undefined}
                renderItem={item => (
                  <List.Item>
                    <List.Item.Meta
                      title={<a onClick={() => this.handleRead(true, item, 'a')}><Badge color="blue" text={item.title} /></a>}
                    // description={<Ellipsis length={50}>{item.content}</Ellipsis>}
                    // avatar={<Avatar icon='smile' style={{ color: '#1890ff', backgroundColor: '#e6f7ff' }} />}
                    />
                  </List.Item>
                )}
              />
            </Card>
            <Card
              title="文件专区"
              extra={<Link to="/public"><Icon type="double-right" style={{ marginLeft: '10px', color: '#100f0f85' }} /></Link>}
              hoverable='true'
            >
              <List
                itemLayout="horizontal"
                dataSource={filist}
                size="small"
                loading={fipagination.total === undefined}
                renderItem={item => (
                  <List.Item>
                    <a download href={`${window.location.origin}/server/api/file/download/template&${item.file_path}`}>{item.name}</a>
                  </List.Item>
                )}
              />
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Index;
