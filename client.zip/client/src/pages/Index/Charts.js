import { Bar, ChartCard, yuan, Field, MiniArea, MiniBar } from '@/components/Charts';
import { Row, Col, Card, Icon, Tooltip } from 'antd';
import Link from 'umi/link';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { AsyncLoadBizCharts } from '@/components/Charts/AsyncLoadBizCharts';
import numeral from 'numeral';

@connect(({ apply, fapply, eapply, proposal, midcheck, conclude }) => ({
    apply,
    fapply,
    eapply,
    proposal,
    midcheck,
    conclude
}))
class Charts extends PureComponent {

    componentWillMount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'eapply/fetchEBar',
        });
        dispatch({
            type: 'apply/fetchPArea',
            payload: {
                opt: 'g'
            }
        });
        dispatch({
            type: 'fapply/fetchFCharts',
            payload: {
                opt: 'g'
            }
        });
        dispatch({
            type: 'proposal/fetchPPBar',
        });
        dispatch({
            type: 'midcheck/fetchPMArea',
        });
        dispatch({
            type: 'conclude/fetchPCBar',
        });
    }

    render() {
        const {
            eapply: { EBar }, apply: { PArea }, proposal: { PPBar }, midcheck: { PMArea }, conclude: { PCBar }, fapply: { FCharts }
        } = this.props;

        return (
            <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
                <Row gutter={16}>
                    <Col span={6}>
                        <ChartCard
                            hoverable='true'
                            title="项目申报"
                            action={
                                <>
                                    <Tooltip title="到上月为止一年的项目申报立项情况">
                                        <Icon type="info-circle-o" />
                                    </Tooltip>
                                    <Link to="/project/apply"><Icon type="double-right" style={{ marginLeft: '10px', color: '#100f0f85' }} /></Link>
                                </>
                            }
                            total={numeral(PArea.reduce((sum, cur) => sum + cur.y, 0)).format('0,0')}
                            contentHeight={46}
                        >
                            <MiniArea
                                line
                                height={46}
                                data={PArea}
                            />
                        </ChartCard>
                    </Col>
                    <Col span={6}>
                        <ChartCard
                            hoverable='true'
                            title="项目开题"
                            action={
                                <>
                                    <Tooltip title="到上月为止一年的项目开题结束情况">
                                        <Icon type="info-circle-o" />
                                    </Tooltip>
                                    <Link to="/project/excute/proposal"><Icon type="double-right" style={{ marginLeft: '10px', color: '#100f0f85' }} /></Link>
                                </>
                            }
                            total={numeral(PPBar.reduce((sum, cur) => sum + cur.y, 0)).format('0,0')}
                            contentHeight={46}
                        >
                            <MiniArea
                                line
                                height={46}
                                data={PPBar}
                            />
                        </ChartCard>
                    </Col>
                    <Col span={6}>
                        <ChartCard
                            hoverable='true'
                            title="中期检查"
                            action={
                                <>
                                    <Tooltip title="到上月为止一年的项目中期检查结束情况">
                                        <Icon type="info-circle-o" />
                                    </Tooltip>
                                    <Link to="/project/excute/midcheck"><Icon type="double-right" style={{ marginLeft: '10px', color: '#100f0f85' }} /></Link>
                                </>
                            }
                            total={numeral(PMArea.reduce((sum, cur) => sum + cur.y, 0)).format('0,0')}
                            contentHeight={46}
                        >
                            <MiniArea
                                line
                                height={46}
                                data={PMArea}
                            />
                        </ChartCard>
                    </Col>
                    <Col span={6}>
                        <ChartCard
                            hoverable='true'
                            title="项目结题"
                            action={
                                <>
                                    <Tooltip title="到上月为止一年的项目结题结束情况">
                                        <Icon type="info-circle-o" />
                                    </Tooltip>
                                    <Link to="/project/excute/conclude"><Icon type="double-right" style={{ marginLeft: '10px', color: '#100f0f85' }} /></Link>
                                </>
                            }
                            total={numeral(PCBar.reduce((sum, cur) => sum + cur.y, 0)).format('0,0')}
                            contentHeight={46}
                        >
                            <MiniArea
                                line
                                height={46}
                                data={PCBar}
                            />
                        </ChartCard>
                    </Col>
                </Row>
                <Card
                    title="经费趋势"
                    extra={<Link to="/expenditure"><Icon type="double-right" style={{ marginLeft: '10px', color: '#100f0f85' }} /></Link>}
                    style={{ margin: '20px 0' }}
                    hoverable='true'
                >
                    <Row gutter={80}>
                        <Col span={16}>
                            <Bar
                                height={200}
                                data={EBar}
                            />
                        </Col>
                        <Col span={8}>
                            <ChartCard
                                style={{ marginTop: '20px' }}
                                title="年总发放额"
                                action={
                                    <Tooltip title="到上月为止一年的经费总发放金额">
                                        <Icon type="info-circle-o" />
                                    </Tooltip>
                                }
                                total={() => (
                                    <span dangerouslySetInnerHTML={{ __html: yuan(EBar.reduce((sum, cur) => sum + cur.y, 0)) }} />
                                )}
                                footer={
                                    <Field label="日均发放额" value={numeral(parseFloat(EBar.reduce((sum, cur) => sum + cur.y, 0)) / 365).format("0,0")} />
                                }
                            />
                        </Col>
                    </Row>
                </Card>
                <Card
                    title="成果统计"
                    extra={<Link to="/fruit"><Icon type="double-right" style={{ marginLeft: '10px', color: '#100f0f85' }} /></Link>}
                    style={{ marginBottom: '20px' }}
                    hoverable='true'
                >
                    <Row gutter={80}>
                        <Col span={16}>
                            <Bar
                                height={200}
                                data={FCharts}
                            />
                        </Col>
                        <Col span={8}>
                            <ChartCard
                                style={{ marginTop: '30px' }}
                                title="年成果总数"
                                action={
                                    <Tooltip title="到上月为止一年的成果总数">
                                        <Icon type="info-circle-o" />
                                    </Tooltip>
                                }
                                total={numeral(FCharts.reduce((sum, cur) => sum + cur.y, 0)).format('0,0')}
                            />
                        </Col>
                    </Row>
                </Card>
            </div>
        );
    }
}

export default props => (
    <AsyncLoadBizCharts>
        <Charts {...props} />
    </AsyncLoadBizCharts>
);