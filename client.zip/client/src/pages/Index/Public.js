import { Card, Col, Menu, Row, Table } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { PureComponent } from 'react';
import Read from './Read';

@connect(({ apply, fapply, files, announce }) => ({
    apply,
    fapply,
    files,
    announce,
}))
class Index extends PureComponent {
    state = {
        type: 'p',
        item: {},
        visible: false,
        key: 'announce',
    }

    componentWillMount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'apply/changeSearchFormFields',
            payload: {
                establish_time: 'notNull',
                del_flag: 0,
            }
        });
        dispatch({
            type: 'fapply/resetSearchData',
            payload: {
                confirm_time: 'notNull',
                del_flag: 0,
            }
        });
        dispatch({
            type: 'files/changeSearchFormFields',
            payload: {
              is_public:1,
            }
          });
        dispatch({
            type: 'apply/fetchSelect',
        });
        this.handleClick({
            key: 'announce',
        });
    }

    componentWillUnmount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'apply/resetSearchData',
        });
        dispatch({
            type: 'apply/resetList',
        });
        dispatch({
            type: 'fapply/resetSearchData',
        });
        dispatch({
            type: 'fapply/resetList',
        });
        dispatch({
            type: 'announce/resetList',
        });
        dispatch({
            type: 'announce/resetSearchData',
        });
        dispatch({
            type: 'files/resetList',
        });
        dispatch({
            type: 'files/resetSearchData',
        });
    }

    handleRead = (flag, item, type) => {
        this.setState({
            visible: !!flag,
        });
        if (item && type) {
            this.setState({
                item,
                type
            });
        }
    }

    handleClick = (e) => {
        const { dispatch } = this.props;
        switch (e.key) {
            case 'announce':
                dispatch({
                    type: 'announce/fetch',
                });
                break;
            case 'apply':
                dispatch({
                    type: 'apply/fetch',
                });
                break;
            case 'fapply':
                dispatch({
                    type: 'fapply/fetch',
                });
                break;
            case 'files':
                dispatch({
                    type: 'files/fetch',
                });
                break;
            default: break;
        }
        this.setState({
            key: e.key,
        });
    }

    getColumns = (key) => {
        const { apply:{projectSelect} } = this.props;
        switch (key) {
            case 'announce':
                return [
                    {
                        title: '序号',
                        key:'number',
                        render: (text, record, index) => index + 1,
                    },
                    {
                        title: '标题',
                        dataIndex: 'title',
                        key: 'title',
                        render: (text, record) => (<a onClick={() => this.handleRead(true, record, 'a')}>{text}</a>)
                    },
                    {
                        title: '发布日期',
                        dataIndex: 'upd_time',
                        key:'upd_time',
                        render: text => moment(text).format('YYYY-MM-DD'),
                    },
                ];
                break;
            case 'apply':
                return [
                    {
                        title: '序号',
                        key:'number',
                        render: (text, record, index) => index + 1,
                    },
                    {
                        title: '名称',
                        key:'name',
                        dataIndex: 'name',
                        render: (text, record) => (<a onClick={() => this.handleRead(true, record, 'p')}>{text}</a>)
                    },
                    {
                        title: '发布日期',
                        key:'upd_time',
                        dataIndex: 'upd_time',
                        render: text => moment(text).format('YYYY-MM-DD'),
                    },
                ];
                break;
            case 'fapply':
                return [
                    {
                        title: '序号',
                        key:'number',
                        render: (text, record, index) => index + 1,
                    },
                    {
                        title: '名称',
                        key:'project_id',
                        dataIndex: 'project_id',
                        render: (text, record) => (<a onClick={() => this.handleRead(true, record, 'f')}>{projectSelect ?.[text]}</a>)
                    },
                    {
                        title: '发布日期',
                        dataIndex: 'upd_time',
                        key:'upd_time',
                        render: text => moment(text).format('YYYY-MM-DD'),
                    },
                ];
                break;
            case 'files':
                return [
                    {
                        title: '序号',
                        key:'number',
                        render: (text, record, index) => index + 1,
                    },
                    {
                        title: '名称',
                        dataIndex: 'name',
                        key:'name',
                        render: (text, record) => (<a download href={`${window.location.origin}/server/api/file/download/template&${record.file_path}`}>{record.name}</a>)
                    },
                    {
                        title: '发布日期',
                        dataIndex: 'upd_time',
                        key:'upd_time',
                        render: text => moment(text).format('YYYY-MM-DD'),
                    },
                ];
                break;
            default: break;
        }
    }

    onChange = (page, pageSize) => {
        const { key } = this.state;
        const { dispatch } = this.props;
        const params = {
            pageNum: page,
            pageSize,
        }
        switch (key) {
            case 'announce':
                dispatch({
                    type: 'announce/changeSearchFormFields',
                    payload: params,
                });
                dispatch({
                    type: 'announce/fetch',
                });
                break;
            case 'apply':
                dispatch({
                    type: 'apply/changeSearchFormFields',
                    payload: params,
                });
                dispatch({
                    type: 'apply/fetch',
                });
                break;
            case 'fapply':
                dispatch({
                    type: 'fapply/changeSearchFormFields',
                    payload: params,
                });
                dispatch({
                    type: 'fapply/fetch',
                });
                break;
            case 'files':
                dispatch({
                    type: 'files/changeSearchFormFields',
                    payload: params,
                });
                dispatch({
                    type: 'files/fetch',
                });
                break;
        }
    }

    render() {
        const { type, item, visible, key } = this.state;

        return (
            <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
                <Read visible={visible} onCancel={() => this.handleRead(false)} type={type} record={item} />
                <Row gutter={10}>
                    <Col span={5} >
                        <Menu onClick={this.handleClick} mode="vertical" defaultSelectedKeys={["announce"]}>
                            <Menu.Item key="announce">通知公告</Menu.Item>
                            <Menu.Item key="apply">项目展示</Menu.Item>
                            <Menu.Item key="fapply">成果展示</Menu.Item>
                            <Menu.Item key="files">文件专区</Menu.Item>
                        </Menu>
                    </Col>
                    <Col span={19} >
                        <Card>
                            <Table
                                columns={this.getColumns(key)}
                                dataSource={this.props[key].data.list}
                                pagination={{
                                    ...this.props[key].data.pagination,
                                    showTotal: total => `总计 ${total} 条数据`,
                                    onChange: this.onChange,
                                }}
                                rowKey={record => record.Id} />
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default Index;
