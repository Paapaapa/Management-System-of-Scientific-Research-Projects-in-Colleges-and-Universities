import { Drawer, Upload, Divider, Timeline, Tooltip, Row, Col, Modal } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import DescriptionList from '@/components/DescriptionList';

const { Description } = DescriptionList;

@connect(({ apply, user, category }) => ({
    personSelect: user.personSelect,
    categorySelect: category.categorySelect,
    projectSelect: apply.projectSelect,
}))
class Read extends PureComponent {
    renderContent = () => {
        const { type, record, categorySelect, personSelect, projectSelect } = this.props;
        // 附件下载
        const downloadFile = () => {
            const props = {
                fileList: record ?.file_path ?.split(',') ?.map((val, index) => ({
                    'uid': index,
                    'name': val.split('_')[1],
                    'status': 'done',
                    'url': `${window.location.origin}/server/api/file/download/project&${val}`,
                })),
                showUploadList: {
                    showPreviewIcon: true,
                    showRemoveIcon: false,
                },
            };
            return record.file_path ? (<Upload {...props} />) : <>暂无附件</>;
        };
        switch (type) {
            case 'p':
                return (
                    <DescriptionList size="large" col={1} layout="vertical">
                        <Description term="项目名称">{record ?.name}</Description>
                        <Description term="项目类别">{categorySelect[record ?.category_id]}</Description>
                        <Description term="项目负责人">{personSelect[record ?.principal_id]}</Description>
                        <Description term="研究周期">{record ?.period}天</Description>
                        <Description term="经费预算">{record ?.money}元</Description>
                        <Description term="申报截止日期">{moment(record ?.end_time).format('YYYY-MM-DD')}</Description>
                        <Description term="项目简介">{record ?.description}</Description>
                        <Description term="预期成果">{record ?.fruit}</Description>
                        <Description term="申报时间">{moment(record ?.apply_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
                        <Description term="附件下载" >
                            <div style={{ marginLeft: '18px' }}>{downloadFile()}</div>
                        </Description>
                    </DescriptionList>
                );
                break;
            case 'f':
                return (
                    <DescriptionList size="large" col={1} layout="vertical">
                        <Description term="项目名称">{projectSelect[record ?.project_id]}</Description>
                        <Description term="项目类别">{categorySelect[record ?.category_id]}</Description>
                        <Description term="登记人">{personSelect[record ?.principal_id]}</Description>
                        <Description term="成果简介">
                            {record ?.description}
                        </Description>
                        <Description term="登记时间">{moment(record ?.apply_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
                        <Description term="附件下载" >
                            <div style={{ marginLeft: '18px' }}>{downloadFile()}</div>
                        </Description>
                    </DescriptionList>
                )
                break;
            case 'a':
                return (<p>{record ?.content}</p>)
                break;
            default: break;
        }
    }

    render() {
        const { visible, projectSelect, onCancel, record, type } = this.props;
        const title = {
            'p': `项目展示 —— ${record ?.name}`,
            'f': `成果展示 —— ${projectSelect ?.[record ?.project_id]}`,
            'a': `通知公告 —— ${record ?.title}`,
        };

        return (
            <Modal
                title={title[type]}
                visible={visible}
                onCancel={onCancel}
                footer={null}
                width={800}
                destroyOnClose
            >
                {this.renderContent()}
            </Modal>
        );
    }
}

export default Read;