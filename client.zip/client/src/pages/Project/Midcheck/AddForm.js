import { Form, Input, message, Modal, Select, Upload, Icon, Button } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { PureComponent } from 'react';
import { removeFile } from '@/services/api';
import {
  formatObj,
} from '@/utils/utils';

const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ midcheck, user }) => ({
  formData: midcheck.formData,
  currentUser: user.currentUser,
}))
@Form.create()
class AddForm extends PureComponent {
  state = {
    fileList: [],
  }

  componentWillReceiveProps(nextProps) {
    const {
      formData: nformData
    } = nextProps;
    const { formData } = this.props;
    if (nformData.file_path) {
      const files = nformData.file_path;
      this.setState({
        fileList: files.split(',').map((val, index) => {
          return {
            'uid': index,
            'name': val.split('_')[1],
            'status': 'done',
            'url': `${window.location.origin}/server/api/file/download/midcheck&${val}`,
          }
        }),
      });
    } else {
      this.setState({
        fileList: [],
      });
    }
  }

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      formData
    } = this.props;
    const {
      fileList
    } = this.state;
    const postData = new FormData();
    fileList.forEach((file) => {
      postData.append('files', file);
    });
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      if (formData.Id) {
        Object.keys(formData).forEach(val => {
          postData.append(val, formatObj({ [val]: formData[val] })[val]);
        });
        Object.keys(fieldsValue).forEach(val => {
          postData.set(val, fieldsValue[val]);
        })
        if (formData.file_path !== null) {
          // 和原来对比筛选出未被删除的文件，新上传的文件在后台添加进file_path
          postData.set('file_path', formData.file_path.split(',').filter(filename => fileList.some(file => file.url.split('&')[1] === filename)));
        }
        postData.append('opt', formData.submit_time ? '' : 'submit');
        postData.set('status', 2);
        postData.set('submit_time', moment().format('YYYY-MM-DD hh:mm:ss'));
      }
      dispatch({
        type: 'midcheck/changeFormData',
        payload: postData,
      });
      dispatch({
        type: 'midcheck/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("操作成功");
          this.setState({
            fileList: [],
          });
          dispatch({
            type: 'midcheck/fetch',
          });
        } else {
          message.error("操作失败");
        }
      });
    });
  };

  render() {
    const { visible, onCancel, form, formData } = this.props;
    const { fileList } = this.state;
    const props = {
      onRemove: (file) => {
        this.setState((state) => {
          const index = state.fileList.indexOf(file);
          const newFileList = state.fileList.slice();
          newFileList.splice(index, 1);
          return {
            fileList: newFileList,
          };
        });
        if (formData.Id) {
          removeFile({
            file_path: `./upload/midcheck/${file.url.split('&')[1]}`
          });
        }
      },
      beforeUpload: (file) => {
        this.setState(state => ({
          fileList: [...state.fileList, file],
        }));
        return false;
      },
      fileList
    };
    // 附件下载
    const downloadFile = () => {
      const props = {
        fileList: [{
          'uid': -1,
          'name': '申报模板',
          'status': 'done',
          'url': `${window.location.origin}/server/api/file/download/template&midcheck.doc`,
        }],
        showUploadList: {
          showPreviewIcon: true,
          showRemoveIcon: false,
        },
      };
      return (<>
        <div style={{ marginTop: 10 }}>请先下载以下模板填写再上传</div>
        <Upload {...props} />
      </>);
    };
    return (
      <Modal
        destroyOnClose
        title="项目中期检查"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} label="中期检查描述">
          {form.getFieldDecorator('description', {
            rules: [{ required: true, message: '请输入至少10个字符！', min: 10 }],
            initialValue: formData ?.description,
          })(<TextArea
            style={{ minHeight: 32 }}
            placeholder='请输入中期检查描述'
            rows={4}
          />)}
        </FormItem>
        <FormItem label="附件上传" labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} help={downloadFile()}>
          <Upload name="midcheck" listType="picture" {...props}>
            <Button>
              <Icon type="upload" /> 上传
            </Button>
          </Upload>
        </FormItem>
      </Modal>
    );
  };
};

export default AddForm;