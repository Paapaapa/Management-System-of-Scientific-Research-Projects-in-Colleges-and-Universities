import StandardTable from '@/components/StandardTable';
import { Button, Divider, Radio } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import styles from './Midcheck.less';
import ReadDescription from './ReadDescription';
import SearchForm from './SearchForm';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待管理员设置截止时间', '等待负责人提交材料', '等待专家评审', '评审通过，等待确认', '评审不通过', '申请重新评审，等待评审', '已确认'];

@connect(({ midcheck, loading, user, apply }) => ({
    midcheck,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    projectSelect: apply.projectSelect
}))
class midcheck extends PureComponent {
    state = {
        menuVal: 'public',
        readVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'project_id',
            sorter: true,
            render: (text) => {
                const { projectSelect } = this.props;
                return (<Link to={`/project/apply?menuVal=1&Id=${text}`}>{projectSelect[text]}</Link>)
            },
        },
        {
            title: '负责人',
            dataIndex: 'principal_id',
            sorter: true,
            render: text => {
                const { personSelect } = this.props;
                return personSelect[text];
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                };
                return (<>
                    {renderBtn.read}
                </>);
            },
        },
    ];

    componentDidMount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'apply/fetchSelect',
        });
    }

    componentWillReceiveProps(nextProps){
        const { midcheck: { isIndex } } = nextProps;
        if (isIndex) {
            this.setState({
                menuVal: 'public',
            })
        }
    }

    

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'midcheck/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        dispatch({
            type: 'midcheck/resetFormData',
        });
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'midcheck/changeFormData',
                payload: {
                    ...record,
                },
            });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleRadioGroup = (e) => {
        const {
            dispatch,
            currentUser
        } = this.props;
        const params = {};
        this.setState({
            menuVal: e.target.value,
        });
        switch (e.target.value) {
            case 'all':
                params.del_flag = 0;
                break;
            default:
                params.midcheck_time = 'notNull';
                params.del_flag = 0;
                break;
        }
        dispatch({
            type: 'midcheck/changeIsIndex',
            payload: false,
        });
        dispatch({
            type: 'midcheck/saveTypeParams',
            payload: params,
        });
        this.doPageSearch();
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'midcheck/fetch',
        });
    }

    render() {
        const {
            midcheck: { data },
            loading,
            currentUser
        } = this.props;
        const { menuVal, readVisible } = this.state;
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };
        return (
            <div className={styles.tableList}>
                <div className={styles.tableListForm}>
                    <SearchForm />
                </div>
                <div className={styles.tableListOperator}>
                    <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                        刷新
                    </Button>
                    {currentUser.role === 'G' ? (<RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                        <RadioButton value="all">所有</RadioButton>
                        <RadioButton value="public">公开</RadioButton>
                    </RadioGroup>) : null}
                </div>
                <StandardTable
                    selectedRows={[]}
                    loading={loading}
                    data={data}
                    columns={this.columns}
                    onChange={this.handleStandardTableChange}
                    rowKey={record => record.Id}
                />
                <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
            </div>
        );
    }
}

export default midcheck;
