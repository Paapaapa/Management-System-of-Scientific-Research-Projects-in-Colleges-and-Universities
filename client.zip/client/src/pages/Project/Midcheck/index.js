import { Card, Tabs } from 'antd';
import { connect } from 'dva';
import React, { Component } from 'react';
import PageHeaderWrapper from '../../../components/PageHeaderWrapper';
import Check from './Check';
import Extend from './Extend';
import Finish from './Finish';
import Public from './Public';
import Self from './Self';

const { TabPane } = Tabs;

@connect(({ user }) => ({
    user,
}))
class Index extends Component {
    state = {
        activeKey: '1',
    }

    componentDidMount() {
        const { dispatch, location } = this.props;
        const {Id,menuVal}=location.query;
        if(Id){
            dispatch({
                type: 'midcheck/changeSearchFormFields',
                payload: {
                  Id,
                },
            });
        }
        this.onChange(menuVal || this.state.activeKey);
    }

    componentWillUnmount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'midcheck/resetSearchData',
        });
        dispatch({
            type: 'midcheck/resetList',
        });
        dispatch({
            type: 'midcheck/saveTypeParams',
        });
    }

    onChange = (key) => {
        const {
            dispatch,
            user: { currentUser }
        } = this.props;
        const params = {};
        this.setState({
            activeKey: key,
        });
        switch (key) {
            case '1':
                params.midcheck_time = 'notNull';
                params.del_flag = 0;
                break;
            case '2':
                params.principal_id = currentUser.Id;
                params.del_flag = 0;
                break;
            case '3':
                params.setman_id = 'null';
                params.del_flag = 0;
                break;
            case '4':
                params.is_check_pass = 'null';
                params.checkman_id = 'null';
                params.submit_time = 'notNull';
                params.del_flag = 0;
                break;
            case '5':
                params.check_time = 'notNull';
                params.is_check_pass = 1;
                params.midcheck_time = 'null';
                params.del_flag = 0;
                break;
            default: break;
        }
        dispatch({
            type: 'midcheck/changeIsIndex',
            payload: true,
        });
        dispatch({
            type: 'midcheck/resetSearchData',
        });
        dispatch({
            type: 'midcheck/saveTypeParams',
            payload: params,
        });
        dispatch({
            type: 'midcheck/fetch',
        });
    }

    render() {
        const { user: { currentUser } } = this.props;
        const { activeKey } = this.state;

        return (
            <PageHeaderWrapper title="中期检查">
                <Card bordered={false}>
                    <Tabs defaultActiveKey="1" type="card" onChange={this.onChange} activeKey={activeKey}>
                        <TabPane tab="公开公示" key="1">
                            <Public />
                        </TabPane>
                        <TabPane tab="个人负责" key="2">
                            <Self />
                        </TabPane>
                        {currentUser.role === 'G' ? <TabPane tab="设置时间" key="3">
                            <Extend />
                        </TabPane> : null}
                        {currentUser.role === 'Z' ? <TabPane tab="评审项目" key="4">
                            <Check />
                        </TabPane> : null}
                        {currentUser.role === 'G' ? <TabPane tab="结束阶段" key="5">
                            <Finish />
                        </TabPane> : null}
                    </Tabs>
                </Card>
            </PageHeaderWrapper>
        );
    }
}

export default Index;