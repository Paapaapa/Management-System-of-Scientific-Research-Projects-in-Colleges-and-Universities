import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import StandardTable from '@/components/StandardTable';
import { Button, Card, Divider, Dropdown, Icon, Menu, message, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { Fragment, PureComponent } from 'react';
import styles from './Apply.less';
import AssignPersonForm from './AssignPersonForm';
import CheckForm from './CheckForm';
import ZCheckForm from './ZCheckForm';
import ReadDescription from './ReadDescription';
import AddForm from './AddForm';
import SearchForm from './SearchForm';
import {
    formatObj,
} from '@/utils/utils';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待初审', '等待分配专家评审', '初审未通过', '申请重新初审', '等待专家评审', '等待终审', '立项成功', '立项失败'];

@connect(({ apply, loading, user, category }) => ({
    apply,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
}))
class Apply extends PureComponent {
    state = {
        selectedRows: [],
        readVisible: false,
        menuVal:'noEstablish',
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'name',
            sorter: true,
        },
        {
            title: '负责人',
            dataIndex: 'principal_id',
            sorter: true,
            render: text => {
                const { personSelect } = this.props;
                return personSelect[text];
            },
        },
        {
            title: '类别',
            dataIndex: 'category_id',
            sorter: true,
            render: text => {
                const { categorySelect } = this.props;
                return categorySelect[text];
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const { currentUser } = this.props;
                const { menuVal } = this.state;
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                    'establish': <Popconfirm title="您确定同意立项吗？" onConfirm={() => this.handleEstablish(record, true)} okText="确定" cancelText="取消"><a href="#">同意立项</a></Popconfirm>,
                    'nestablish': <Popconfirm title="您确定不予立项吗？" onConfirm={() => this.handleEstablish(record, false)} okText="确定" cancelText="取消"><a href="#">不予立项</a></Popconfirm>
                };
                return (
                    <>
                        {renderBtn.read}
                        {
                              currentUser.Id !== record.principal_id && record.status === 5 ?
                                (<>{renderBtn.divider}{renderBtn.establish}{renderBtn.divider}{renderBtn.nestablish}</>) : null
                        }
                    </>
                );
            },
        },
    ];

    componentDidMount() {
        const { dispatch, location } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'category/fetchSelect',
        });
    }

    componentWillReceiveProps(nextProps){
        const { apply: { isIndex } } = nextProps;
        if (isIndex) {
            this.setState({
                menuVal: 'noEstablish',
            })
        }
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'apply/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleMenuClick = e => {
        const { dispatch } = this.props;
        const { selectedRows } = this.state;

        if (selectedRows.length === 0) return;
        switch (e.key) {
            case 'remove':
                dispatch({
                    type: 'apply/remove',
                    payload: {
                        key: selectedRows.map(row => row.key),
                    },
                    callback: () => {
                        this.setState({
                            selectedRows: [],
                        });
                    },
                });
                break;
            default:
                break;
        }
    };

    handleSelectRows = rows => {
        this.setState({
            selectedRows: rows,
        });
        const { dispatch } = this.props;
        dispatch({
            type: 'apply/changeSelectedRows',
            payload: rows,
        });
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'apply/changeFormData',
                payload: {
                    ...record,
                },
            });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleRadioGroup = (e) => {
        const {
            dispatch,
            currentUser
        } = this.props;
        const params = {};
        this.setState({
            menuVal: e.target.value,
        });
        switch (e.target.value) {
            case 'established':
                params.esman_id = currentUser.Id;
                params.del_flag = 0;
                break;
            default:
                params.status = 5;
                params.establish_time = 'null';
                params.del_flag = 0;
                break;
        }
        dispatch({
            type: 'apply/changeIsIndex',
            payload: false,
        });
        dispatch({
            type: 'apply/saveTypeParams',
            payload: params,
        });
        this.doPageSearch();
    }

    handleEstablish = (record, flag) => {
        const {
            dispatch, currentUser
        } = this.props;
        if (record)
            dispatch({
                type: 'apply/changeFormData',
                payload: {
                    ...formatObj(record),
                    establish_time: flag ? moment().format('YYYY-MM-DD HH:mm:ss') : null,
                    status: flag ? 6 : 7,
                    esman_id: currentUser.Id,
                    opt:flag?'finish':'',
                },
            });
        dispatch({
            type: 'apply/add',
        }).then((res) => {
            if (res.code === 1) {
                message.success("处理成功");
                this.doPageSearch();
            } else {
                message.error("处理失败");
            }
        });
    };

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'apply/fetch',
        });
    }

    render() {
        const {
            apply: { data },
            loading,
            currentUser
        } = this.props;
        const { selectedRows, menuVal, readVisible } = this.state;
        const menu = (
            <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
                <Menu.Item key="remove">删除</Menu.Item>
                <Menu.Item key="approval">批量审批</Menu.Item>
            </Menu>
        );
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };
        return (
            <Card bordered={false}>
                <div className={styles.tableList}>
                    <div className={styles.tableListOperator}>
                        <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                            刷新
                        </Button>
                        {/* {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )} */}
                        <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                            <RadioButton value="noEstablish">待处理</RadioButton>
                            <RadioButton value="established">已处理</RadioButton>
                        </RadioGroup>
                    </div>
                    <StandardTable
                        selectedRows={selectedRows}
                        loading={loading}
                        data={data}
                        columns={this.columns}
                        onSelectRow={this.handleSelectRows}
                        onChange={this.handleStandardTableChange}
                        rowKey={record=>record.Id}
                    />
                </div>
                <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
            </Card>
        );
    }
}

export default Apply;
