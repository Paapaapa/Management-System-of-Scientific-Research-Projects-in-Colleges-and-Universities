import StandardTable from '@/components/StandardTable';
import { Button, Card, Divider, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import styles from './Apply.less';
import AssignPersonForm from './AssignPersonForm';
import ReadDescription from './ReadDescription';
import SearchForm from './SearchForm';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待初审', '等待分配专家评审', '初审未通过', '申请重新初审', '等待专家评审', '等待终审', '立项成功', '立项失败'];

@connect(({ apply, loading, user, category }) => ({
    apply,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
}))
class Apply extends PureComponent {
    state = {
        menuVal: 'noAssign',
        assignPersonVisible: false,
        readVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'name',
            sorter: true,
        },
        {
            title: '负责人',
            dataIndex: 'principal_id',
            sorter: true,
            render: text => {
                const { personSelect } = this.props;
                return personSelect[text];
            },
        },
        {
            title: '类别',
            dataIndex: 'category_id',
            sorter: true,
            render: text => {
                const { categorySelect } = this.props;
                return categorySelect[text];
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const { currentUser } = this.props;
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                    'assign': <a onClick={() => this.handlePersonModalVisible(true, record)}>{record.assign_time ? '重新分配' : '分配专家'}</a>,
                };
                return (
                    <>
                        {renderBtn.read}
                        {
                           currentUser.Id !== record.principal_id &&
                                [1,4].includes(record.status) ?
                                (<>{renderBtn.divider}{renderBtn.assign}</>) : null
                        }
                    </>
                );
            },
        },
    ];

    componentDidMount() {
        const { dispatch, location } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'category/fetchSelect',
        });
    }

    componentWillReceiveProps(nextProps){
        const { apply: { isIndex } } = nextProps;
        if (isIndex) {
            this.setState({
                menuVal: 'noAssign',
            })
        }
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'apply/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handlePersonModalVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            assignPersonVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'apply/changeFormData',
                payload: {
                    ...record,
                },
            });
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'apply/changeFormData',
                payload: {
                    ...record,
                },
            });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleRadioGroup = (e) => {
        const {
            dispatch,
            currentUser
        } = this.props;
        const params = {};
        this.setState({
            menuVal: e.target.value,
        });
        switch (e.target.value) {
            case 'assigned':
                params.assign_time='notNull';
                params.assignman_id = currentUser.Id;
                params.del_flag = 0;
                break;
            default:
                params.is_check_pass = 1;
                params.check_time = 'notNull';
                params.assign_time='null';
                params.del_flag = 0;
                break;
        }
        dispatch({
            type: 'apply/changeIsIndex',
            payload: false,
        });
        dispatch({
            type: 'apply/saveTypeParams',
            payload: params,
        });
        this.doPageSearch();
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'apply/fetch',
        });
    }

    render() {
        const {
            apply: { data },
            loading,
            currentUser
        } = this.props;
        const { menuVal, assignPersonVisible, readVisible } = this.state;
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };
        return (
            <Card bordered={false}>
                <div className={styles.tableList}>
                    <div className={styles.tableListOperator}>
                        <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                            刷新
                        </Button>
                        <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                            <RadioButton value="noAssign">待处理</RadioButton>
                            <RadioButton value="assigned">已处理</RadioButton>
                        </RadioGroup>
                    </div>
                    <StandardTable
                        selectedRows={[]}
                        loading={loading}
                        data={data}
                        columns={this.columns}
                        onChange={this.handleStandardTableChange}
                        rowKey={record=>record.Id}
                    />
                </div>
                <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
                <AssignPersonForm visible={assignPersonVisible} onCancel={() => this.handlePersonModalVisible(false)} />
            </Card>
        );
    }
}

export default Apply;
