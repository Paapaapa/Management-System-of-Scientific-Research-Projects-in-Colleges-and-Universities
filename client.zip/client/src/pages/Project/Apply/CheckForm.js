import { Modal, Select, Form, message, Input } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { formatObj } from '@/utils/utils';

const { Option } = Select;
const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ apply, user }) => ({
  apply,
  personSelect: user.personSelect,
  currentUser: user.currentUser,
}))
@Form.create()
class Check extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      apply: { formData },
      currentUser
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'apply/changeFormData',
        payload: {
          ...formatObj(formData),
          ...fieldsValue,
          checkman_id: currentUser.Id,
          check_time: moment().format('YYYY-MM-DD HH:mm:ss'),
          status: fieldsValue.is_check_pass == '0' ? 2 : 1,
          opt:  'fcheck',
        },
      });
      dispatch({
        type: 'apply/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("审核成功");
          dispatch({
            type: 'apply/fetch',
          });
        } else {
          message.error("审核失败");
        }
      })
    });
  };

  render() {
    const { visible, onCancel, form, apply: { formData } } = this.props;

    return (
      <Modal
        destroyOnClose
        title="项目初审"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="是否合格">
          {form.getFieldDecorator('is_check_pass', {
            rules: [{ required: true, message: '必选' }],
            initialValue: formData.is_check_pass==0 || formData.is_check_pass ? String(formData ?.is_check_pass) : '',
          })(<Select
            style={{ width: 200 }}
            placeholder="请选择"
          >
            <Option key="0">不同意</Option>
            <Option key="1">同意</Option>
          </Select>)}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="评审意见">
          {form.getFieldDecorator('check_comment', {
            rules: [{ required: true, message: '必填' }],
            initialValue: formData ?.check_comment
        })(<TextArea
              style={{ minHeight: 32 }}
              placeholder='请输入申报建议'
              rows={4}
            />)}
        </FormItem>
      </Modal>
    );
  };
};

export default Check;