import { Form, Input, message, Modal } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';

const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ apply, user }) => ({
  apply,
  currentUser: user.currentUser,
}))
@Form.create()
class Check extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      apply: { formData,signFormData },
      currentUser
    } = this.props;
    let oringinSign={...signFormData};
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'apply/changeSignFormData',
        payload: {
          project_id:formData.Id,
          signman_id:currentUser.Id,
          ...signFormData,
          ...fieldsValue,
        },
      });
      dispatch({
        type: 'apply/addSign',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("申请成功");
          if(!oringinSign.Id){
          dispatch({
            type: 'apply/fetch',
          });
        }else{
            dispatch({
              type: 'apply/fetchSign',
            });
          }
        } else {
          message.error("申请失败");
        }
      })
    });
  };

  render() {
    const { visible, onCancel, form, apply: { signFormData } } = this.props;

    return (
      <Modal
        destroyOnClose
        title="申请加入"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="申请理由">
          {form.getFieldDecorator('sign_reason', {
            rules: [{ required: true, message: '必填' }],
            initialValue: signFormData ?.sign_reason,
        })(<TextArea
              style={{ minHeight: 32 }}
              placeholder='请输入申请理由'
              rows={4}
            />)}
        </FormItem>
      </Modal>
    );
  };
};

export default Check;