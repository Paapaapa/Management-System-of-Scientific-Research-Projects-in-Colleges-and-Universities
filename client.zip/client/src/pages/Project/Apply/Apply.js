import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import StandardTable from '@/components/StandardTable';
import { Button, Card, Divider, Dropdown, Icon, Menu, message, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { Fragment, PureComponent } from 'react';
import styles from './Apply.less';
import AssignPersonForm from './AssignPersonForm';
import CheckForm from './CheckForm';
import ZCheckForm from './ZCheckForm';
import ReadDescription from './ReadDescription';
import AddForm from './AddForm';
import SearchForm from './SearchForm';
import {
  formatObj,
} from '@/utils/utils';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待初审', '等待分配专家评审', '初审未通过', '申请重新初审', '等待专家评审', '等待终审', '立项成功', '立项失败'];

@connect(({ apply, loading, user, category }) => ({
  apply,
  loading: loading.models.rule,
  personSelect: user.personSelect,
  currentUser: user.currentUser,
  categorySelect: category.categorySelect,
}))
class Apply extends PureComponent {
  state = {
    modalVisible: false,
    menuVal: 'all',
    selectedRows: [],
    assignPersonVisible: false,
    checkVisible: false,
    readVisible: false,
    zCheckVisible: false,
  };

  columns = [
    {
      title: '项目名称',
      dataIndex: 'name',
      sorter: true,
    },
    {
      title: '负责人',
      dataIndex: 'principal_id',
      sorter: true,
      render: text => {
        const { personSelect } = this.props;
        return personSelect[text];
      },
    },
    {
      title: '类别',
      dataIndex: 'category_id',
      sorter: true,
      render: text => {
        const { categorySelect } = this.props;
        return categorySelect[text];
      },
    },
    {
      title: '进度',
      dataIndex: 'status',
      sorter: true,
      render: val => PROGRESS[val],
    },
    {
      title: '操作',
      render: (text, record) => {
        const { currentUser } = this.props;
        const { menuVal } = this.state;
        const renderBtn = {
          'divider': <Divider type="vertical" />,
          'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
          'edit': <a onClick={() => this.handleModalVisible(true, record)}>编辑</a>,
          'rollback': <Popconfirm title="您确定撤销申报吗？" onConfirm={() => this.handleRollBack(record)} okText="确定" cancelText="取消"><a href="#">撤销</a></Popconfirm>,
          'applyCheck': <Popconfirm title="您确定申请重新初审吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请初审</a></Popconfirm>,
          'restart': <Popconfirm title="您确定恢复已撤销的项目吗？" onConfirm={() => this.handleRestart(record)} okText="确定" cancelText="取消"><a href="#">恢复</a></Popconfirm>,
          'assign': <a onClick={() => this.handlePersonModalVisible(true, record)}>{record.assign_time?'重新分配':'分配专家'}</a>,
          'remove': <Popconfirm title="您确定彻底删除已撤销的项目吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消"><a href="#">彻底删除</a></Popconfirm>,
          'firstCheck': <a onClick={() => this.handleCheckModalVisible(true, record)}>{record.check_time !== null ? '重新审核' : '审核'}</a>,
          'zCheck': <a onClick={() => this.handleZCheckModalVisible(true, record)}>{record.zcheck.length > 0 && record.zcheck.some(val => val.expert_id === currentUser.Id) ? '重新评审' : '评审'}</a>,
          'establish': <Popconfirm title="您确定同意立项吗？" onConfirm={() => this.handleEstablish(record, true)} okText="确定" cancelText="取消"><a href="#">同意立项</a></Popconfirm>,
          'nestablish': <Popconfirm title="您确定不予立项吗？" onConfirm={() => this.handleEstablish(record, false)} okText="确定" cancelText="取消"><a href="#">不予立项</a></Popconfirm>
        };
        return (
          <>
            {renderBtn.read}
            {currentUser.Id === record.principal_id && record.del_flag === 0 &&
              (record.status === 0 || record.status === 2 || record.status === 3 || record.status === 7) ?
              (<>{renderBtn.divider}{renderBtn.edit}</>) : null}
            {currentUser.Id === record.principal_id && record.del_flag === 0 &&
              (record.status === 0 || record.status === 2 || record.status === 3 || record.status === 7) ?
              (<>{renderBtn.divider}{renderBtn.rollback}</>) : null}
            {currentUser.Id === record.principal_id &&
              record.del_flag === 1 ?
              (<>{renderBtn.divider}{renderBtn.restart}</>) : null}
            {currentUser.Id === record.principal_id &&
              record.del_flag === 1 ?
              (<>{renderBtn.divider}{renderBtn.remove}</>) : null}
            {
              currentUser.Id === record.principal_id &&
                (record.status === 2 || record.status === 7) ?
                (<>{renderBtn.divider}{renderBtn.applyCheck}</>) : null
            }
            {
              currentUser.role === 'G' && currentUser.Id !== record.principal_id && 
              (record.status === 0 || record.status===3) ?
                (<>{renderBtn.divider}{renderBtn.firstCheck}</>) : null
            }
            {
              currentUser.role === 'G' && currentUser.Id !== record.principal_id && 
              (record.status === 1 || record.status===4) ?
                (<>{renderBtn.divider}{renderBtn.assign}</>) : null
            }
            {
              record.expert_ids && record.expert_ids.split(',').includes(currentUser.Id) && (record.status === 4 || record.status===5) ?
                (<>{renderBtn.divider}{renderBtn.zCheck}</>) : null
            }
            {
              currentUser.role === 'G' && currentUser.Id !== record.principal_id && record.status === 5 ?
                (<>{renderBtn.divider}{renderBtn.establish}{renderBtn.divider}{renderBtn.nestablish}</>) : null
            }
          </>
        );
      },
    },
  ];

  componentDidMount() {
    const { dispatch, location } = this.props;
    dispatch({
      type: 'user/fetchSelect',
    });
    dispatch({
      type: 'category/fetchSelect',
    });
    if (location.query.Id) {
      this.handleRadioGroup({
        target: {
          value: location.query.menuVal,
          opt: 'redirect',
        }
      });
      dispatch({
        type: 'apply/changeSearchFormFields',
        payload: {
          Id: location.query.Id,
        },
      });
      this.doPageSearch();
    } else {
      this.handleRadioGroup({
        target: {
          value: 'all'
        }
      });
    }
    dispatch({
      type: 'apply/fetch',
    })
    //   .then(item => {
    //   //  if (item && item ?.code === 1) {
    //       // if ('WebSocket' in window) {
    //       socket = io(`ws://localhost:3003`);
    //       socket.emmit('client message', { msg: 'hi, server' });

    //       // socket.on()用于接收服务端发来的消息
    //       socket.on('connect', () => {
    //         console.log('client connect server');
    //       });
    //       socket.on('disconnect', () => {
    //         console.log('client disconnect');
    //       });
    //       // socket.onopen = () => {
    //       //   window.console.log('WebSocket链接已打开');
    //       // };
    //       // socket.onmessage = event => {
    //       //   window.console.log(`event`, event);
    //       //   if (event.data) {
    //       //     dispatch({
    //       //       type: 'apply/save',
    //       //       payload: event.response || {},
    //       //     });
    //       //   }
    //       // };
    //       // socket.onerror = event => {
    //       //   window.console.log('WebSocket连接错误', event);
    //       // };
    //     // } else window.console.error('该浏览器不支持WebSocket!');
    //   // }
    // });
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'apply/resetSearchData',
    });
    dispatch({
      type: 'apply/resetList',
    });
    dispatch({
      type: 'apply/saveTypeParams',
    });
    // socket.close();
    // socket.onclose = event => {
    //   window.console.log('WebSocket链接已关闭。', event);
    // };
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const params = {
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'apply/changeSearchFormFields',
      payload: params,
    })
    this.doPageSearch();
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (selectedRows.length === 0) return;
    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'apply/remove',
          payload: {
            key: selectedRows.map(row => row.key),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
    const { dispatch } = this.props;
    dispatch({
      type: 'apply/changeSelectedRows',
      payload: rows,
    });
  };

  handleModalVisible = (flag, record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'apply/resetFormData',
    });
    this.setState({
      modalVisible: !!flag,
    });
    if (record) {
      dispatch({
        type: 'apply/changeFormData',
        payload: record,
      });
    }
  };

  handlePersonModalVisible = (flag, record) => {
    const { dispatch } = this.props;
    this.setState({
      assignPersonVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'apply/changeFormData',
        payload: {
          ...record,
        },
      });
  };

  handleCheckModalVisible = (flag, record) => {
    const { dispatch } = this.props;
    this.setState({
      checkVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'apply/changeFormData',
        payload: {
          ...record,
        },
      });
  };

  handleZCheckModalVisible = (flag, record) => {
    const { dispatch, currentUser } = this.props;
    this.setState({
      zCheckVisible: !!flag,
    });
    if (record) {
      dispatch({
        type: 'apply/changeFormData',
        payload: {
          ...record,
        },
      });
      // dispatch({
      //   type:'apply/change'
      // })
      // if (record.zcheck.length > 0 && record.zcheck.some(val => val.expert_id === currentUser.Id)) {
        dispatch({
          type: 'apply/changeZCheckFormData',
          payload: record.zcheck.filter(val => val.expert_id === currentUser.Id)[0] || {},
        });
      // }
    }
  };

  handleReadVisible = (flag, record) => {
    const { dispatch } = this.props;
    this.setState({
      readVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'apply/changeFormData',
        payload: {
          ...record,
        },
      });
  }

  handleRecheck = (record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'apply/changeFormData',
      payload: {
        ...formatObj(record),
        status: 3,
        is_check_pass: null,
        check_time: null,
        check_comment: null,
        checkman_id:null,
        expert_ids:null,
        assign_time:null,
        assignman_id:null,
        esman_id:null,
        establish_time:null,
        opt: 'recheck',
      },
    });
    dispatch({
      type: 'apply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('操作成功');
        this.doPageSearch();
      } else {
        message.error('操作失败');
      }
    });
  }

  handleRefresh = () => {
    this.doPageSearch();
  }

  handleRadioGroup = (e) => {
    const {
      dispatch,
      currentUser
    } = this.props;
    const params = {};
    this.setState({
      menuVal: e.target.value,
    });
    if (!e.target.opt) {
      dispatch({
        type: 'apply/changeSearchFormFields',
        payload: {
          Id: '',
        }
      });
    }
    switch (e.target.value) {
      case 'self':
        params.principal_id = currentUser.Id;
        break;
      case 'noFCheck':
        params.is_check_pass = 'null';
        params.checkman_id = 'null';
        params.del_flag = 0;
        break;
      case 'fchecked':
        params.is_check_pass = 'notNull';
        params.checkman_id = currentUser.Id;
        params.del_flag = 0;
        break;
      case 'noCheck':
        params.expert_ids = currentUser.Id;
        params.del_flag = 0;
        break;
      case 'noAssign':
        params.expert_ids = 'null';
        params.del_flag = 0;
        break;
      case 'assigned':
        params.assignman_id = currentUser.Id;
        params.del_flag = 0;
        break;
      case 'noEstablish':
        params.status = 5;
        params.establish_time = 'null';
        params.del_flag = 0;
        break;
      case 'established':
        params.esman_id = currentUser.Id;
        params.establish_time = 'notNull';
        params.del_flag = 0;
        break;
      default:
        params.del_flag = 0;
        params.establish_time = currentUser.role === 'G' ? '' : 'notNull';
        break;
    }
    dispatch({
      type: 'apply/saveTypeParams',
      payload: params,
    });
    this.doPageSearch();
  }

  handleRollBack = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'apply/changeFormData',
      payload: {
        ...formatObj(record),
        del_flag: 1,
      },
    });
    dispatch({
      type: 'apply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('撤销成功');
        this.doPageSearch();
      } else {
        message.error('撤销失败');
      }
    });
  }

  handleRestart = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'apply/changeFormData',
      payload: {
        ...formatObj(record),
        del_flag: 0,
        opt: 'remain',
      },
    });
    dispatch({
      type: 'apply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('恢复成功');
        this.doPageSearch();
      } else {
        message.error('恢复失败');
      }
    });
  }

  handleEstablish = (record, flag) => {
    const {
      dispatch, currentUser
    } = this.props;
    if (record)
      dispatch({
        type: 'apply/changeFormData',
        payload: {
          ...formatObj(record),
          establish_time: flag ? moment().format('YYYY-MM-DD HH:mm:ss') : null,
          status: flag ? 6 : 7,
          esman_id: currentUser.Id,
        },
      });
    dispatch({
      type: 'apply/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success("立项成功");
        this.doPageSearch();
      } else {
        message.error("立项失败");
      }
    });
  };

  handleRemove = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'apply/remove',
      payload: {
        Id: record.Id
      },
    }).then((res) => {
      if (res.code === 1) {
        message.success("删除成功");
        this.doPageSearch();
      } else {
        message.error("删除失败");
      }
    });
  }

  doPageSearch() {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'apply/fetch',
    });
  }

  render() {
    const {
      apply: { data },
      loading,
      currentUser
    } = this.props;
    const { selectedRows, modalVisible, menuVal, assignPersonVisible, checkVisible, zCheckVisible, readVisible } = this.state;
    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );

    data.pagination = {
      ...data.pagination,
      showTotal: total => `总计 ${total} 条数据`,
      pageSizeOptions: ['10', '20', '30'],
    };

    return (
      <PageHeaderWrapper title="项目申报">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              <SearchForm />
            </div>
            <div className={styles.tableListOperator}>
              <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                刷新
              </Button>
              <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
                申报
              </Button>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
              <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                <RadioButton value="all">全部</RadioButton>
                <RadioButton value="self">个人申报</RadioButton>
                {currentUser.role === 'G' ? (<RadioButton value="noFCheck">初审</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="fchecked">已初审</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="noAssign">分配专家</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="assigned">已分配</RadioButton>) : null}
                {currentUser.role === 'Z' ? (<RadioButton value="noCheck">评审</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="noEstablish">立项</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="established">已立项</RadioButton>) : null}
              </RadioGroup>
            </div>

            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={this.columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
              rowKey="Id"
            />
          </div>
        </Card>
        <AddForm visible={modalVisible} onCancel={() => this.handleModalVisible(false)} />
        <AssignPersonForm visible={assignPersonVisible} onCancel={() => this.handlePersonModalVisible(false)} />
        <CheckForm visible={checkVisible} onCancel={() => this.handleCheckModalVisible(false)} />
        <ZCheckForm visible={zCheckVisible} onCancel={() => this.handleZCheckModalVisible(false)} />
        <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
      </PageHeaderWrapper>
    );
  }
}

export default Apply;
