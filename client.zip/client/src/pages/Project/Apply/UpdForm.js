import { Form, Input, message, Modal, Select, Upload, Icon, Button, InputNumber, DatePicker } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import moment from 'moment';
import { removeFile } from '@/services/api';
import {
    formatObj,
} from '@/utils/utils';

const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;

@connect(({ apply, user, category }) => ({
    formData: apply.formData,
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
}))
@Form.create()
class AddForm extends PureComponent {
    state = {
        fileList: [],
    }

    componentWillReceiveProps(nextProps) {
        const {
            formData: nformData
        } = nextProps;
        if (nformData.file_path) {
            const files = nformData.file_path;
            this.setState({
                fileList: files.split(',').map((val, index) => {
                    return {
                        'uid': index,
                        'name': val.split('_')[1],
                        'status': 'done',
                        'url': `${window.location.origin}/server/api/file/download/project&${val}`,
                    }
                }),
            });
        } else {
            this.setState({
                fileList: [],
            });
        }
    }

    handleOk = () => {
        const {
            dispatch,
            form,
            onCancel,
            formData,
            currentUser
        } = this.props;
        const {
            fileList
        } = this.state;
        const postData = new FormData();
        fileList.forEach((file) => {
            postData.append('files', file);
        });
        form.validateFields((err, fieldsValue) => {
            if (err) return;
            form.resetFields();
            Object.keys(formData).forEach(val => {
                postData.append(val, formatObj({ [val]: formData[val] })[val]);
            })
            Object.keys(fieldsValue).forEach(val => {
                postData.set(val, formatObj({ [val]: fieldsValue[val] })[val]);
            })
            if (formData.file_path !== null) {
                postData.set('file_path', formData.file_path.split(',').filter(filename => fileList.some(file => file.url.split('&')[1] === filename)));
            }
            dispatch({
                type: 'apply/changeFormData',
                payload: postData,
            });
            dispatch({
                type: 'apply/add',
            }).then((res) => {
                if (res.code === 1) {
                    onCancel();
                    message.success("操作成功");
                    this.setState({
                        fileList: [],
                    });
                    dispatch({
                        type: 'apply/fetch',
                    });
                } else {
                    message.error("操作失败");
                }
            });
        });
    };

    render() {
        const { visible, onCancel, form, formData, categorySelect } = this.props;
        const { fileList } = this.state;
        const props = {
            onRemove: (file) => {
                this.setState((state) => {
                    const index = state.fileList.indexOf(file);
                    const newFileList = state.fileList.slice();
                    newFileList.splice(index, 1);
                    return {
                        fileList: newFileList,
                    };
                });
                if (formData.Id) {
                    removeFile({
                        file_path: `./upload/project/${file.url.split('&')[1]}`
                    });
                }
            },
            beforeUpload: (file) => {
                this.setState(state => ({
                    fileList: [...state.fileList, file],
                }));
                return false;
            },
            fileList
        };
        // 附件下载
        const downloadFile = () => {
            const props = {
                fileList: [{
                    'uid': -1,
                    'name': '申报模板',
                    'status': 'done',
                    'url': `${window.location.origin}/server/api/file/download/template&apply.doc`,
                }],
                showUploadList: {
                    showPreviewIcon: true,
                    showRemoveIcon: false,
                },
            };
            return (<>
                <div style={{ marginTop: 10 }}>请下载以下模板，按照模板填写，并上传</div>
                <Upload {...props} />
            </>);
        };

        return (
            <Modal
                destroyOnClose
                title="项目申报"
                visible={visible}
                onOk={this.handleOk}
                onCancel={onCancel}
            >
                <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} label="项目名称">
                    {form.getFieldDecorator('name', {
                        rules: [{ required: true, message: '必填' }],
                        initialValue: formData ?.name,
                    })(<Input placeholder="请输入项目名称" />)}
                </FormItem>
                <FormItem label="项目类别" labelCol={{ span: 6 }} wrapperCol={{ span: 16 }}>
                    {form.getFieldDecorator('category_id', {
                        rules: [{ required: true, message: '必选' }],
                        initialValue: formData ?.category_id,
                    })(
                        <Select placeholder="请选择" style={{ width: '100%' }}>
                            {Object.keys(categorySelect).map(val => (<Option key={val}>{categorySelect[val]}</Option>))}
                        </Select>
                    )}
                </FormItem>
                <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} label="研究周期">
                    {form.getFieldDecorator('period', {
                        rules: [{ required: true, message: '必填' }],
                        initialValue: formData ?.period || 1,
                    })(<InputNumber min={1} max={90} />)}
                </FormItem>
                <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} label="经费预算">
                    {form.getFieldDecorator('money', {
                        rules: [{ required: true, message: '必填' }],
                        initialValue: formData ?.money || 0,
                    })(<InputNumber min={0} step={100.00} precision={2} />)}
                </FormItem>
                <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} label="申报截止日期">
                    {form.getFieldDecorator('end_time', {
                        rules: [{ required: true, message: '日期未选择' }],
                        initialValue: formData.end_time ? moment(formData.end_time) : '',
                    })(<DatePicker />)}
                </FormItem>
                <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} label="项目简介">
                    {form.getFieldDecorator('description', {
                        rules: [{ required: true, message: '请输入至少10个字符', min: 10 }],
                        initialValue: formData ?.description,
                    })(<TextArea
                        style={{ minHeight: 32 }}
                        placeholder='请输入项目简介'
                        rows={4}
                    />)}
                </FormItem>
                <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} label="预期成果">
                    {form.getFieldDecorator('fruit', {
                        rules: [{ required: true, message: '请输入至少10个字符', min: 10 }],
                        initialValue: formData ?.fruit,
                    })(<TextArea
                        style={{ minHeight: 32 }}
                        placeholder='请输入预期成果'
                        rows={4}
                    />)}
                </FormItem>
                <FormItem label="附件上传" labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} help={downloadFile()}>
                    <Upload name="project" listType="picture" {...props}>
                        <Button>
                            <Icon type="upload" /> 上传
            </Button>
                    </Upload>
                </FormItem>
            </Modal>
        );
    };
};

export default AddForm;