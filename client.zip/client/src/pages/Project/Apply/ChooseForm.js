import { Modal, message, Table } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { formatObj } from '@/utils/utils';
import Ellipsis from '@/components/Ellipsis';
import { addSign } from '@/services/api';
import { resolve } from 'path';

@connect(({ apply, user }) => ({
    apply,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
}))
class Check extends PureComponent {
    state = {
        selectedRowKeys: [],
        selectedRows: [],
    };

    componentWillReceiveProps(nextProps) {
        const {
            apply: { formData: { member_ids, sign } }, visible
        } = nextProps;
        if (visible) {
            this.setState({
                selectedRows: sign.length > 0 && member_ids ? sign.filter(val => member_ids.split(',').includes(val.signman_id)) : [],
                selectedRowKeys: sign.length > 0 && member_ids ? sign.filter(val => member_ids.split(',').includes(val.signman_id)).map(val => val.Id) : [],
            });
        }
    }

    handleOk = () => {
        const {
            dispatch,
            onCancel,
            apply: { formData },
            currentUser
        } = this.props;
        dispatch({
            type: 'apply/changeFormData',
            payload: {
                ...formatObj(formData),
                member_ids: this.state.selectedRows.map(val => val.signman_id).join(','),
            },
        });
        dispatch({
            type: 'apply/add',
        }).then((res) => {
            if (res.code === 1) {
                onCancel();
                message.success("选择成功");
                Promise.all(this.state.selectedRows.map(val =>
                    addSign({
                        ...val,
                        is_checked: 1,
                    })
                ));
                Promise.all(
                    formData.sign.filter(val => !this.state.selectedRowKeys.includes(val.Id))
                        .map(val =>
                            addSign({
                                ...val,
                                is_checked: 0,
                            })
                        ));
                dispatch({
                    type: 'apply/fetch',
                });
            } else {
                message.error("选择失败");
            }
        })
    };

    columns = [{
        title: '申请人员',
        dataIndex: 'signman_id',
        render: text => {
            const { personSelect } = this.props;
            return personSelect[text];
        },
    }, {
        title: '申请理由',
        dataIndex: 'sign_reason',
        render: text => (<Ellipsis length={40} tooltip>{text}</Ellipsis>),
    }]

    onSelectChange = (selectedRowKeys, selectedRows) => {
        console.log('selectedRowKeys changed: ', selectedRowKeys);
        this.setState({ selectedRowKeys, selectedRows });
    }

    render() {
        const { visible, onCancel, form, apply: { formData } } = this.props;
        const { selectedRowKeys } = this.state;
        const rowSelection = {
            selectedRowKeys,
            onChange: this.onSelectChange,
        };

        return (
            <Modal
                destroyOnClose
                title="选择成员"
                visible={visible}
                onOk={this.handleOk}
                onCancel={onCancel}
            >
                <Table rowSelection={rowSelection} rowKey={(record) => record.Id} columns={this.columns} dataSource={formData.sign || []} pagination={false} />
            </Modal>
        );
    };
};

export default Check;