import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import StandardTable from '@/components/StandardTable';
import { Button, Card, Divider, Dropdown, Icon, Menu, message, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { Fragment, PureComponent } from 'react';
import styles from './Apply.less';
import ReadDescription from './ReadDescription';
import SearchForm from './SearchForm';
import SignForm from './SignForm';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;

@connect(({ apply, loading, user, category }) => ({
    apply,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
}))
class Apply extends PureComponent {
    state = {
        readVisible: false,
        menuVal: 'public',
        signVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'name',
            sorter: true,
        },
        {
            title: '负责人',
            dataIndex: 'principal_id',
            sorter: true,
            render: text => {
                const { personSelect } = this.props;
                return personSelect[text];
            },
        },
        {
            title: '类别',
            dataIndex: 'category_id',
            sorter: true,
            render: text => {
                const { categorySelect } = this.props;
                return categorySelect[text];
            },
        },
        {
            title: '申报截止日期',
            dataIndex: 'end_time',
            sorter: true,
            render: text => moment(text).format('YYYY-MM-DD'),
        },
        {
            title: '操作',
            render: (text, record) => {
                const { currentUser } = this.props;
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                    'sign': <a onClick={() => this.handleSignVisible(true, record)}>申请加入</a>,
                };
                return (
                    <>
                        {renderBtn.read}
                        {
                             // 超过截止时间，负责人本人，已经报过名的不可以重复报名
                            record.principal_id !== currentUser.Id && moment(record.end_time).isAfter(moment()) && !record ?.sign ?.some(val => val.signman_id === currentUser.Id) ?
                                (<>{renderBtn.divider}{renderBtn.sign}</>) : null
                        }
                    </>
                );
            },
        },
    ];

    componentDidMount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'category/fetchSelect',
        });
    }

    componentWillReceiveProps(nextProps) {
        const { apply: { isIndex } } = nextProps;
        if (isIndex) {
            this.setState({
                menuVal: 'public',
            })
        }
    }

    handleRadioGroup = (e) => {
        const {
            dispatch,
            currentUser
        } = this.props;
        const params = {};
        this.setState({
            menuVal: e.target.value,
        });
        switch (e.target.value) {
            case 'all':
                params.del_flag = 0;
                break;
            default:
                params.establish_time = 'notNull';
                params.del_flag = 0;
                break;
        }
        dispatch({
            type: 'apply/changeIsIndex',
            payload: false,
        });
        dispatch({
            type: 'apply/saveTypeParams',
            payload: params,
        });
        this.doPageSearch();
    }

    handleSignVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            signVisible: !!flag,
        });
        dispatch({
            type: 'apply/changeSignFormData',
            payload: {},
        });
        if (record)
            dispatch({
                type: 'apply/changeFormData',
                payload: record,
            });
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'apply/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'apply/changeFormData',
                payload: {
                    ...record,
                },
            });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'apply/fetch',
        });
    }

    render() {
        const {
            apply: { data },
            loading,
            currentUser
        } = this.props;
        const { readVisible, menuVal, signVisible } = this.state;
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };
        return (
            <Card bordered={false}>
                <div className={styles.tableList}>
                    <div className={styles.tableListForm}>
                        <SearchForm />
                    </div>
                    <div className={styles.tableListOperator}>
                        <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                            刷新
                        </Button>
                        {currentUser.role === 'G' ? <RadioGroup style={{ float: "right" }} onChange={this.handleRadioGroup} value={menuVal}>
                            <RadioButton value="public">公开</RadioButton>
                            <RadioButton value="all">所有</RadioButton>
                        </RadioGroup> : null}
                    </div>
                    <StandardTable
                        selectedRows={[]}
                        loading={loading}
                        data={data}
                        columns={this.columns}
                        onChange={this.handleStandardTableChange}
                        rowKey={record=>record.Id}
                    />
                    <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
                    <SignForm visible={signVisible} onCancel={() => this.handleSignVisible(false)} />
                </div>
            </Card>
        );
    }
}

export default Apply;