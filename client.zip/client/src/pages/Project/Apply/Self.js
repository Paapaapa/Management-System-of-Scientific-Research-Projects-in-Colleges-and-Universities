import StandardTable from '@/components/StandardTable';
import { formatObj } from '@/utils/utils';
import { Button, Card, Divider, Menu, message, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import styles from './Apply.less';
import ReadDescription from './ReadDescription';
import SearchForm from './SearchForm';
import UpdForm from './UpdForm';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待初审', '等待分配专家评审', '初审未通过', '申请重新初审', '等待专家评审', '等待终审', '立项成功', '立项失败'];

@connect(({ apply, loading, user, category }) => ({
    apply,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
}))
class Apply extends PureComponent {
    state = {
        selectedRows: [],
        readVisible: false,
        updVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'name',
            sorter: true,
        },
        {
            title: '类别',
            dataIndex: 'category_id',
            sorter: true,
            render: text => {
                const { categorySelect } = this.props;
                return categorySelect[text];
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const { currentUser } = this.props;
                const { menuVal } = this.state;
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                    'edit': <a onClick={() => this.handleUpdVisible(true, record)}>编辑</a>,
                    'rollback': <Popconfirm title="您确定撤销申报吗？" onConfirm={() => this.handleRollBack(record)} okText="确定" cancelText="取消"><a href="#">撤销</a></Popconfirm>,
                    'applyCheck': <Popconfirm title="您确定申请重新初审吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请初审</a></Popconfirm>,
                    'restart': <Popconfirm title="您确定恢复已撤销的项目吗？" onConfirm={() => this.handleRestart(record)} okText="确定" cancelText="取消"><a href="#">恢复</a></Popconfirm>,
                    'remove': <Popconfirm title="您确定彻底删除已撤销的项目吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消"><a href="#">彻底删除</a></Popconfirm>,
                };
                return (
                    <>
                        {renderBtn.read}
                        {[0, 2, 3, 7].includes(record.status) && record.del_flag === 0 ?
                            (<>{renderBtn.divider}{renderBtn.edit}</>) : null}
                        {[0, 2, 3, 7].includes(record.status) && record.del_flag === 0 ?
                            (<>{renderBtn.divider}{renderBtn.rollback}</>) : null}
                        {[0, 2, 3, 7].includes(record.status) && record.del_flag === 1 ?
                            (<>{renderBtn.divider}{renderBtn.restart}{renderBtn.divider}{renderBtn.remove}</>) : null}
                        {[2, 7].includes(record.status) ?
                            (<>{renderBtn.divider}{renderBtn.applyCheck}</>) : null}
                    </>
                );
            },
        },
    ];

    componentDidMount() {
        const { dispatch, location } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'category/fetchSelect',
        });
    }

    handleUpdVisible = (flag, record) => {
        const { dispatch } = this.props;
        dispatch({
            type: 'apply/resetFormData',
        });
        this.setState({
            updVisible: !!flag,
        });
        if (record) {
            dispatch({
                type: 'apply/changeFormData',
                payload: record,
            });
        }
    };

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'apply/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleMenuClick = e => {
        const { dispatch } = this.props;
        const { selectedRows } = this.state;

        if (selectedRows.length === 0) return;
        switch (e.key) {
            case 'remove':
                dispatch({
                    type: 'apply/remove',
                    payload: {
                        key: selectedRows.map(row => row.key),
                    },
                    callback: () => {
                        this.setState({
                            selectedRows: [],
                        });
                    },
                });
                break;
            default:
                break;
        }
    };

    handleSelectRows = rows => {
        this.setState({
            selectedRows: rows,
        });
        const { dispatch } = this.props;
        dispatch({
            type: 'apply/changeSelectedRows',
            payload: rows,
        });
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'apply/changeFormData',
                payload: {
                    ...record,
                },
            });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleRollBack = (record) => {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'apply/changeFormData',
            payload: {
                ...formatObj(record),
                del_flag: 1,
                opt: 'rollback',
            },
        });
        dispatch({
            type: 'apply/add',
        }).then((res) => {
            if (res.code === 1) {
                message.success('撤销成功');
                this.doPageSearch();
            } else {
                message.error('撤销失败');
            }
        });
    }

    handleRestart = (record) => {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'apply/changeFormData',
            payload: {
                ...formatObj(record),
                del_flag: 0,
                opt: 'remain',
            },
        });
        dispatch({
            type: 'apply/add',
        }).then((res) => {
            if (res.code === 1) {
                message.success('恢复成功');
                this.doPageSearch();
            } else {
                message.error('恢复失败');
            }
        });
    }

    handleRemove = (record) => {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'apply/remove',
            payload: {
                Id: record.Id
            },
        }).then((res) => {
            if (res.code === 1) {
                message.success("删除成功");
                this.doPageSearch();
            } else {
                message.error("删除失败");
            }
        });
    }

    handleRecheck = (record) => {
        const { dispatch } = this.props;
        dispatch({
            type: 'apply/changeFormData',
            payload: {
                ...formatObj(record),
                status: 3,
                is_check_pass: null,
                check_time: null,
                check_comment: null,
                checkman_id: null,
                expert_ids: null,
                assign_time: null,
                assignman_id: null,
                esman_id: null,
                establish_time: null,
                opt: 'apply',
            },
        });
        dispatch({
            type: 'apply/add',
        }).then((res) => {
            if (res.code === 1) {
                message.success('操作成功');
                this.doPageSearch();
            } else {
                message.error('操作失败');
            }
        });
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'apply/fetch',
        });
    }

    render() {
        const {
            apply: { data },
            loading,
            currentUser
        } = this.props;
        const { selectedRows, readVisible, updVisible } = this.state;
        const menu = (
            <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
                <Menu.Item key="remove">删除</Menu.Item>
                <Menu.Item key="approval">批量审批</Menu.Item>
            </Menu>
        );

        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };

        return (
            <Card bordered={false}>
                <div className={styles.tableList}>
                    <div className={styles.tableListOperator}>
                        <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                            刷新
                        </Button>
                        {/* {selectedRows.length > 0 && (
                            <span>
                                <Button>批量操作</Button>
                                <Dropdown overlay={menu}>
                                    <Button>
                                        更多操作 <Icon type="down" />
                                    </Button>
                                </Dropdown>
                            </span>
                        )} */}
                    </div>
                    <StandardTable
                        selectedRows={selectedRows}
                        loading={loading}
                        data={data}
                        columns={this.columns}
                        onSelectRow={this.handleSelectRows}
                        onChange={this.handleStandardTableChange}
                        rowKey={record => record.Id}
                    />
                    <UpdForm visible={updVisible} onCancel={() => this.handleUpdVisible(false)} />
                    <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
                </div>
            </Card>
        );
    }
}

export default Apply;
