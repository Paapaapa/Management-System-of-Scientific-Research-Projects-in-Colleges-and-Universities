import StandardTable from '@/components/StandardTable';
import { Button, Card, Divider, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import styles from './Apply.less';
import ReadDescription from './ReadDescription';
import SearchForm from './SearchForm';
import ZCheckForm from './ZCheckForm';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待初审', '等待分配专家评审', '初审未通过', '申请重新初审', '等待专家评审', '等待终审', '立项成功', '立项失败'];

@connect(({ apply, loading, user, category }) => ({
    apply,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    categorySelect: category.categorySelect,
}))
class Apply extends PureComponent {
    state = {
        readVisible: false,
        zCheckVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'name',
            sorter: true,
        },
        {
            title: '负责人',
            dataIndex: 'principal_id',
            sorter: true,
            render: text => {
                const { personSelect } = this.props;
                return personSelect[text];
            },
        },
        {
            title: '类别',
            dataIndex: 'category_id',
            sorter: true,
            render: text => {
                const { categorySelect } = this.props;
                return categorySelect[text];
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const { currentUser } = this.props;
                const { menuVal } = this.state;
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
                    'zCheck': <a onClick={() => this.handleZCheckModalVisible(true, record)}>{record?.zcheck?.length > 0 && record?.zcheck?.some(val => val.expert_id === currentUser.Id) ? '重新评审' : '评审'}</a>,
                };
                return (
                    <>
                        {renderBtn.read}
                        {
                            record.expert_ids
                            && record.expert_ids.split(',').includes(currentUser.Id)
                            && [4,5].includes(record.status) ?
                            (<>{renderBtn.divider}{renderBtn.zCheck}</>) : null
                        }
                    </>
                );
            },
        },
    ];

    componentDidMount() {
        const { dispatch, location } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'category/fetchSelect',
        });
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'apply/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleZCheckModalVisible = (flag, record) => {
        const { dispatch, currentUser } = this.props;
        this.setState({
            zCheckVisible: !!flag,
        });
        if (record) {
            dispatch({
                type: 'apply/changeFormData',
                payload: {
                    ...record,
                },
            });
            // dispatch({
            //   type:'apply/change'
            // })
            // if (record.zcheck.length > 0 && record.zcheck.some(val => val.expert_id === currentUser.Id)) {
            dispatch({
                type: 'apply/changeZCheckFormData',
                payload: record.zcheck.filter(val => val.expert_id === currentUser.Id)[0] || {},
            });
            // }
        }
    };

    handleReadVisible = (flag, record) => {
        const { dispatch } = this.props;
        this.setState({
            readVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'apply/changeFormData',
                payload: {
                    ...record,
                },
            });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'apply/fetch',
        });
    }

    render() {
        const {
            apply: { data },
            loading,
            currentUser
        } = this.props;
        const { zCheckVisible, readVisible } = this.state;
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };

        return (
            <Card bordered={false}>
                <div className={styles.tableList}>
                    <div className={styles.tableListOperator}>
                        <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                            刷新
                        </Button>
                    </div>
                    <StandardTable
                        selectedRows={[]}
                        loading={loading}
                        data={data}
                        columns={this.columns}
                        onChange={this.handleStandardTableChange}
                        rowKey={record=>record.Id}
                    />
                </div>
                <ZCheckForm visible={zCheckVisible} onCancel={() => this.handleZCheckModalVisible(false)} />
                <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
            </Card>
        );
    }
}

export default Apply;
