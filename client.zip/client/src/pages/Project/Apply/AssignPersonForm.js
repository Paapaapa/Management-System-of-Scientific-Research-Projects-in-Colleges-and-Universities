import { Modal, Select, Form, message } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { formatObj } from '@/utils/utils';

const { Option } = Select;
const FormItem = Form.Item;

@connect(({ apply, loading, user }) => ({
  apply,
  loading: loading.models.rule,
  zSelect: user.zSelect,
  currentUser: user.currentUser
}))
@Form.create()
class AssignPerson extends PureComponent {
  state = {
    selectedItems: [],
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'user/fetchSelect',
      payload: {
        role: 'Z',
      }
    });
  }

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      apply: {
        formData
      },
      currentUser
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'apply/changeFormData',
        payload: {
          ...formatObj(formData),
          ...fieldsValue,
          status: 4,
          assignman_id: currentUser.Id,
          expert_ids: fieldsValue.expert_ids.toString(),
          assign_time: moment().format('YYYY-MM-DD HH:mm:ss'),
          oexpert_ids:formData.expert_ids || null,
          opt: formData.expert_ids && formData.expert_ids !== fieldsValue.expert_ids.toString() ? 'reassign' : 'assign',
        },
      });
      dispatch({
        type: 'apply/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("指定成功");
          dispatch({
            type: 'apply/fetch',
          });
        } else {
          message.error("指定失败");
        }
      });
    });
  };

  render() {
    const { visible, onCancel, zSelect, form, apply: {
      formData
    } } = this.props;

    return (
      <Modal
        destroyOnClose
        title="指定专家"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 16 }} label="项目审核人">
          {form.getFieldDecorator('expert_ids', {
            rules: [{ required: true, message: '必选' }],
            initialValue: formData.expert_ids ? formData.expert_ids.split(',') : [],
          })(<Select
            mode="multiple"
            style={{ width: 200 }}
            placeholder="请选择"
          >
            {
              Object.keys(zSelect).map((val) => formData.principal_id !== val ? <Option key={val}>{zSelect[val]}</Option> : null)
            }
          </Select>)}
        </FormItem>
      </Modal>
    );
  };
};

export default AssignPerson;