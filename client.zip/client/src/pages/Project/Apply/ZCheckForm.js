import { Modal, Select, Form, message, Input } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { formatObj } from '@/utils/utils';

const { Option } = Select;
const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ apply, user }) => ({
  apply,
  personSelect: user.personSelect,
  currentUser: user.currentUser,
}))
@Form.create()
class ZCheck extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      apply: { formData, zcheckFormData },
      currentUser
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'apply/changeZCheckFormData',
        payload: {
          ...zcheckFormData,
          ...fieldsValue,
          project_id: formData.Id,
          expert_id: currentUser.Id,
        },
      });
      dispatch({
        type: 'apply/addZCheck',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("审核成功");
          dispatch({
            type: 'apply/fetch',
          });
        } else {
          message.error("审核失败");
        }
      })
    });
  };

  render() {
    const { visible, onCancel, form, apply: { zcheckFormData: formData } } = this.props;

    return (
      <Modal
        destroyOnClose
        title="专家评审"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="是否合格">
          {form.getFieldDecorator('is_passed', {
            rules: [{ required: true, message: '必选' }],
            initialValue: formData.is_passed == 0 || formData.is_passed ? String(formData.is_passed) : '',
          })(<Select
            style={{ width: 200 }}
            placeholder="请选择"
          >
            <Option key="0">不同意</Option>
            <Option key="1">同意</Option>
          </Select>)}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="评审意见">
          {form.getFieldDecorator('comment', {
            rules: [{ required: true, message: '必填' }],
            initialValue: formData ?.comment
        })(<TextArea
              style={{ minHeight: 32 }}
              placeholder='请输入评审意见'
              rows={4}
            />)}
        </FormItem>
      </Modal>
    );
  };
};

export default ZCheck;