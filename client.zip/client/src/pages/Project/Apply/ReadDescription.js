import { Drawer, Upload, Divider, Timeline, Tooltip,Row,Col } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import DescriptionList from '@/components/DescriptionList';
import Ellipsis from '@/components/Ellipsis';

const { Description } = DescriptionList;

@connect(({ apply, user, category }) => ({
  record: apply.formData,
  personSelect: user.personSelect,
  categorySelect: category.categorySelect,
}))
class ReadDescription extends PureComponent {

  render() {
    const { record, visible, onClose, personSelect, categorySelect } = this.props;
    // 时间轴显示进度
    const RenderTimeline = (records) => (
      <Timeline pending={[7,6].includes(records.status) ? false : "进行中···"} mode="alternate" style={{ paddingTop: '10px' }}>
        {records.apply_time ? (
          <Timeline.Item key="1">
            <div>{`${personSelect[records.principal_id]}申报了项目-${records.name}`}</div>
            <div>{moment(records.apply_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
        {records.check_time ? (
          <Timeline.Item key="2">
            <div>{`管理员${personSelect[records.checkman_id]}给项目-${records.name}进行了初审`}</div>
            <div>{moment(records.check_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
        {records.assign_time ? (
          <Timeline.Item key="3">
            <div>{`管理员${personSelect[records.assignman_id]}给项目-${records.name}分配了专家进行评审`}</div>
            <div>{moment(records.assign_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
        {records?.zcheck?.length > 0 ? records.zcheck.map((val,index) =>
          <Timeline.Item key={`4-${index}`}>
            <div>{`专家${personSelect[val.expert_id]}给项目-${records.name}进行了评审`}</div>
            <div>{moment(val.upd_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>
        ) : null}
        {records.establish_time ? (
          <Timeline.Item key="5">
            <div>{`管理员${personSelect[records.esman_id]}为项目-${records.name}进行了立项`}</div>
            <div>{moment(records.establish_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
      </Timeline>
    );
    // 附件下载
    const downloadFile = () => {
      const props = {
        fileList: record ?.file_path ?.split(',') ?.map((val, index) => ({
          'uid': index,
          'name': val.split('_')[1],
          'status': 'done',
          'url': `${window.location.origin}/server/api/file/download/project&${val}`,
        })),
        showUploadList: {
          showPreviewIcon: true,
          showRemoveIcon: false,
        },
      };
      return record.file_path ? (<Upload {...props} />) : <>暂无附件</>;
    };
    return (
      <Drawer
        destroyOnClose
        title={`${record ?.name}-详情`}
        placement="right"
        closable={false}
        onClose={onClose}
        visible={visible}
        width={800}
      >
        <DescriptionList size="large" title="流程进度" style={{ marginBottom: 32 }}>
          {RenderTimeline(record)}
        </DescriptionList>
        <Divider style={{ marginBottom: 32 }} />
        <DescriptionList size="large" title="First-项目申报" style={{ marginBottom: 32 }}>
          <Description term="项目名称">
            <Ellipsis tooltip lines={1}>{record?.name}</Ellipsis>
          </Description>
          <Description term="项目类别">{categorySelect[record ?.category_id]}</Description>
          <Description term="项目负责人">{personSelect[record ?.principal_id]}</Description>
          <Description term="研究周期">{record ?.period}天</Description>
          <Description term="经费预算">{record?.money}元</Description>
          <Description term="申报截止日期">{moment(record ?.end_time).format('YYYY-MM-DD')}</Description>
          <Description term="项目简介">
          <Ellipsis tooltip lines={1}>{record?.description}</Ellipsis>
          </Description>
          <Description term="预期成果">
          <Ellipsis tooltip lines={1}>{record?.fruit}</Ellipsis>
          </Description>
          <Description term="申报时间">{moment(record ?.apply_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
          <Description term="参与成员">
          {record?.member_ids?.split(',')?.map(val=>personSelect?.[val])?.join(',')||'尚未选择'}
          </Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.check_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Second-管理员初审" style={{ marginBottom: 32, display: record ?.check_time ? 'block' : 'none' }}>
          <Description term="处理人员">{personSelect[record?.checkman_id]}</Description>
          <Description term="是否合格">{record ?.is_check_pass == 1 ? '是' : '否'}</Description>
          <Description term="审核建议">
          <Ellipsis tooltip lines={1}>{record?.check_comment}</Ellipsis>
          </Description>
          <Description term="评审时间">{moment(record ?.check_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.assign_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Third-专家分配" style={{ marginBottom: 32, display: record ?.assign_time ? 'block' : 'none' }}>
          <Description term="评审专家">{record ?.expert_ids ?.split(',') ?.map(val => personSelect[val]) ?.toString()}</Description>
          <Description term="处理人员">{personSelect[record ?.assignman_id]}</Description>
          <Description term="处理时间">{moment(record ?.assign_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.status > 3 ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Forth-专家评审" style={{ marginBottom: 32, display: record ?.status > 3 ? 'block' : 'none' }}>
          <Row gutter={25} style={{marginLeft:10}}>
          {
            record ?.zcheck ?.length == 0 ? '暂无专家评审' : record ?.zcheck ?.map((val,index) => (
              <Col span={12} key={index}>
                <Description term="专家">{personSelect[val ?.expert_id]}</Description>
                <Description term="是否通过">{val ?.is_passed == 1 ? '是' : '否'}</Description>
                <Description term="评审时间">{moment(val ?.upd_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
                <Description term="评审意见">
                  <Tooltip title={val ?.comment} >
                    <div style={{ width: '20%', display: 'block', textOverflow: 'ellipsis', whiteSpace: 'nowrap', overflow: 'hidden' }}>{val ?.comment}</div>
                  </Tooltip>
                </Description>
              </Col>
            ))
        }
        </Row>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.establish_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Last-项目立项" style={{ marginBottom: 32, display: record ?.establish_time ? 'block' : 'none' }}>
          <Description term="处理人员">{personSelect[record ?.esman_id]}</Description>
          <Description term="立项时间">{moment(record ?.establish_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32 }} />
        <DescriptionList size="large" title="附件下载" style={{ marginBottom: 32 }}>
          <div style={{ marginLeft: '18px' }}>{downloadFile()}</div>
        </DescriptionList>
      </Drawer>
    );
  }
}

export default ReadDescription;