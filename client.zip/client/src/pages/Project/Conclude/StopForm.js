import { Form, Input, message, Modal } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';

const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ stop,user }) => ({
  stop,
  user
}))
@Form.create()
class StopForm extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      stop: { formData },
      user:{currentUser}
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'stop/changeFormData',
        payload: {
          ...fieldsValue,
          project_id: formData.project_id,
          principal_id:currentUser.Id,
          opt:'apply',
        },
      });
      dispatch({
        type: 'stop/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("申请成功");
          dispatch({
            type: 'conclude/fetch',
          });
        } else {
          message.error("申请失败");
        }
      })
    });
  };

  render() {
    const { visible, onCancel, form, stop: { formData } } = this.props;

    return (
      <Modal
        destroyOnClose
        title="申请中止"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="中止理由">
          {form.getFieldDecorator('reason', {
            rules: [{ required: true, message: '必填' }],
            initialValue: formData ?.reason,
          })(<TextArea
            style={{ minHeight: 32 }}
            placeholder='请输入中止理由'
            rows={4}
          />)}
        </FormItem>
      </Modal>
    );
  };
};

export default StopForm;