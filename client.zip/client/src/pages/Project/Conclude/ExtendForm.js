import { Modal, Form, message, Input, InputNumber } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { formatObj } from '@/utils/utils';

const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ conclude }) => ({
  conclude,
}))
@Form.create()
class ExtendForm extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      conclude: { formData },
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'conclude/changeFormData',
        payload: {
          ...formatObj(formData),
          ...fieldsValue,
          eapply_time: moment().format('YYYY-MM-DD HH:mm:ss'),
          is_echeck_pass:null,
          echeck_time:null,
          opt:'aextend',
        },
      });
      dispatch({
        type: 'conclude/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("提交成功");
          dispatch({
            type: 'conclude/fetch',
          });
        } else {
          message.error("提交失败");
        }
      })
    });
  };

  render() {
    const { visible, onCancel, form, conclude: { formData } } = this.props;

    return (
      <Modal
        destroyOnClose
        title="延长申请"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="延长天数">
          {form.getFieldDecorator('extend_days', {
            rules: [{ required: true, message: '必填' }],
            initialValue: formData ?.extend_days,
          })
            (<InputNumber min={1} />)}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="延长理由">
          {form.getFieldDecorator('extend_reason', {
            rules: [{ required: true, message: '必填' }],
            initialValue: formData ?.extend_reason,
          })(<TextArea
            style={{ minHeight: 32 }}
            placeholder='请输入延长理由'
            rows={4}
          />)}
        </FormItem>
      </Modal>
    );
  };
};

export default ExtendForm;