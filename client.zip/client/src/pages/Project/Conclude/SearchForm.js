import { Form, Row, Col, AutoComplete, Button, Icon, DatePicker, Select } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import styles from './Conclude.less';

const FormItem = Form.Item;
const { Option } = Select;
const { RangePicker } = DatePicker;
const PROGRESS = ['等待管理员设置截止时间', '等待负责人提交结题材料', '等待专家评审', '评审通过，等待确认', '评审不通过', '申请重新评审，等待评审', '已确认'];

@connect(({ user, apply }) => ({
  personSelect: user.personSelect,
  currentUser: user.currentUser,
  projectSelect: apply.projectSelect,
}))
@Form.create()
class SearchForm extends PureComponent {
  state = {
    principalData: [],
    expandForm: false,
  };

  handleFormReset = () => {
    const { form, dispatch} = this.props;
    form.resetFields();
    dispatch({
      type: 'conclude/resetSearchData',
    });
    dispatch({
      type: 'conclude/fetch',
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleSearch = (e) => {
    e.preventDefault();
    const { dispatch, form, personSelect, projectSelect, currentUser } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      Object.keys(personSelect).forEach((val) => {
        personSelect[val] === values.principal_id && (values.principal_id = val);
        personSelect[val] === values.checkman_id && (values.checkman_id = val);
        personSelect[val] === values.setman_id && (values.setman_id = val);
        personSelect[val] === values.prman_id && (values.prman_id = val);
      });
      Object.keys(projectSelect).forEach((val) => {
        projectSelect[val] === values.project_id && (values.project_id = val);
      });
      dispatch({
        type: 'conclude/resetSearchData',
        payload: {
          ...values,
          end_time: values.end_time ? [values.end_time[0].format('YYYY-MM-DD'), values.end_time[1].format('YYYY-MM-DD')].toString() : '',
          check_time: values.check_time ? [values.check_time[0].format('YYYY-MM-DD'), values.check_time[1].format('YYYY-MM-DD')].toString() : '',
          conclude_time: values.conclude_time ? [values.conclude_time[0].format('YYYY-MM-DD'), values.conclude_time[1].format('YYYY-MM-DD')].toString() : '',
        },
      });
      dispatch({
        type: 'conclude/fetch',
      });
    });
  };

  handleAutoSearch = (value, data) => {
    if (value !== '') {
      const dataSource = [];
      Object.keys(data).forEach((val) => {
        if (data[val].indexOf(value) > -1) dataSource.push(data[val]);
      });
      this.setState({
        principalData: dataSource,
      });
    }
  };

  renderSimpleForm() {
    const {
      form: { getFieldDecorator }, personSelect, projectSelect
    } = this.props;
    const { principalData } = this.state;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="项目名称">
              {getFieldDecorator('project_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, projectSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="负责人">
              {getFieldDecorator('principal_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons} style={{ float: 'right' }}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
              <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
                展开 <Icon type="down" />
              </a>
            </span>
          </Col>
        </Row>
      </Form>
    );
  };

  renderAdvancedForm() {
    const {
      form: { getFieldDecorator }, projectSelect, personSelect
    } = this.props;
    const { principalData } = this.state;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="项目名称">
              {getFieldDecorator('project_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, projectSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="负责人">
              {getFieldDecorator('principal_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="审核人">
              {getFieldDecorator('checkman_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="结束人">
              {getFieldDecorator('prman_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="设置日期人">
              {getFieldDecorator('setman_id')(
                <AutoComplete
                  dataSource={principalData}
                  style={{ width: 200 }}
                  onSearch={val => this.handleAutoSearch(val, personSelect)}
                  placeholder="请输入"
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="截止时间">
              {getFieldDecorator('end_time')(
                <RangePicker />
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="评审时间">
              {getFieldDecorator('check_time')(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="结束时间">
              {getFieldDecorator('conclude_time')(
                <RangePicker />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="是否通过">
              {getFieldDecorator('is_check_pass')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option key="0">否</Option>
                  <Option key="1">是</Option>
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="进度" labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              {getFieldDecorator('status')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  {PROGRESS.map((val, index) => (<Option key={index}>{val}</Option>))}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={16} sm={24}>
            <div style={{ overflow: 'hidden', float: 'right' }}>
              <div style={{ marginBottom: 24 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                  重置
                </Button>
                <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
                  收起 <Icon type="up" />
                </a>
              </div>
            </div>
          </Col>
        </Row>
      </Form>
    );
  }

  render() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }
};

export default SearchForm;