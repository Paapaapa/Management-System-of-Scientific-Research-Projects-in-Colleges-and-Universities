import { Form, Input, message, Modal } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';

const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ category }) => ({
  formData: category.formData,
}))
@Form.create()
class AddForm extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'category/changeFormData',
        payload: fieldsValue,
      });
      dispatch({
        type: 'category/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("操作成功");
          dispatch({
            type: 'category/fetch',
          });
          dispatch({
            type: 'category/fetchSelect',
          });
        } else {
          message.error("操作失败");
        }
      });
    });
  };

  render() {
    const { visible, onCancel, form, formData } = this.props;

    return (
      <Modal
        destroyOnClose
        title="项目类别"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} label="名称">
          {form.getFieldDecorator('name', {
            rules: [{ required: true,message:'必填' }],
            initialValue: formData ?.name,
          })(<Input placeholder="请输入名称" />)}
        </FormItem>
        <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} label="描述">
          {form.getFieldDecorator('description', {
            rules: [{ required: true, message: '请输入至少10个字符！', min: 10 }],
            initialValue: formData ?.description,
          })(<TextArea
            style={{ minHeight: 32 }}
            placeholder='请输入描述'
            rows={4}
          />)}
        </FormItem>
      </Modal>
    );
  };
};

export default AddForm;