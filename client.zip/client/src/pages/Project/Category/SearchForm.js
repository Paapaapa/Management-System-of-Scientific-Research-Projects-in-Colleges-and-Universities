import { Form,Row,Col,AutoComplete,Button } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';

const FormItem = Form.Item;


@connect(({ category }) => ({
    categorySelect:category.categorySelect,
  }))
@Form.create()
class SearchForm extends PureComponent {
  state={
    categorySource:[],
  };

  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    dispatch({
      type:'category/resetSearchData',
    });
    dispatch({
      type:'category/fetch',
    });
  };

  handleSearch = (e) => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      dispatch({
        type: 'category/changeSearchFormFields',
        payload:values,
      });
      dispatch({
        type: 'category/fetch',
      });
    });
  };
  
    render() {
        const {
            form: { getFieldDecorator },categorySelect
          } = this.props;
          const { categorySource }=this.state;
          const handleSearch=(value) => {
            if(value!== ''){
              const dataSource=[];
              Object.keys(categorySelect).forEach((val) => {
                if(categorySelect[val].indexOf(value)>-1) dataSource.push(categorySelect[val]);
              });
              this.setState({
                categorySource :dataSource,
              });
            }
          };
      
          return (
            <Form onSubmit={this.handleSearch} layout="inline">
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={8} sm={24}>
                  <FormItem label="类别名称">
                    {getFieldDecorator('name')(
                      <AutoComplete
                       dataSource={categorySource}
                       style={{ width: 200 }}
                       onSearch={handleSearch}
                       placeholder="请输入"
                      />
                    )}
                  </FormItem>
                </Col>
                <Col md={16} sm={24}>
                 <div style={{ overflow: 'hidden'}}>
                  <div style={{ marginBottom: 24,marginTop:4 }}>
                   <Button type="primary" htmlType="submit">
                     查询
                   </Button>
                   <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                     重置
                   </Button>
                  </div>
                 </div>
                </Col>
              </Row>
            </Form>
      );
    };
};

export default SearchForm;