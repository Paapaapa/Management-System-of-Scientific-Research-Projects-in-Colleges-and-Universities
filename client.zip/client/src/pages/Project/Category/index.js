import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import StandardTable from '@/components/StandardTable';
import {  Button, Card, Divider, Dropdown, Form, Icon, Menu, message, Popconfirm,Modal } from 'antd';
import { connect } from 'dva';
import React, { Fragment, PureComponent } from 'react';
import styles from './Category.less';
import AddForm from './AddForm';
import SearchForm from './SearchForm';


@connect(({ category, loading  }) => ({
  category,
  loading: loading.models.rule,
}))
@Form.create()
class Apply extends PureComponent {
  state = {
    modalVisible: false,
    selectedRows:[],
  };

  columns = [
    {
      title: '类别名称',
      dataIndex: 'name',
      sorter:true,
    },
    {
      title: '操作',
      render: (text, record) => (<Fragment>
        <a onClick={() => this.handleDetail(record)}>查看详情</a>
        <Divider type="vertical" />
        <a onClick={() => this.handleModalVisible(true, record)}>编辑</a>
        <Divider type="vertical" />
        <Popconfirm title="您确定删除吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消"><a href="#">删除</a>
        </Popconfirm>
        </Fragment>),
    },
  ];

  componentDidMount() {
    const { dispatch } = this.props;
    this.doPageSearch();
    dispatch({
      type: 'category/fetchSelect',
    });
  }

  componentWillUnmount(){
    const {dispatch}=this.props;
    dispatch({
      type: 'category/resetSearchData',
    });
    dispatch({
      type: 'category/resetList',
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const params = {
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type:'category/changeSearchFormFields',
      payload:params,
    })
    this.doPageSearch();
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (selectedRows.length === 0) return;
    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'category/remove',
          payload: {
            key: selectedRows.map(row => row.key),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
    const {dispatch}=this.props;
    dispatch({
      type:'category/changeSelectedRows',
      payload:rows,
    });
  };

  handleModalVisible = (flag,record) => {
    const {dispatch}=this.props;
    this.setState({
      modalVisible: !!flag,
    });
    dispatch({
      type:'category/resetFormData',
    });
    if(record){
      dispatch({
        type:'category/changeFormData',
        payload:record,
      });
    }
  };

  handleDetail=(record)=>{
    Modal.info({
      title: '类别详情',
      content: (
        <div style={{marginTop:'16px'}}>
          <div>
            <span style={{marginRight:'10px',fontWeight:'bold',fontSize:'12px'}}>名称：</span>
            {record?.name}
          </div>
          <hr style={{background: '#c5c5c580',height: '1px',border: 'none'}} />
          <div>
            <span style={{marginRight:'10px',fontWeight:'bold',fontSize:'12px'}}>说明：</span><br />
            {record.description?record.description:'暂无说明'}
          </div>
        </div>
      ),
      okText:'关闭'
    });
  }

  handleRefresh = () => {
    this.doPageSearch();
  }

  handleRemove = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'category/remove',
      payload: record,
    }).then((res) => {
      if (res.code === 1) {
        message.success('删除成功');
        this.doPageSearch();
      } else {
        message.error('删除失败');
      }
    });
  }

  doPageSearch() {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'category/fetch',
    });
  }

  render() {
    const {
      category: { data },
      loading,
    } = this.props;
    const { modalVisible,selectedRows } = this.state;
    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );

    data.pagination={
      ...data.pagination,
      showTotal: total => `总计 ${total} 条数据`,
      pageSizeOptions:['10', '20', '30'],
    };
    
    return (
      <PageHeaderWrapper title="项目类别">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <SearchForm />
            <div className={styles.tableListOperator}>
              <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                刷新
              </Button>
              <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
                新建
              </Button>
              {/* {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )} */}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={this.columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
              rowKey={record=>record.Id}
            />
          </div>
        </Card>
        <AddForm visible={modalVisible} onCancel={() => this.handleModalVisible(false)} />
      </PageHeaderWrapper>
    );
  }
}

export default Apply;
