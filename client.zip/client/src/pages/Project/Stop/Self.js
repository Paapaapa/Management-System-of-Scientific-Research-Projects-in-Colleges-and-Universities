import StandardTable from '@/components/StandardTable';
import { Button, Divider, message, Modal, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import styles from './default.less';
import StopForm from './StopForm';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待审批', '审批通过', '审批不通过'];

@connect(({ stop, loading, user,apply}) => ({
    stop,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    projectSelect: apply.projectSelect
}))
class Self extends PureComponent {
    state = {
        modalVisible: false,
        readVisible: false,
        extendVisible: false,
        stopVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'project_id',
            sorter: true,
            render: (text) => {
                const { projectSelect } = this.props;
                return (<Link to={`/project/apply?menuVal=1&Id=${text}`}>{projectSelect[text]}</Link>)
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const { currentUser } = this.props;
                const { menuVal } = this.state;
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'stop': <a onClick={() => this.handleStopVisible(true, record)}>修改中止申请</a>,
                    'rollback': <Popconfirm title="您确定撤销吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消"><a href="#">撤销</a></Popconfirm>,
                    'read': <a onClick={() => this.handleDetail(record)}>查看详情</a>,
                };
                return (<>
                    {renderBtn.read}
                    {record.status === 0 ? (<>{renderBtn.divider}{renderBtn.stop}</>) : null}
                    {record.status === 0 ? (<>{renderBtn.divider}{renderBtn.rollback}</>) : null}
                </>
                );
            },
        },
    ];

    componentDidMount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'apply/fetchSelect',
        });
    }

    handleRouter = (val) => {
        const { currentUser } = this.props;
        router.push({
            pathname: '/project/stop',
            query: {
                Id: val,
                menuVal: currentUser.role === 'G' ? 'all' : 'self',
            },
        });
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'stop/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleStopVisible = (flag, record) => {
        const { dispatch } = this.props;
        dispatch({
            type: 'stop/resetFormData',
        });
        this.setState({
            stopVisible: !!flag,
        });
        if (record) {
            dispatch({
                type: 'stop/changeFormData',
                payload: record,
            });
        }
    }

    handleRemove = (record) => {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'stop/remove',
            payload: record,
        }).then((res) => {
            if (res.code === 1) {
                message.success("撤销成功");
                this.doPageSearch();
            } else {
                message.error("撤销失败");
            }
        });
    }

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleDetail = (record) => {
        const { projectSelect,personSelect } = this.props;
        Modal.info({
            title: '处理详情',
            content: (
                <div style={{ marginTop: '16px' }}>
                    <div>
                        <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>项目名称：</span>
                        {projectSelect ?.[record ?.project_id]}
                    </div>
                    <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
                    <div>
                        <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>中止理由：</span><br />
                        {record ?.reason}
                    </div>
                    {
                        record.is_passed !== null ? <>
                            <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
                            <div>
                                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>状态：</span>
                                {record ?.is_passed == 0 ? '驳回' : '已同意'}
                            </div>
                            <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
                            <div>
                                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>处理人员：</span>
                                {personSelect[record ?.checkman_id]}
                            </div>
                            <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
                            <div>
                                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>审批意见：</span><br />
                                {record.check_comment ? record.check_comment : '无'}
                            </div>
                            <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
                            <div>
                                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>处理时间：</span>
                                {moment(record ?.check_time).format('YYYY-MM-DD hh:mm:ss')}
                            </div>
                        </> : null
                    }
                </div>
            ),
            okText: '关闭'
        });
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'stop/fetch',
        });
    }

    render() {
        const {
            stop: { data },
            loading
        } = this.props;
        const { stopVisible } = this.state;

        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };

        return (
            <div className={styles.tableList}>
                <div className={styles.tableListOperator}>
                    <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                        刷新
                    </Button>
                </div>
                <StandardTable
                    selectedRows={[]}
                    loading={loading}
                    data={data}
                    columns={this.columns}
                    onChange={this.handleStandardTableChange}
                    rowKey={record => record.Id}
                />
                <StopForm visible={stopVisible} onCancel={() => this.handleStopVisible(false)} />
            </div>
        );
    }
}

export default Self;
