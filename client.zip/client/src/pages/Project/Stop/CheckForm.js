import { Modal, Select, Form, message, Input } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { formatObj } from '@/utils/utils';

const { Option } = Select;
const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ stop, user }) => ({
  stop,
  personSelect: user.personSelect,
  currentUser: user.currentUser,
}))
@Form.create()
class Check extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      stop: { formData },
      currentUser
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      dispatch({
        type: 'stop/changeFormData',
        payload: {
          ...formatObj(formData),
          ...fieldsValue,
          check_time: moment().format('YYYY-MM-DD HH:mm:ss'),
          checkman_id: currentUser.Id,
          status: fieldsValue.is_passed === '0' ? 2 : 1,
          opt:'check',
        },
      });
      dispatch({
        type: 'stop/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("审批成功");
          dispatch({
            type: 'stop/fetch',
          });
        } else {
          message.error("审批失败");
        }
      })
    });
  };

  render() {
    const { visible, onCancel, form, stop: { formData } } = this.props;

    return (
      <Modal
        destroyOnClose
        title="审批中止"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="是否通过">
          {form.getFieldDecorator('is_passed', {
            rules: [{ required: true, message: '必选' }],
            initialValue: formData.is_passed==0||formData.is_passed?String(formData?.is_passed):'',
          })
            (<Select
              style={{ width: 200 }}
              placeholder="请选择"
            >
              <Option key="0">不同意</Option>
              <Option key="1">同意</Option>
            </Select>
            )}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="审批意见">
          {form.getFieldDecorator('check_comment', {
            rules: [{ required: true, message: '必填' }],
            initialValue: formData ?.check_comment,
          })(<TextArea
            style={{ minHeight: 32 }}
            placeholder='请输入审批意见'
            rows={4}
          />)}
        </FormItem>
      </Modal>
    );
  };
};

export default Check;