import { Card, Tabs } from 'antd';
import { connect } from 'dva';
import React, { Component } from 'react';
import PageHeaderWrapper from '../../../components/PageHeaderWrapper';
import Check from './Check';
import Self from './Self';

const { TabPane } = Tabs;

@connect(({ user }) => ({
    user,
}))
class Index extends Component {
    state = {
        activeKey: '1',
    }

    componentDidMount() {
        const { dispatch, location } = this.props;
        const { activeKey } = this.state;
        if (location.query.Id) {
            dispatch({
                type: 'stop/changeSearchFormFields',
                payload: {
                    Id: location.query.Id,
                },
            });
            this.onChange(location.query.key);
        }
        this.onChange(activeKey);
    }

    componentWillUnmount() {
        const { dispatch } = this.props;
        dispatch({
            type: 'stop/resetSearchData',
        });
        dispatch({
            type: 'stop/resetList',
        });
        dispatch({
            type: 'stop/saveTypeParams',
        });
    }

    onChange = (key) => {
        const {
            dispatch,
            user: { currentUser }
        } = this.props;
        const params = {};
        this.setState({
            activeKey: key,
        });
        switch (key) {
            case '1':
                params.principal_id = currentUser.Id;
                break;
            case '2':
                params.check_time = 'null';
                params.del_flag = 0;
                break;
            default: break;
        }
        dispatch({
            type: 'stop/changeIsIndex',
            payload: true,
        });
        dispatch({
            type: 'stop/resetSearchData',
        });
        dispatch({
            type: 'stop/saveTypeParams',
            payload: params,
        });
        dispatch({
            type: 'stop/fetch',
        });
    }

    render() {
        const { user: { currentUser } } = this.props;
        const { activeKey } = this.state;

        return (
            <PageHeaderWrapper title="项目中止">
                <Card bordered={false}>
                    <Tabs defaultActiveKey="1" type="card" onChange={this.onChange} activeKey={activeKey}>
                        <TabPane tab="个人申请" key="1">
                            <Self />
                        </TabPane>
                        {currentUser.role === 'G' ? <TabPane tab="审批项目" key="2">
                            <Check />
                        </TabPane> : null}
                    </Tabs>
                </Card>
            </PageHeaderWrapper>
        );
    }
}

export default Index;