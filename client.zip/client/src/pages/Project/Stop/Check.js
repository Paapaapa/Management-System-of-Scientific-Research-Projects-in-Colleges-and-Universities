import StandardTable from '@/components/StandardTable';
import { Button, Divider, Popconfirm, Radio,Modal } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import CheckForm from './CheckForm';
import styles from './default.less';
import moment from 'moment';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待审批', '审批通过', '审批不通过'];

@connect(({ stop, loading, user, apply }) => ({
    stop,
    loading: loading.models.rule,
    personSelect: user.personSelect,
    currentUser: user.currentUser,
    projectSelect: apply.projectSelect
}))
class stop extends PureComponent {
    state = {
        menuVal: 'noCheck',
        checkVisible: false,
        readVisible: false,
    };

    columns = [
        {
            title: '项目名称',
            dataIndex: 'project_id',
            sorter: true,
            render: (text) => {
                const { projectSelect } = this.props;
                return (<Link to={`/project/apply?menuVal=1&Id=${text}`}>{projectSelect[text]}</Link>)
            },
        },
        {
            title: '负责人',
            dataIndex: 'principal_id',
            sorter: true,
            render: text => {
                const { personSelect } = this.props;
                return personSelect[text];
            },
        },
        {
            title: '进度',
            dataIndex: 'status',
            sorter: true,
            render: val => PROGRESS[val],
        },
        {
            title: '操作',
            render: (text, record) => {
                const { currentUser } = this.props;
                const renderBtn = {
                    'divider': <Divider type="vertical" />,
                    'check': <a onClick={() => this.handleCheckModalVisible(true, record)}>{record.check_time ? '重新审批' : '审批'}</a>,
                    'read': <a onClick={() => this.handleDetail(record)}>查看详情</a>,
                };
                return (
                    <>
                        {renderBtn.read}
                        {currentUser.Id !== record.principal_id ? (<>{renderBtn.divider}{renderBtn.check}</>) : null}
                    </>
                );
            },
        },
    ];

    componentDidMount() {
        const { dispatch, currentUser, location } = this.props;
        dispatch({
            type: 'user/fetchSelect',
        });
        dispatch({
            type: 'apply/fetchSelect',
        });
    }

    componentWillReceiveProps(nextProps) {
        const { stop: { isIndex } } = nextProps;
        if (isIndex) {
            this.setState({
                menuVal: 'noCheck',
            })
        }
    }

    handleDetail = (record) => {
        const { projectSelect,personSelect } = this.props;
        Modal.info({
            title: '处理详情',
            content: (
                <div style={{ marginTop: '16px' }}>
                    <div>
                        <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>项目名称：</span>
                        {projectSelect ?.[record ?.project_id]}
                    </div>
                    <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
                    <div>
                        <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>中止理由：</span><br />
                        {record ?.reason}
                    </div>
                    {
                        record.is_passed !== null ? <>
                            <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
                            <div>
                                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>状态：</span>
                                {record ?.is_passed == 0 ? '驳回' : '已同意'}
                            </div>
                            <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
                            <div>
                                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>处理人员：</span>
                                {personSelect[record ?.checkman_id] == 0 ? '驳回' : '已同意'}
                            </div>
                            <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
                            <div>
                                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>审批意见：</span><br />
                                {record.check_comment ? record.check_comment : '无'}
                            </div>
                            <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
                            <div>
                                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>处理时间：</span>
                                {moment(record ?.check_time).format('YYYY-MM-DD hh:mm:ss')}
                            </div>
                        </> : null
                    }
                </div>
            ),
            okText: '关闭'
        });
    }

    handleStandardTableChange = (pagination, filtersArg, sorter) => {
        const { dispatch } = this.props;
        const params = {
            pageNum: pagination.current,
            pageSize: pagination.pageSize,
        };
        if (sorter.field) {
            params.sorter = `${sorter.field}_${sorter.order}`;
        }
        dispatch({
            type: 'stop/changeSearchFormFields',
            payload: params,
        })
        this.doPageSearch();
    };

    handleCheckModalVisible = (flag, record) => {
        const { dispatch } = this.props;
        dispatch({
            type: 'stop/resetFormData',
        });
        this.setState({
            checkVisible: !!flag,
        });
        if (record)
            dispatch({
                type: 'stop/changeFormData',
                payload: {
                    ...record,
                },
            });
    };

    handleRefresh = () => {
        this.doPageSearch();
    }

    handleRadioGroup = (e) => {
        const {
            dispatch,
            currentUser
        } = this.props;
        const params = {};
        this.setState({
            menuVal: e.target.value,
        });
        switch (e.target.value) {
            case 'checked':
                params.is_passed = 'notNull';
                params.checkman_id = currentUser.Id;
                params.del_flag = 0;
                break;
            default:
                params.is_passed = 'null';
                params.checkman_id = 'null';
                params.del_flag = 0;
                break;
        }
        dispatch({
            type: 'stop/changeIsIndex',
            payload: false,
        });
        dispatch({
            type: 'stop/saveTypeParams',
            payload: params,
        });
        this.doPageSearch();
    }

    doPageSearch() {
        const {
            dispatch
        } = this.props;
        dispatch({
            type: 'stop/fetch',
        });
    }

    render() {
        const {
            stop: { data },
            loading,
            currentUser
        } = this.props;
        const { menuVal, checkVisible, readVisible } = this.state;
        data.pagination = {
            ...data.pagination,
            showTotal: total => `总计 ${total} 条数据`,
            pageSizeOptions: ['10', '20', '30'],
        };
        return (
            <div className={styles.tableList}>
                <div className={styles.tableListOperator}>
                    <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                        刷新
                    </Button>
                    <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                        <RadioButton value="noCheck">待处理</RadioButton>
                        <RadioButton value="checked">已处理</RadioButton>
                    </RadioGroup>
                </div>

                <StandardTable
                    selectedRows={[]}
                    loading={loading}
                    data={data}
                    columns={this.columns}
                    onChange={this.handleStandardTableChange}
                    rowKey={record => record.Id}
                />
                <CheckForm visible={checkVisible} onCancel={() => this.handleCheckModalVisible(false)} />
            </div>
        );
    }
}

export default stop;
