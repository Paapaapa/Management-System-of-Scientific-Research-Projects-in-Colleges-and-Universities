import { Drawer, Upload, Divider, Timeline,Tooltip } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import DescriptionList from '@/components/DescriptionList';
import Ellipsis from '@/components/Ellipsis';

const { Description } = DescriptionList;

@connect(({ proposal, user, apply }) => ({
  record: proposal.formData,
  personSelect: user.personSelect,
  projectSelect: apply.projectSelect,
}))
class ReadDescription extends PureComponent {

  render() {
    const { record, visible, onClose, personSelect, projectSelect } = this.props;
    // 时间轴显示进度
    const RenderTimeline = (records) => (
      <Timeline pending={records.proposal_time ? false : "进行中···"} mode="alternate" style={{ paddingTop: '10px' }}>
        {records.set_time ? (
          <Timeline.Item>
            <div>{`管理员${personSelect[records.setman_id]}给项目设置了截止时间`}</div>
            <div>{moment(records.set_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
        {records.submit_time ? (
          <Timeline.Item>
            <div>{`${personSelect[records.principal_id]}提交了开题材料`}</div>
            <div>{moment(records.submit_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
        {records.check_time ? (
          <Timeline.Item>
            <div>{`专家${personSelect[records.checkman_id]}进行了开题评审`}</div>
            <div>{moment(records.check_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
        {records.proposal_time ? (
          <Timeline.Item>
            <div>{`管理员${personSelect[records.prman_id]}确认项目的开题阶段结束`}</div>
            <div>{moment(records.proposal_time).format('YYYY-MM-DD HH:mm:ss')}</div>
          </Timeline.Item>) : null}
      </Timeline>
    );
    // 附件下载
    const downloadFile = () => {
      const props = {
        fileList: record ?.file_path ?.split(',') ?.map((val, index) => ({
          'uid': index,
          'name': val.split('_')[1],
          'status': 'done',
          'url': `${window.location.origin}/server/api/file/download/proposal&${val}`,
        })),
        showUploadList: {
          showPreviewIcon: true,
          showRemoveIcon: false,
        },
      };
      return record.file_path ? (<Upload {...props} />) : <>暂无附件</>;
    };


    return (
      <Drawer
        destroyOnClose
        title={`${projectSelect[record ?.project_id]}-开题详情`}
        placement="right"
        closable={false}
        onClose={onClose}
        visible={visible}
        width={800}
      >
        <DescriptionList size="large" title="流程进度" style={{ marginBottom: 32 }}>
          {RenderTimeline(record)}
        </DescriptionList>
        <Divider style={{ marginBottom: 32,display: record ?.set_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="First-设置截止时间" style={{ marginBottom: 32, display: record ?.set_time ? 'block' : 'none'  }}>
          <Description term="截止时间">{moment(record ?.end_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
          <Description term="处理人员">{personSelect[record ?.setman_id]}</Description>
          <Description term="处理时间">{moment(record ?.set_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.submit_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Second-提交开题材料" style={{ marginBottom: 32, display: record ?.submit_time ? 'block' : 'none' }}>
          <Description term="项目负责人">{personSelect[record ?.principal_id]}</Description>
          <Description term="开题描述">
          <Ellipsis tooltip lines={1}>{record?.description}</Ellipsis>
          </Description>
          <Description term="提交时间">{moment(record ?.submit_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.check_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Third-专家评审" style={{ marginBottom: 32, display: record ?.check_time ? 'block' : 'none' }}>
          <Description term="评审专家">{personSelect[record ?.checkman_id]}</Description>
          <Description term="是否通过">{record ?.is_check_pass == 1 ? '是' : '否'}</Description>
          <Description term="评审意见">
          <Ellipsis tooltip lines={1}>{record?.check_comment}</Ellipsis>
          </Description>
          <Description term="评审时间">{moment(record ?.check_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32, display: record ?.proposal_time ? 'block' : 'none' }} />
        <DescriptionList size="large" title="Last-开题结束" style={{ marginBottom: 32, display: record ?.proposal_time ? 'block' : 'none' }}>
          <Description term="处理人员">{personSelect[record ?.prman_id]}</Description>
          <Description term="结束时间">{moment(record ?.proposal_time).format('YYYY-MM-DD HH:mm:ss')}</Description>
        </DescriptionList>
        <Divider style={{ marginBottom: 32 }} />
        <DescriptionList size="large" title="附件下载" style={{ marginBottom: 32 }}>
          <div style={{ marginLeft: '18px' }}>{downloadFile()}</div>
        </DescriptionList>
      </Drawer>
    );
  }
}

export default ReadDescription;