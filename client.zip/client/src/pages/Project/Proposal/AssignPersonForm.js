import { Modal, Select, Form, message,DatePicker } from 'antd';
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { formatObj } from '@/utils/utils';

const { Option } = Select;
const FormItem = Form.Item;

@connect(({ proposal, loading, user }) => ({
  proposal,
  loading: loading.models.rule,
  currentUser: user.currentUser
}))
@Form.create()
class AssignPerson extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      proposal: {
        formData
      },
      currentUser
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      if(!moment(formData.end_time).isBefore(fieldsValue.end_time) && formData.opt){
        message.error('延长时间必须在原截止时间之后');
        return;
      }
      dispatch({
        type: 'proposal/changeFormData',
        payload: {
          ...formatObj(formData),
          end_time:fieldsValue.end_time.format('YYYY-MM-DD HH:mm:ss'),
          status: 1,
          setman_id:currentUser.Id,
          set_time:moment().format('YYYY-MM-DD HH:mm:ss'),
          is_echeck_pass:formData.opt?1:null,
          echeck_time:formData.opt?moment().format('YYYY-MM-DD HH:mm:ss'):null,
          opt:formData.end_time?'reset':'set',
        },
      });
      dispatch({
        type: 'proposal/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("设置成功");
          dispatch({
            type: 'proposal/fetch',
          });
        } else {
          message.error("设置失败");
        }
      });
    });
  };

  render() {
    const { visible, onCancel,form,proposal: {
      formData
    } } = this.props;

    return (
      <Modal
        destroyOnClose
        title="设置截止时间"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 8 }} wrapperCol={{ span: 16 }} label="截止日期">
          {form.getFieldDecorator('end_time', {
            rules: [{ required: true, message: '日期未选择' }],
            initialValue:formData.end_time?moment(formData.end_time):'',
          })(<DatePicker  />)}
        </FormItem>
      </Modal>
    );
  };
};

export default AssignPerson;