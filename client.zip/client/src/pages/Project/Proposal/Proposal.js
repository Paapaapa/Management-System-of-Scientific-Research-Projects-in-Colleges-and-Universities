import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import StandardTable from '@/components/StandardTable';
import { Button, Card, Divider, Dropdown, Icon, Menu, message, Popconfirm, Radio, Modal } from 'antd';
import { connect } from 'dva';
import Link from 'umi/link';
import moment from 'moment';
import React, { Fragment, PureComponent } from 'react';
import styles from './Proposal.less';
import AssignPersonForm from './AssignPersonForm';
import CheckForm from './CheckForm';
import ReadDescription from './ReadDescription';
import AddForm from './AddForm';
import SearchForm from './SearchForm';
import ExtendForm from './ExtendForm';
import {
  formatObj,
} from '@/utils/utils';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待管理员设置截止时间', '等待负责人提交开题材料', '等待专家评审', '评审通过，等待确认', '评审不通过', '申请重新评审，等待评审', '已确认'];

@connect(({ proposal, loading, user, apply }) => ({
  proposal,
  loading: loading.models.rule,
  personSelect: user.personSelect,
  currentUser: user.currentUser,
  projectSelect: apply.projectSelect
}))
class Proposal extends PureComponent {
  state = {
    modalVisible: false,
    menuVal: 'all',
    selectedRows: [],
    assignPersonVisible: false,
    checkVisible: false,
    readVisible: false,
    extendVisible: false,
  };

  columns = [
    {
      title: '项目名称',
      dataIndex: 'project_id',
      sorter: true,
      render: (text) => {
        const { projectSelect } = this.props;
        return (<a onClick={()=>this.handleRouter(text)}>{projectSelect[text]}</a>)
      },
    },
    {
      title: '负责人',
      dataIndex: 'principal_id',
      sorter: true,
      render: text => {
        const { personSelect } = this.props;
        return personSelect[text];
      },
    },
    {
      title: '截止时间',
      dataIndex: 'end_time',
      sorter: true,
      render: text => text ? moment(text).format('YYYY-MM-DD HH:mm:ss') : '尚未设置',
    },
    {
      title: '进度',
      dataIndex: 'status',
      sorter: true,
      render: val => PROGRESS[val],
    },
    {
      title: '操作',
      render: (text, record) => {
        const { currentUser } = this.props;
        const { menuVal } = this.state;
        const isEdit = ((record.status > 0 && record.status < 3) || (record.status > 3 && record.status < 6)) && !moment(record.end_time).isBefore(moment());
        const isExtend = record.status === 1 && moment(record.end_time).isBefore(moment());
        const renderButton = {
          'G': {
            'self': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              {isEdit ? (<Divider type="vertical" />) : null}
              {isEdit ? (<a onClick={() => this.handleModalVisible(true, record)}>{record.status === 1 ? '提交材料' : '编辑'}</a>) : null}
              {record.status === 4 ? (<Divider type="vertical" />) : null}
              {record.status === 4 ? (<Popconfirm title="您确定申请重新评审吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请评审</a></Popconfirm>) : null}
              {isExtend ? (<Divider type="vertical" />) : null}
              {isExtend ? (<a onClick={() => this.handleExtendVisible(true, record, true)}>{(record.eapply_time && record.is_echeck_pass == null) ? '修改申请' : '申请延长时间'}</a>) : null}
              {record.eapply_time ? (<Divider type="vertical" />) : null}
              {record.eapply_time ? (<a onClick={() => this.handleDetail(record)}>查看申请详情</a>) : null}
            </Fragment>,
            'all': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
            </Fragment>,
            'noSet': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              <Divider type="vertical" />
              <a onClick={() => this.handlePersonModalVisible(true, record)}>设置截止时间</a>
            </Fragment>,
            'noProposal': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              <Divider type="vertical" />
              <Popconfirm title="您确定结束开题吗？" onConfirm={() => this.handleEstablish(record)} okText="确定" cancelText="取消"><a href="#">结束开题</a>
              </Popconfirm>
            </Fragment>,
            'seted': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              {record.status < 2 ? <Divider type="vertical" /> : null}
              {record.status < 2 ? <a onClick={() => this.handlePersonModalVisible(true, record)}>重设截止时间</a> : null}
            </Fragment>,
            'proposaled': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              {/* <Divider type="vertical" />
              <Popconfirm title="您确定取消结束吗？" onConfirm={() => this.handleCancelEs(record)} okText="确定" cancelText="取消"><a href="#">取消结束</a>
              </Popconfirm> */}
            </Fragment>,
            'noHandle': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              <Divider type="vertical" />
              <a onClick={() => this.handleDetail(record)}>查看申请详情</a>
              <Divider type="vertical" />
              <a onClick={() => this.handlePersonModalVisible(true, record, 'extend')}>延长</a>
              <Divider type="vertical" />
              <Popconfirm title="您确定驳回吗？" onConfirm={() => this.handleReject(record)} okText="确定" cancelText="取消"><a href="#">驳回</a>
              </Popconfirm>
            </Fragment>,
            'handled': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              <Divider type="vertical" />
              <a onClick={() => this.handleDetail(record)}>查看申请详情</a>
            </Fragment>
          },
          'J': {
            'self': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              {isEdit ? (<Divider type="vertical" />) : null}
              {isEdit ? (<a onClick={() => this.handleModalVisible(true, record)}>{record.status === 1 ? '提交材料' : '编辑'}</a>) : null}
              {record.status === 4 ? (<Divider type="vertical" />) : null}
              {record.status === 4 ? (<Popconfirm title="您确定申请重新评审吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请评审</a></Popconfirm>) : null}
              {isExtend ? (<Divider type="vertical" />) : null}
              {isExtend ? (<a onClick={() => this.handleExtendVisible(true, record)}>{(record.eapply_time && record.is_echeck_pass == null) ? '修改申请' : '申请延长时间'}</a>) : null}
              {record.eapply_time ? (<Divider type="vertical" />) : null}
              {record.eapply_time ? (<a onClick={() => this.handleDetail(record)}>查看申请详情</a>) : null}
            </Fragment>,
          },
          'Z': {
            'self':
              <Fragment>
                <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
                {isEdit ? (<Divider type="vertical" />) : null}
                {isEdit ? (<a onClick={() => this.handleModalVisible(true, record)}>{record.status === 1 ? '提交材料' : '编辑'}</a>) : null}
                {record.status === 4 ? (<Divider type="vertical" />) : null}
                {record.status === 4 ? (<Popconfirm title="您确定申请重新评审吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请评审</a></Popconfirm>) : null}
                {isExtend ? (<Divider type="vertical" />) : null}
                {isExtend ? (<a onClick={() => this.handleExtendVisible(true, record)}>{(record.eapply_time && record.is_echeck_pass == null) ? '修改申请' : '申请延长时间'}</a>) : null}
                {record.eapply_time ? (<Divider type="vertical" />) : null}
                {record.eapply_time ? (<a onClick={() => this.handleDetail(record)}>查看申请详情</a>) : null}
              </Fragment>,
            'noCheck': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              <Divider type="vertical" />
              <a onClick={() => this.handleCheckModalVisible(true, record)}>{record.check_time ? '重新评审' : '评审'}</a>
            </Fragment>,
            'checked': <Fragment>
              <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>
              {record.status < 5 ? <Divider type="vertical" /> : null}
              {record.status < 5 ? <a onClick={() => this.handleCheckModalVisible(true, record)}>重新评审</a> : null}
            </Fragment>,

          },
        };
        return renderButton[currentUser.role][menuVal];
      },
    },
  ];

  componentDidMount() {
    const { dispatch, currentUser,location } = this.props;
    dispatch({
      type: 'user/fetchSelect',
    });
    dispatch({
      type: 'apply/fetchSelect',
    });
    if (location.query.Id) {
      this.handleRadioGroup({
        target: {
          value: location.query.menuVal,
          opt:'redirect'
        }
      });
      dispatch({
        type: 'proposal/changeSearchFormFields',
        payload: {
          Id: location.query.Id,
        },
      });
      this.doPageSearch();
    } else {
      this.handleRadioGroup({
        target: {
          value: currentUser.role === 'G' ? 'all' : 'self'
        }
      });
    }
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetSearchData',
    });
    dispatch({
      type: 'proposal/resetList',
    });
    dispatch({
      type: 'proposal/saveTypeParams',
    });
  }

  handleRouter=(val)=>{
    const {currentUser}=this.props;
    router.push({
      pathname: '/project/apply',
      query: {
        Id: val,
        menuVal:currentUser.role==='G'?'all':'self',
      },
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const params = {
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'proposal/changeSearchFormFields',
      payload: params,
    })
    this.doPageSearch();
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (selectedRows.length === 0) return;
    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'proposal/remove',
          payload: {
            key: selectedRows.map(row => row.key),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/changeSelectedRows',
      payload: rows,
    });
  };

  handleModalVisible = (flag, record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    this.setState({
      modalVisible: !!flag,
    });
    if (record) {
      dispatch({
        type: 'proposal/changeFormData',
        payload: record,
      });
    }
  };

  handleExtendVisible = (flag, record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    this.setState({
      extendVisible: !!flag,
    });
    if (record) {
      dispatch({
        type: 'proposal/changeFormData',
        payload: record,
      });
    }
  }

  handlePersonModalVisible = (flag, record, opt) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    this.setState({
      assignPersonVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'proposal/changeFormData',
        payload: {
          ...record,
          opt,
        },
      });
  };

  handleCheckModalVisible = (flag, record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    this.setState({
      checkVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'proposal/changeFormData',
        payload: {
          ...record,
        },
      });
  };

  handleReadVisible = (flag, record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    this.setState({
      readVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'proposal/changeFormData',
        payload: {
          ...record,
        },
      });
  }

  handleRecheck = (record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    dispatch({
      type: 'proposal/changeFormData',
      payload: {
        ...formatObj(record),
        status: 5,
        is_check_pass: null,
        check_time: null,
        check_comment: null,
        checkman_id: null,
        opt: 'recheck',
      },
    });
    dispatch({
      type: 'proposal/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('申请成功');
        this.doPageSearch();
      } else {
        message.error('申请失败');
      }
    });
  }

  handleRefresh = () => {
    this.doPageSearch();
  }

  handleReject = (record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    dispatch({
      type: 'proposal/changeFormData',
      payload: {
        ...formatObj(record),
        is_echeck_pass: 0,
        echeck_time: moment().format('YYYY-MM-DD HH:mm:ss'),
        opt: 'nextend',
      },
    });
    dispatch({
      type: 'proposal/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('驳回成功');
        this.doPageSearch();
      } else {
        message.error('驳回失败');
      }
    });
  }

  handleRadioGroup = (e) => {
    const {
      dispatch,
      currentUser
    } = this.props;
    const params = {};
    this.setState({
      menuVal: e.target.value,
    });
    if(!e.target.opt){
      dispatch({
        type: 'proposal/changeSearchFormFields',
        payload:{
          Id:'',
        }
      });
    }
    switch (e.target.value) {
      case 'self':
        params.principal_id = currentUser.Id;
        params.del_flag = 0;
        break;
      case 'noSet':
        params.setman_id = 'null';
        params.del_flag = 0;
        break;
      case 'seted':
        params.setman_id = currentUser.Id;
        params.del_flag = 0;
        break;
      case 'noCheck':
        params.is_check_pass = 'null';
        params.checkman_id = 'null';
        params.submit_time = 'notNull';
        params.del_flag = 0;
        break;
      case 'checked':
        params.is_check_pass = 'notNull';
        params.checkman_id = currentUser.Id;
        params.del_flag = 0;
        break;
      case 'noProposal':
        params.check_time = 'notNull';
        params.is_check_pass = 1;
        params.proposal_time = 'null';
        params.del_flag = 0;
        break;
      case 'proposaled':
        params.prman_id = currentUser.Id;
        params.proposal_time = 'notNull';
        params.del_flag = 0;
        break;
      case 'noHandle':
        params.setman_id = currentUser.Id;
        params.extend_days = 'notNull';
        params.echeck_time = 'null';
        params.del_flag = 0;
        break;
      case 'handled':
        params.setman_id = currentUser.Id;
        params.echeck_time = 'notNull';
        params.del_flag = 0;
        break;
      default:
        params.del_flag = 0;
        break;
    }
    dispatch({
      type: 'proposal/saveTypeParams',
      payload: params,
    });
    this.doPageSearch();
  }

  handleRollBack = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    dispatch({
      type: 'proposal/changeFormData',
      payload: {
        ...formatObj(record),
        del_flag: 1,
      },
    });
    dispatch({
      type: 'proposal/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('撤销成功');
        this.doPageSearch();
      } else {
        message.error('撤销失败');
      }
    });
  }

  handleRestart = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    dispatch({
      type: 'proposal/changeFormData',
      payload: {
        ...formatObj(record),
        del_flag: 0,
        opt: 'remain',
      },
    });
    dispatch({
      type: 'proposal/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('恢复成功');
        this.doPageSearch();
      } else {
        message.error('恢复失败');
      }
    });
  }

  handleEstablish = (record) => {
    const {
      dispatch, currentUser
    } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    if (record)
      dispatch({
        type: 'proposal/changeFormData',
        payload: {
          ...formatObj(record),
          proposal_time: moment().format('YYYY-MM-DD HH:mm:ss'),
          status: 6,
          prman_id: currentUser.Id,
        },
      });
    dispatch({
      type: 'proposal/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success("结束成功");
        this.doPageSearch();
      } else {
        message.error("结束失败");
      }
    });
  };

  // handleCancelEs = (record) => {
  //   const {
  //     dispatch
  //   } = this.props;
  //   dispatch({
  //     type: 'proposal/resetFormData',
  //   });
  //   if (record)
  //     dispatch({
  //       type: 'proposal/changeFormData',
  //       payload: {
  //         ...formatObj(record),
  //         proposal_time: null,
  //         status: 3,
  //         prman_id: null,
  //       },
  //     });
  //   dispatch({
  //     type: 'proposal/add',
  //   }).then((res) => {
  //     if (res.code === 1) {
  //       message.success("取消结束成功");
  //       this.doPageSearch();
  //     } else {
  //       message.error("取消结束失败");
  //     }
  //   });
  // };

  handleDetail = (record) => {
    Modal.info({
      title: '申请详情',
      content: (
        <div style={{ marginTop: '16px' }}>
          <div>
            <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>延长天数：</span>
            {record ?.extend_days}天
          </div>
          <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
          <div>
            <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>延长理由：</span><br />
            {record ?.extend_reason}
          </div>
          {
            record.is_echeck_pass !== null ? <>
              <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
              <div>
                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>状态：</span>
                {record ?.is_echeck_pass == 0 ? '驳回' : '已同意'}
              </div>
            </> : null
          }
        </div>
      ),
      okText: '关闭'
    });
  }

  // handleRemove  =(record)=>{
  //   const {
  //     dispatch
  //   } = this.props;
  //   dispatch({
  //     type: 'proposal/remove',
  //     payload:{
  //       Id:record.Id
  //     },
  //   }).then((res) => {
  //     if (res.code === 1) {
  //       message.success("删除成功");
  //       this.doPageSearch();
  //     } else {
  //       message.error("删除失败");
  //     }
  //   });
  // }

  doPageSearch() {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'proposal/fetch',
    });
  }

  render() {
    const {
      proposal: { data },
      loading,
      currentUser
    } = this.props;
    const { selectedRows, modalVisible, menuVal, assignPersonVisible, checkVisible, extendVisible, readVisible } = this.state;
    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );

    data.pagination = {
      ...data.pagination,
      showTotal: total => `总计 ${total} 条数据`,
      pageSizeOptions: ['10', '20', '30'],
    };

    return (
      <PageHeaderWrapper title="项目开题">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              <SearchForm />
            </div>
            <div className={styles.tableListOperator}>
              <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                刷新
              </Button>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
              <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
                {currentUser.role === 'G' ? (<RadioButton value="all">全部</RadioButton>) : null}
                <RadioButton value="self">个人负责</RadioButton>
                {currentUser.role === 'G' ? (<RadioButton value="noSet">待设置时间</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="seted">已设置时间</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="noHandle">待处理申请</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="handled">已处理申请</RadioButton>) : null}
                {currentUser.role === 'Z' ? (<RadioButton value="noCheck">待审核</RadioButton>) : null}
                {currentUser.role === 'Z' ? (<RadioButton value="checked">已审核</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="noProposal">待结束</RadioButton>) : null}
                {currentUser.role === 'G' ? (<RadioButton value="proposaled">已结束</RadioButton>) : null}
              </RadioGroup>
            </div>

            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={this.columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
              rowKey="Id"
            />
          </div>
        </Card>
        <AddForm visible={modalVisible} onCancel={() => this.handleModalVisible(false)} />
        <AssignPersonForm visible={assignPersonVisible} onCancel={() => this.handlePersonModalVisible(false)} />
        <CheckForm visible={checkVisible} onCancel={() => this.handleCheckModalVisible(false)} />
        <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
        <ExtendForm visible={extendVisible} onCancel={() => this.handleExtendVisible(false)} />
      </PageHeaderWrapper>
    );
  }
}

export default Proposal;
