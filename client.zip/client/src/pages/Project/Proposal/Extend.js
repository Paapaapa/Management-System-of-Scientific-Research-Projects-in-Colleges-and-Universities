import StandardTable from '@/components/StandardTable';
import { formatObj } from '@/utils/utils';
import { Button, Divider, message, Modal, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import moment from 'moment';
import React, { PureComponent } from 'react';
import Link from 'umi/link';
import AssignPersonForm from './AssignPersonForm';
import styles from './Proposal.less';
import ReadDescription from './ReadDescription';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const PROGRESS = ['等待管理员设置截止时间', '等待负责人提交开题材料', '等待专家评审', '评审通过，等待确认', '评审不通过', '申请重新评审，等待评审', '已确认'];

@connect(({ proposal, loading, user, apply }) => ({
  proposal,
  loading: loading.models.rule,
  personSelect: user.personSelect,
  currentUser: user.currentUser,
  projectSelect: apply.projectSelect
}))
class Proposal extends PureComponent {
  state = {
    menuVal: 'noSet',
    assignPersonVisible: false,
    readVisible: false,
    extendVisible: false,
  };

  columns = [
    {
      title: '项目名称',
      dataIndex: 'project_id',
      sorter: true,
      render: (text) => {
        const { projectSelect } = this.props;
        return (<Link to={`/project/apply?menuVal=1&Id=${text}`}>{projectSelect[text]}</Link>)
      },
    },
    {
      title: '负责人',
      dataIndex: 'principal_id',
      sorter: true,
      render: text => {
        const { personSelect } = this.props;
        return personSelect[text];
      },
    },
    {
      title: '截止时间',
      dataIndex: 'end_time',
      sorter: true,
      render: text => text ? moment(text).format('YYYY-MM-DD HH:mm:ss') : '尚未设置',
    },
    {
      title: '进度',
      dataIndex: 'status',
      sorter: true,
      render: val => PROGRESS[val],
    },
    {
      title: '操作',
      render: (text, record) => {
        const { currentUser } = this.props;
        const renderBtn = {
          'divider': <Divider type="vertical" />,
          'read': <a onClick={() => this.handleReadVisible(true, record)}>查看详情</a>,
          'edit': <a onClick={() => this.handleModalVisible(true, record)}>{record.status === 1 ? '提交材料' : '编辑'}</a>,
          'applyCheck': <Popconfirm title="您确定申请重新评审吗？" onConfirm={() => this.handleRecheck(record)} okText="确定" cancelText="取消"><a href="#">申请评审</a></Popconfirm>,
          'extend': <a onClick={() => this.handleExtendVisible(true, record, true)}>{(record.eapply_time && record.is_echeck_pass == null) ? '修改申请' : '申请延长时间'}</a>,
          'readExtend': <a onClick={() => this.handleDetail(record)}>查看申请详情</a>,
          'set': <a onClick={() => this.handlePersonModalVisible(true, record)}>{record.set_time ? '重设截止时间' : '设置截止时间'}</a>,
          'finish': <Popconfirm title="您确定结束开题吗？" onConfirm={() => this.handleEstablish(record)} okText="确定" cancelText="取消"><a href="#">结束开题</a></Popconfirm>,
          'agreeExtend': <a onClick={() => this.handlePersonModalVisible(true, record, 'extend')}>延长</a>,
          'rejectExtend': <Popconfirm title="您确定驳回吗？" onConfirm={() => this.handleReject(record)} okText="确定" cancelText="取消"><a href="#">驳回</a></Popconfirm>,
        };
        return (<>
          {renderBtn.read}
          {record.status < 2 && currentUser.Id !== record.principal_id ? (<>{renderBtn.divider}{renderBtn.set}</>) : null}
          {record.eapply_time ? (<>{renderBtn.divider}{renderBtn.readExtend}</>) : null}
          {record.status < 2 && record.eapply_time && !record.echeck_time ? (<>{renderBtn.divider}{renderBtn.agreeExtend}{renderBtn.divider}{renderBtn.rejectExtend}</>) : null}
        </>
        );
      },
    },
  ];

  componentDidMount() {
    const { dispatch, currentUser, location } = this.props;
    dispatch({
      type: 'user/fetchSelect',
    });
    dispatch({
      type: 'apply/fetchSelect',
    });
  }

  componentWillReceiveProps(nextProps) {
    const { proposal: { isIndex } } = nextProps;
    if (isIndex) {
      this.setState({
        menuVal: 'noSet',
      })
    }
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const params = {
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'proposal/changeSearchFormFields',
      payload: params,
    })
    this.doPageSearch();
  };
  
 // opt是为了区分是否是处理延长申请时同意的情况，从而判断是否需要比较设置的新时间和旧时间
  handlePersonModalVisible = (flag, record, opt) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    this.setState({
      assignPersonVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'proposal/changeFormData',
        payload: {
          ...record,
          opt,
        },
      });
  };

  handleReadVisible = (flag, record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    this.setState({
      readVisible: !!flag,
    });
    if (record)
      dispatch({
        type: 'proposal/changeFormData',
        payload: {
          ...record,
        },
      });
  }

  handleRefresh = () => {
    this.doPageSearch();
  }

  handleReject = (record) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'proposal/resetFormData',
    });
    dispatch({
      type: 'proposal/changeFormData',
      payload: {
        ...formatObj(record),
        is_echeck_pass: 0,
        echeck_time: moment().format('YYYY-MM-DD HH:mm:ss'),
        opt: 'nextend',
      },
    });
    dispatch({
      type: 'proposal/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('驳回成功');
        this.doPageSearch();
      } else {
        message.error('驳回失败');
      }
    });
  }

  handleRadioGroup = (e) => {
    const {
      dispatch,
      currentUser
    } = this.props;
    const params = {};
    this.setState({
      menuVal: e.target.value,
    });
    switch (e.target.value) {
      case 'seted':
        params.setman_id = currentUser.Id;
        params.del_flag = 0;
        break;
      default:
        params.setman_id = 'null';
        params.del_flag = 0;
        break;
    }
    dispatch({
      type: 'proposal/changeIsIndex',
      payload: false,
    });
    dispatch({
      type: 'proposal/saveTypeParams',
      payload: params,
    });
    this.doPageSearch();
  }

  handleDetail = (record) => {
    Modal.info({
      title: '申请详情',
      content: (
        <div style={{ marginTop: '16px' }}>
          <div>
            <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>延长天数：</span>
            {record ?.extend_days}天
          </div>
          <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
          <div>
            <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>延长理由：</span><br />
            {record ?.extend_reason}
          </div>
          {
            record.is_echeck_pass !== null ? <>
              <hr style={{ background: '#c5c5c580', height: '1px', border: 'none' }} />
              <div>
                <span style={{ marginRight: '10px', fontWeight: 'bold', fontSize: '12px' }}>状态：</span>
                {record ?.is_echeck_pass == 0 ? '驳回' : '已同意'}
              </div>
            </> : null
          }
        </div>
      ),
      okText: '关闭'
    });
  }

  doPageSearch() {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'proposal/fetch',
    });
  }

  render() {
    const {
      proposal: { data },
      loading,
      currentUser
    } = this.props;
    const { menuVal, assignPersonVisible, readVisible } = this.state;
    data.pagination = {
      ...data.pagination,
      showTotal: total => `总计 ${total} 条数据`,
      pageSizeOptions: ['10', '20', '30'],
    };
    return (
      <div className={styles.tableList}>
        <div className={styles.tableListOperator}>
          <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
            刷新
          </Button>
          <RadioGroup style={{ float: "right" }} onChange={(e) => this.handleRadioGroup(e)} value={menuVal}>
            <RadioButton value="noSet">待处理</RadioButton>
            <RadioButton value="seted">已处理</RadioButton>
          </RadioGroup>
        </div>
        <StandardTable
          selectedRows={[]}
          loading={loading}
          data={data}
          columns={this.columns}
          onChange={this.handleStandardTableChange}
          rowKey={record => record.Id}
        />
        <AssignPersonForm visible={assignPersonVisible} onCancel={() => this.handlePersonModalVisible(false)} />
        <ReadDescription visible={readVisible} onClose={() => this.handleReadVisible(false)} />
      </div>
    );
  }
}

export default Proposal;
