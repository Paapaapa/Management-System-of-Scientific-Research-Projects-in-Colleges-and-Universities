import { Form, Input, message, Modal, Select, InputNumber, Upload, Button, Icon } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';
import {
  formatObj,
} from '@/utils/utils';
import {
  removeFile
} from '@/services/api';

const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;

@connect(({ files, user }) => ({
  formData: files.formData,
  currentUser: user.currentUser,
}))
@Form.create()
class AddForm extends PureComponent {
  state = {
    fileList: [],
  }

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      formData,
      currentUser
    } = this.props;
    const {
      fileList
    } = this.state;
    const postData = new FormData();
    fileList.forEach((file) => {
      postData.append('files', file);
    });
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      if(fileList.length>1){
        message.error('只能上传一个文件');
        return;
      }
      form.resetFields();
      Object.keys(fieldsValue).forEach(val => {
        postData.append(val, fieldsValue[val]);
      });
      postData.append('writer_id', currentUser.Id);
      dispatch({
        type: 'files/changeFormData',
        payload: postData,
      });
      dispatch({
        type: 'files/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("操作成功");
          this.setState({
            fileList: [],
          });
          dispatch({
            type: 'files/fetch',
          });
        } else {
          message.error("操作失败");
        }
      });
    });
  };

  render() {
    const { visible, onCancel, form, formData } = this.props;
    const { fileList } = this.state;
    const props = {
      onRemove: (file) => {
        this.setState((state) => {
          const index = state.fileList.indexOf(file);
          const newFileList = state.fileList.slice();
          newFileList.splice(index, 1);
          return {
            fileList: newFileList,
          };
        });
      },
      beforeUpload: (file) => {
        this.setState(state => ({
          fileList: [...state.fileList, file],
        }));
        return false;
      },
      fileList
    };

    return (
      <Modal destroyOnClose title="添加文件" visible={visible} onOk={this.handleOk} onCancel={onCancel}>
        <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} label="文件名称">
          {form.getFieldDecorator('name', {
            rules: [{ required: true,message:'必填' }],
            initialValue: formData?.name,
          })(<Input placeholder="请输入名称" />)}
        </FormItem>
        <FormItem label="文件上传" labelCol={{ span: 6 }} wrapperCol={{ span: 16 }} help="只能上传一个文件">
          <Upload name="files" listType="picture" {...props}>
            <Button>
              <Icon type="upload" /> 上传
            </Button>
          </Upload>
        </FormItem>
      </Modal>
    );
  };
};

export default AddForm;