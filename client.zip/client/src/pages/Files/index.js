import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import StandardTable from '@/components/StandardTable';
import { Button, Card, Divider, Dropdown, Form, Icon, Menu, message, Popconfirm, Modal } from 'antd';
import { connect } from 'dva';
import React, { Fragment, PureComponent } from 'react';
import styles from './index.less';
import AddForm from './AddForm';
import moment from 'moment';
import SearchForm from './SearchForm';


@connect(({ files, loading, user }) => ({
  files,
  loading: loading.models.rule,
  personSelect: user.personSelect,
}))
class Apply extends PureComponent {
  state = {
    modalVisible: false,
    selectedRows: [],
  };

  columns = [
    {
      title: '文件名称',
      dataIndex: 'name',
      sorter: true,
    },
    {
      title: '上传者',
      dataIndex: 'writer_id',
      sorter: true,
      render: text => {
        const { personSelect } = this.props;
        return personSelect[text];
      },
    },
    {
      title: '上传时间',
      dataIndex: 'upd_time',
      sorter: true,
      render: text => moment(text).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: '是否公开',
      dataIndex: 'is_public',
      sorter: true,
      render: text => text ? '是' : '否',
    },
    {
      title: '操作',
      render: (text, record) => (
        <>
          <a download href={`${window.location.origin}/server/api/file/download/template&${record.file_path}`}>下载文件</a>
          <Divider type="vertical" />
          <Popconfirm title="您确定公开这个文件吗？" onConfirm={() => this.handlePublic(record)} okText="确定" cancelText="取消">
            <a href="#">公开</a>
          </Popconfirm>
          <Divider type="vertical" />
          <Popconfirm title="您确定删除吗？" onConfirm={() => this.handleRemove(record)} okText="确定" cancelText="取消">
            <a href="#">删除</a>
          </Popconfirm>
        </>),
    },
  ];

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'user/fetchSelect',
    })
    this.doPageSearch();
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'files/resetSearchData',
    });
    dispatch({
      type: 'files/resetList',
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const params = {
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'files/changeSearchFormFields',
      payload: params,
    })
    this.doPageSearch();
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (selectedRows.length === 0) return;
    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'files/remove',
          payload: {
            key: selectedRows.map(row => row.key),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
    const { dispatch } = this.props;
    dispatch({
      type: 'files/changeSelectedRows',
      payload: rows,
    });
  };

  handleModalVisible = (flag, record) => {
    const { dispatch } = this.props;
    this.setState({
      modalVisible: !!flag,
    });
    dispatch({
      type: 'files/resetFormData',
    });
    if (record) {
      dispatch({
        type: 'files/changeFormData',
        payload: record,
      });
    }
  };

  handleRefresh = () => {
    this.doPageSearch();
  }

  handleRemove = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'files/remove',
      payload: record,
    }).then((res) => {
      if (res.code === 1) {
        message.success('删除成功');
        this.doPageSearch();
      } else {
        message.error('删除失败');
      }
    });
  }

  handlePublic = (record) => {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'files/changeFormData',
      payload: {
        ...record,
        is_public: 1,
      },
    });
    dispatch({
      type: 'files/add',
    }).then((res) => {
      if (res.code === 1) {
        message.success('处理成功');
        this.doPageSearch();
      } else {
        message.error('处理失败');
      }
    });
  }

  doPageSearch() {
    const {
      dispatch
    } = this.props;
    dispatch({
      type: 'files/fetch',
    });
  }

  render() {
    const {
      files: { data },
      loading,
    } = this.props;
    const { modalVisible, selectedRows } = this.state;
    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );

    data.pagination = {
      ...data.pagination,
      showTotal: total => `总计 ${total} 条数据`,
      pageSizeOptions: ['10', '20', '30'],
    };

    return (
      <PageHeaderWrapper title="文件管理">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <SearchForm />
            <div className={styles.tableListOperator}>
              <Button icon="reload" type="primary" onClick={() => this.handleRefresh()}>
                刷新
              </Button>
              <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
                新建
              </Button>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={this.columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
              rowKey={record => record.Id}
            />
          </div>
        </Card>
        <AddForm visible={modalVisible} onCancel={() => this.handleModalVisible(false)} />
      </PageHeaderWrapper>
    );
  }
}

export default Apply;
