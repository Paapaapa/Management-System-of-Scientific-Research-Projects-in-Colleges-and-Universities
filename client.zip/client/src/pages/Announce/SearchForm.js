import { Button, Col, Form, Input, Row } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';

const FormItem = Form.Item;

@connect()
@Form.create()
class SearchForm extends PureComponent {

  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    dispatch({
      type: 'announce/resetSearchData',
    });
    dispatch({
      type: 'announce/fetch',
    });
  };

  handleSearch = (e) => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      };
      dispatch({
        type: 'announce/changeSearchFormFields',
        payload: values,
      });
      dispatch({
        type: 'announce/fetch',
      });
    });
  };

  render() {
    const {
      form: { getFieldDecorator }
    } = this.props;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="标题">
              {getFieldDecorator('title')(
                <Input placeholder="请输入标题" />
              )}
            </FormItem>
          </Col>
          <Col md={16} sm={24}>
            <div style={{ overflow: 'hidden' }}>
              <div style={{ marginBottom: 24, marginTop: 4 }}>
                <Button type="primary" htmlType="submit">
                  查询
                   </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                  重置
                   </Button>
              </div>
            </div>
          </Col>
        </Row>
      </Form>
    );
  };
};

export default SearchForm;