import { Form, Input, message, Modal } from 'antd';
import { connect } from 'dva';
import React, { PureComponent } from 'react';

const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ announce,user }) => ({
  formData: announce.formData,
  currentUser:user.currentUser,
}))
@Form.create()
class AddForm extends PureComponent {

  handleOk = () => {
    const {
      dispatch,
      form,
      onCancel,
      formData,
      currentUser
    } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      if (formData.Id) {
        dispatch({
          type: 'announce/changeFormData',
          payload: fieldsValue,
        });
      } else {
        dispatch({
          type: 'announce/changeFormData',
          payload: {
            ...fieldsValue,
            writer_id: currentUser.Id,
          },
        });
      }
      dispatch({
        type: 'announce/add',
      }).then((res) => {
        if (res.code === 1) {
          onCancel();
          message.success("操作成功");
          dispatch({
            type: 'announce/fetch',
          });
        } else {
          message.error("操作失败");
        }
      });
    });
  };

  render() {
    const { visible, onCancel, form, formData } = this.props;

    return (
      <Modal
        destroyOnClose
        title="添加公告"
        visible={visible}
        onOk={this.handleOk}
        onCancel={onCancel}
      >
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 16 }} label="标题">
          {form.getFieldDecorator('title', {
            rules: [{ required: true, message: '必填' }],
            initialValue: formData ?.title,
          })(<Input placeholder="请输入标题" />)}
        </FormItem>
        <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 16 }} label="内容">
          {form.getFieldDecorator('content', {
            rules: [{ required: true, message: '请至少输入10个字符！', min: 10 }],
            initialValue: formData ?.content,
          })(<TextArea
            style={{ minHeight: 32 }}
            placeholder='请输入内容'
            rows={4}
          />)}
        </FormItem>
      </Modal>
    );
  };
};

export default AddForm;