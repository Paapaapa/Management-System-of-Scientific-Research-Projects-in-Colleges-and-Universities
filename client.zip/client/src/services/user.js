import request from '@/utils/request';
import qs from 'qs';

export async function query(params) {
  return request(`/server/api/person/query?${qs.stringify(params)}`);
}
// 获取当前用户相关信息
export async function queryCurrent(params) {
  return request(`/server/api/person/currentUser?${qs.stringify(params)}`);
}
// 获取展示人员数据
export async function querySelect(params) {
  return request(`/server/api/person/select?${qs.stringify(params)}`);
}
// 获取展示头像数据
export async function queryAvatar() {
  return request(`/server/api/person/avatar`);
}

// 添加，修改
export async function add(params) {
  return request('/server/api/person/add', {
    method: 'POST',
    body: params,
  });
}

// 删除
export async function remove(params) {
  return request(`/server/api/person/delete?${qs.stringify(params)}`);
}