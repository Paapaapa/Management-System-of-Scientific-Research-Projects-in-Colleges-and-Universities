import { stringify } from 'qs';
import request from '@/utils/request';

// 项目申报
// 分页查询
export async function queryProjectApply(params) {
  return request(`/server/api/projectApply/query?${stringify(params)}`);
}
// 添加，修改
export async function addProjectApply(params) {
  return request('/server/api/projectApply/add', {
    method: 'POST',
    body: params,
  });
}
// 删除
export async function removeProjectApply(params) {
  return request(`/server/api/projectApply/delete?${stringify(params)}`);
}
// 获取展示数据
export async function queryPApplySelect(params) {
  return request(`/server/api/projectApply/select?${stringify(params)}`);
}
// 区域图
export async function getPCharts(params) {
  return request(`/server/api/projectApply/charts?${stringify(params)}`);
}
// 专家评审
export async function queryZCheck(params) {
  return request(`/server/api/projectApply/zcheck?${stringify(params)}`);
}
// 添加，修改
export async function addZCheck(params) {
  return request('/server/api/projectApply/zcheck/add', {
    method: 'POST',
    body: params,
  });
}
// 删除
export async function removeZCheck(params) {
  return request(`/server/api/projectApply/zcheck/delete?${stringify(params)}`);
}

// 选题管理
export async function querySign(params) {
  return request(`/server/api/projectApply/sign?${stringify(params)}`);
}
// 添加，修改
export async function addSign(params) {
  return request('/server/api/projectApply/sign/add', {
    method: 'POST',
    body: params,
  });
}
// 删除
export async function removeSign(params) {
  return request(`/server/api/projectApply/sign/delete?${stringify(params)}`);
}

// 项目中止
// 分页查询
export async function queryStop(params) {
  return request(`/server/api/projectApply/stop?${stringify(params)}`);
}
// 添加，修改
export async function addStop(params) {
  return request('/server/api/projectApply/stop/add', {
    method: 'POST',
    body: {
      ...params,
    },
  });
}
// 删除
export async function removeStop(params) {
  return request(`/server/api/projectApply/stop/delete?${stringify(params)}`);
}

// 项目类别
// 分页查询
export async function queryProjectCategory(params) {
  return request(`/server/api/projectCategory/query?${stringify(params)}`);
}
// 添加，修改
export async function addProjectCategory(params) {
  return request('/server/api/projectCategory/add', {
    method: 'POST',
    body: {
      ...params,
    },
  });
}
// 删除
export async function removeProjectCategory(params) {
  return request(`/server/api/projectCategory/delete?${stringify(params)}`);
}

// 获取展示类别数据
export async function queryCategorySelect() {
  return request('/server/api/projectCategory/select');
}

// 经费申报
// 分页查询
export async function queryExpenditure(params) {
  return request(`/server/api/expenditure/query?${stringify(params)}`);
}
// 添加，修改
export async function addExpenditure(params) {
  return request('/server/api/expenditure/add', {
    method: 'POST',
    body: params,
  });
}
// 删除
export async function removeExpenditure(params) {
  return request(`/server/api/expenditure/delete?${stringify(params)}`);
}
// 柱状图
export async function getECharts() {
  return request(`/server/api/expenditure/charts`);
}

// 成果登记
// 分页查询
export async function queryFruit(params) {
  return request(`/server/api/fruit/query?${stringify(params)}`);
}
// 添加，修改
export async function addFruit(params) {
  return request('/server/api/fruit/add', {
    method: 'POST',
    body: params,
  });
}
// 删除
export async function removeFruit(params) {
  return request(`/server/api/fruit/delete?${stringify(params)}`);
}

// 图表
export async function getFCharts(params) {
  return request(`/server/api/fruit/charts?${stringify(params)}`);
}

// 通知
// 分页查询
export async function queryNotice(params) {
  return request(`/server/api/notice/query?${stringify(params)}`);
}
// 添加，修改
export async function addNotice(params) {
  return request('/server/api/notice/add', {
    method: 'POST',
    body: {
      ...params,
    },
  });
}
// 删除
export async function removeNotice(params) {
  return request(`/server/api/notice/delete?${stringify(params)}`);
}

// 项目开题
// 分页查询
export async function queryProposal(params) {
  return request(`/server/api/proposal/query?${stringify(params)}`);
}
// 添加，修改
export async function addProposal(params) {
  return request('/server/api/proposal/add', {
    method: 'POST',
    body: params,
  });
}
// 删除
export async function removeProposal(params) {
  return request(`/server/api/proposal/delete?${stringify(params)}`);
}
// 图表
export async function getPPCharts() {
  return request(`/server/api/proposal/charts`);
}

// 中期检查
// 分页查询
export async function queryMidcheck(params) {
  return request(`/server/api/midcheck/query?${stringify(params)}`);
}
// 添加，修改
export async function addMidcheck(params) {
  return request('/server/api/midcheck/add', {
    method: 'POST',
    body: params,
  });
}
// 删除
export async function removeMidcheck(params) {
  return request(`/server/api/midcheck/delete?${stringify(params)}`);
}
// 图表
export async function getPMCharts() {
  return request(`/server/api/midcheck/charts`);
}

// 项目结题
// 分页查询
export async function queryConclude(params) {
  return request(`/server/api/conclude/query?${stringify(params)}`);
}
// 添加，修改
export async function addConclude(params) {
  return request('/server/api/conclude/add', {
    method: 'POST',
    body: params,
  });
}
// 删除
export async function removeConclude(params) {
  return request(`/server/api/conclude/delete?${stringify(params)}`);
}
// 图表
export async function getPCCharts() {
  return request(`/server/api/conclude/charts`);
}

// 成果评价
// 分页查询
export async function queryComment(params) {
  return request(`/server/api/comment/query?${stringify(params)}`);
}
// 添加，修改
export async function addComment(params) {
  return request('/server/api/comment/add', {
    method: 'POST',
    body: params,
  });
}
// 删除
export async function removeComment(params) {
  return request(`/server/api/comment/delete?${stringify(params)}`);
}

// 删除文件
export async function removeFile(params) {
  return request(`/server/api/file/delete?${stringify(params)}`);
}

// 公告
// 分页查询
export async function queryAnnounce(params) {
  return request(`/server/api/announce/query?${stringify(params)}`);
}
// 添加，修改
export async function addAnnounce(params) {
  return request('/server/api/announce/add', {
    method: 'POST',
    body: {
      ...params,
    },
  });
}
// 删除
export async function removeAnnounce(params) {
  return request(`/server/api/announce/delete?${stringify(params)}`);
}

// 文件管理
// 分页查询
export async function queryFiles(params) {
  return request(`/server/api/files/query?${stringify(params)}`);
}
// 添加，修改
export async function addFiles(params) {
  return request('/server/api/files/add', {
    method: 'POST',
    body: params,
  });
}
// 删除
export async function removeFiles(params) {
  return request(`/server/api/files/delete?${stringify(params)}`);
}

export async function queryProjectNotice() {
  return request('/api/project/notice');
}

export async function queryActivities() {
  return request('/api/activities');
}

export async function queryRule(params) {
  return request(`/api/rule?${stringify(params)}`);
}

export async function removeRule(params) {
  return request('/api/rule', {
    method: 'POST',
    body: {
      ...params,
      method: 'delete',
    },
  });
}

export async function addRule(params) {
  return request('/api/rule', {
    method: 'POST',
    body: {
      ...params,
      method: 'post',
    },
  });
}

export async function updateRule(params = {}) {
  return request(`/api/rule?${stringify(params.query)}`, {
    method: 'POST',
    body: {
      ...params.body,
      method: 'update',
    },
  });
}

export async function fakeSubmitForm(params) {
  return request('/api/forms', {
    method: 'POST',
    body: params,
  });
}

export async function fakeChartData() {
  return request('/api/fake_chart_data');
}

export async function queryTags() {
  return request('/api/tags');
}

export async function queryBasicProfile(id) {
  return request(`/api/profile/basic?id=${id}`);
}

export async function queryAdvancedProfile() {
  return request('/api/profile/advanced');
}

export async function queryFakeList(params) {
  return request(`/api/fake_list?${stringify(params)}`);
}

export async function removeFakeList(params) {
  const { count = 5, ...restParams } = params;
  return request(`/api/fake_list?count=${count}`, {
    method: 'POST',
    body: {
      ...restParams,
      method: 'delete',
    },
  });
}

export async function addFakeList(params) {
  const { count = 5, ...restParams } = params;
  return request(`/api/fake_list?count=${count}`, {
    method: 'POST',
    body: {
      ...restParams,
      method: 'post',
    },
  });
}

export async function updateFakeList(params) {
  const { count = 5, ...restParams } = params;
  return request(`/api/fake_list?count=${count}`, {
    method: 'POST',
    body: {
      ...restParams,
      method: 'update',
    },
  });
}
// 登录校验
export async function fakeAccountLogin(params) {
  return request('/server/api/person/login', {
    method: 'POST',
    body: {...params},
  });
}

export async function fakeRegister(params) {
  return request('/api/register', {
    method: 'POST',
    body: params,
  });
}

export async function queryNotices(params = {}) {
  return request(`/api/notices?${stringify(params)}`);
}

export async function getFakeCaptcha(mobile) {
  return request(`/api/captcha?mobile=${mobile}`);
}
